const bcrypt = require('bcryptjs');
const User = require('../models/User');
const generateToken = require('../utils/generateToken');

// POST /api/auth/register  (تسجيل عميل جديد)
const register = async (req, res) => {
  try {
    const { name, email, phone, password } = req.body;
    if (!name || !email || !phone || !password) {
      return res.status(400).json({ message: 'كل البيانات مطلوبة' });
    }

    const exists = await User.findOne({ email: email.toLowerCase() });
    if (exists) {
      return res.status(400).json({ message: 'البريد الإلكتروني مستخدم بالفعل' });
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    const user = await User.create({
      name, email, phone, password: hashedPassword, role: 'customer',
    });

    const token = generateToken(user);
    res.status(201).json({
      token,
      user: { id: user._id, name: user.name, email: user.email, phone: user.phone, role: user.role, firstOrderDiscountUsed: false },
    });
  } catch (err) {
    res.status(500).json({ message: 'حصل خطأ في التسجيل', error: err.message });
  }
};

// POST /api/auth/login  (بيشتغل لأي حد: عميل / أدمن / ستاف - حسب الـ role المخزن)
const login = async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      return res.status(400).json({ message: 'البريد وكلمة المرور مطلوبين' });
    }

    const user = await User.findOne({ email: email.toLowerCase() });
    if (!user) {
      return res.status(401).json({ message: 'بيانات الدخول غلط' });
    }

    const match = await bcrypt.compare(password, user.password);
    if (!match) {
      return res.status(401).json({ message: 'بيانات الدخول غلط' });
    }

    const token = generateToken(user);
    res.json({
      token,
      user: { id: user._id, name: user.name, email: user.email, phone: user.phone, role: user.role, firstOrderDiscountUsed: user.firstOrderDiscountUsed || false },
    });
  } catch (err) {
    res.status(500).json({ message: 'حصل خطأ في تسجيل الدخول', error: err.message });
  }
};

// GET /api/auth/me  (بيانات المستخدم المسجل دخوله دلوقتي)
const getMe = async (req, res) => {
  res.json({
    user: {
      id: req.user._id,
      name: req.user.name,
      email: req.user.email,
      phone: req.user.phone,
      role: req.user.role,
      savedShipping: req.user.savedShipping || null,
      firstOrderDiscountUsed: req.user.firstOrderDiscountUsed || false,
    }
  });
};

module.exports = { register, login, getMe };