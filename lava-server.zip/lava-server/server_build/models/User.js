const mongoose = require('mongoose');

const addressSchema = new mongoose.Schema({
  governorate: String,
  country: String,
  address: String,
  zipCode: String,
  phone2: String,
}, { _id: false });

const userSchema = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true, lowercase: true, trim: true },
  password: { type: String, required: true }, // مخزّن مشفّر (bcrypt) دايماً
  phone: { type: String, required: true },
  role: {
    type: String,
    enum: ['customer', 'admin', 'call_center', 'packer'],
    default: 'customer',
  },
  savedShipping: addressSchema,
  firstOrderDiscountUsed: { type: Boolean, default: false },

  // ===== نظام الولاء =====
  loyaltyOrderCount: { type: Number, default: 0 },       // عدد الطلبات المكتملة
  loyaltyCodes: [{ type: String }],                       // أكواد الخصم اللي الشخص استلمها
  loyaltyCodesUsed: [{ type: String }],                   // الأكواد اللي استخدمها فعلاً
}, { timestamps: true });

module.exports = mongoose.model('User', userSchema);
