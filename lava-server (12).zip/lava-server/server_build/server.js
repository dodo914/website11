const path = require('path');
// Always load the backend .env next to server.js, regardless of the directory
// from which Node is started (VS Code, root workspace, PM2, Render, etc.).
require('dotenv').config({ path: path.join(__dirname, '.env') });
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const compression = require('compression');
const rateLimit = require('express-rate-limit');
const cookieParser = require('cookie-parser');
const mongoose = require('mongoose');

const connectDB = require('./config/db');
const { csrfProtection } = require('./middleware/csrf');

// Connect to database first
connectDB();

const app = express();

// Correct client IP handling behind Vercel/Render/Railway-style reverse proxies.
if (process.env.NODE_ENV === 'production') {
  app.set('trust proxy', 1);
}

// Security headers
app.use(helmet());

// Compression
app.use(compression());

// CORS
// ملحوظة أمان: لما credentials: true بيبقى مفعّل، مايصحش origin يبقى wildcard ('*').
// في production الـ origin لازم يبقى domain الفرونت اند الفعلي (FRONTEND_URL/CLIENT_URL).
const productionOrigin = process.env.FRONTEND_URL || process.env.CLIENT_URL;
if (process.env.NODE_ENV === 'production' && !productionOrigin) {
  console.warn('⚠️  FRONTEND_URL/CLIENT_URL غير موجود في .env — الكوكيز (JWT) مش هتشتغل صح مع الفرونت اند بدون origin محدد.');
}
app.use(cors({
  origin: process.env.NODE_ENV === 'production'
    ? productionOrigin
    : true,
  credentials: true,
}));

// Body parsing with limits
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Cookie parsing (لازم قبل أي middleware بيستخدم req.cookies زي auth أو csrf)
app.use(cookieParser());

// حماية CSRF لكل الـ requests اللي بتغيّر بيانات (POST/PUT/PATCH/DELETE)
// بعد ما بقى الـ JWT متخزن في Cookie بدل Authorization header.
// (مش مقيدة بـ /api عشان req.path يفضل شامل المسار الكامل زي '/api/auth/login')
app.use(csrfProtection);

// Request timeout
app.use((req, res, next) => {
  req.setTimeout(30000); // 30 seconds
  res.setTimeout(30000);
  next();
});

// Rate limiting
const createLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: process.env.NODE_ENV === 'production' ? 400 : 1500, // keep protection without breaking legitimate local/admin use
  standardHeaders: true,
  legacyHeaders: false,
  message: { message: 'Too many requests, please try again later.' },
});

const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: process.env.NODE_ENV === 'production' ? 30 : 200,
  skipSuccessfulRequests: true,
  message: { message: 'Too many authentication attempts, please try again later.' },
});

const apiLimiter = rateLimit({
  windowMs: 1 * 60 * 1000, // 1 minute
  max: process.env.NODE_ENV === 'production' ? 200 : 800,
  standardHeaders: true,
  legacyHeaders: false,
  message: { message: 'Rate limit exceeded, please slow down.' },
});

// OTP endpoints get an additional limiter. The controller also limits each email
// to one code per minute and a maximum of five verification attempts.
const otpLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: process.env.NODE_ENV === 'production' ? 10 : 100,
  standardHeaders: true,
  legacyHeaders: false,
  message: { message: 'تم إرسال أكواد كثيرة. حاول مرة أخرى لاحقاً.' },
});

const healthBypassLimiter = (req, res, next) => {
  if (req.path === '/health') {
    return next();
  }
  return createLimiter(req, res, next);
};

// Apply rate limiters
app.use('/api', healthBypassLimiter);
app.use('/api/auth', authLimiter);
app.use('/api/auth/send-code', otpLimiter);
app.use('/api/orders', apiLimiter);

// Routes
app.use('/api/auth', require('./routes/authRoutes'));
app.use('/api/products', require('./routes/productRoutes'));
app.use('/api/orders', require('./routes/orderRoutes'));
app.use('/api/payments', require('./routes/paymentRoutes'));
app.use('/api/staff', require('./routes/staffRoutes'));
app.use('/api/customers', require('./routes/customerRoutes'));
app.use('/api/settings', require('./routes/settingsRoutes'));
app.use('/api/abandoned-carts', require('./routes/abandonedCartRoutes'));
app.use('/api/marketing', require('./routes/marketingRoutes'));
app.use('/marketing', require('./routes/marketingPublicRoutes'));

// Brevo/marketing worker runs server-side only. It never blocks API requests.
require('./services/marketingWorker').startMarketingWorker().catch(err => console.error('Marketing worker startup:', err));

// Payment-expiry worker: auto-fails Kashier/Paymob orders stuck on "pending"
// (customer opened the payment page and never finished/cancelled) and releases
// their reserved stock after Settings.paymentSettings.pendingTimeoutMinutes.
require('./services/paymentExpiryWorker').startPaymentExpiryWorker().catch(err => console.error('Payment-expiry worker startup:', err));
app.use('/api/traffic', require('./routes/trafficRoutes'));
app.use('/api/activity-logs', require('./routes/activityLogRoutes'));

// Product Catalog Feeds (Meta / Google / TikTok / Snapchat)
// لا يحتاج /api prefix — المنصات بتجيب اللينك مباشرة
app.use('/feeds', require('./routes/feedRoutes'));

// sitemap.xml و robots.txt (SEO) — بدون /api prefix عشان محركات البحث تلاقيهم في المكان المتوقع.
// ملحوظة مهمة: لو الفرونت والباك إند على دومينين مختلفين، لازم الـ reverse proxy/CDN
// بتاع دومين الفرونت يعمل proxy لمسارات /sitemap.xml و /robots.txt على الباك إند ده،
// عشان جوجل يلاقيهم على دومين المتجر نفسه.
const { getSitemap, getRobotsTxt } = require('./controllers/sitemapController');
app.get('/sitemap.xml', getSitemap);
app.get('/robots.txt', getRobotsTxt);

// Health check
app.get('/api/health', async (req, res) => {
  try {
    // Check database connection
    await mongoose.connection.db.admin().ping();
    res.json({
      status: 'healthy',
      database: 'connected',
      timestamp: new Date().toISOString(),
      uptime: process.uptime(),
    });
  } catch (err) {
    res.status(503).json({
      status: 'unhealthy',
      database: 'disconnected',
      error: err.message,
      timestamp: new Date().toISOString(),
    });
  }
});

app.get('/', (req, res) => {
  res.send('LAVA Server is Running 🔥');
});

// Global error handler
app.use((err, req, res, next) => {
  const requestId = req.headers['x-request-id'] || 'N/A';
  
  // Don't log sensitive data
  const safeError = {
    message: err.message || 'Internal server error',
    stack: process.env.NODE_ENV === 'development' ? err.stack : undefined,
    requestId,
    method: req.method,
    url: req.url,
    timestamp: new Date().toISOString(),
  };

  console.error('Error:', safeError);

  res.status(err.statusCode || 500).json({
    message: err.message || 'حصل خطأ في السيرفر',
    ...(process.env.NODE_ENV === 'development' && { stack: err.stack }),
  });
});

// 404 handler
app.use((req, res) => {
  res.status(404).json({ message: 'Endpoint not found' });
});

const PORT = parseInt(process.env.PORT || process.env.port, 10) || 5000;

const server = app.listen(PORT, () => {
  console.log(`🚀 Server running on port ${PORT}`);
  console.log(`Environment: ${process.env.NODE_ENV || 'development'}`);
}).on('error', (err) => {
  if (err.code === 'EADDRINUSE') {
    console.error(`Port ${PORT} is already in use. Please stop the other process or use a different port.`);
    console.error('You can find the process using: netstat -ano | findstr :' + PORT);
  }
  process.exit(1);
});

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('SIGTERM signal received: closing HTTP server');
  server.close(() => {
    console.log('HTTP server closed');
    mongoose.connection.close(false, () => {
      console.log('MongoDB connection closed');
      process.exit(0);
    });
  });
});

process.on('SIGINT', () => {
  console.log('SIGINT signal received: closing HTTP server');
  server.close(() => {
    console.log('HTTP server closed');
    mongoose.connection.close(false, () => {
      console.log('MongoDB connection closed');
      process.exit(0);
    });
  });
});

// Unhandled rejection handler
process.on('unhandledRejection', (err) => {
  console.error('Unhandled Promise Rejection:', err);
  // Don't exit, just log
});

module.exports = app;