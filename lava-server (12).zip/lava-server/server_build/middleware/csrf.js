// حماية CSRF بنمط Double-Submit Cookie
// بما إن الـ JWT بقى HttpOnly Cookie، لازم نتأكد إن أي POST/PUT/PATCH/DELETE
// جاي فعلاً من الفرونت اند بتاعنا مش من موقع تاني بيستغل تسجيل دخول المستخدم.
// الفكرة: بنبعت CSRF token في كوكي قابلة للقراءة من الـ JS، والفرونت لازم يبعتها
// تاني كـ Header (x-csrf-token). أي حد بره الموقع مايقدرش يقرا الكوكي بتاعتنا عشان
// Same-Origin Policy، فمايقدرش يبني الهيدر ده صح.

const { CSRF_COOKIE_NAME } = require('../utils/cookieAuth');

const SAFE_METHODS = new Set(['GET', 'HEAD', 'OPTIONS']);

// المسارات دي مش محتاجة CSRF لأنها بتحصل قبل ما يبقى فيه أي جلسة مسجلة
// (تسجيل الدخول نفسه محمي بالفعل بـ SameSite=Lax + rate limiting)
const EXEMPT_PATHS = new Set([
  '/api/auth/login',
  '/api/auth/register',
  '/api/auth/send-code',
  '/api/auth/verify-code',
  '/api/auth/check-email',
  // تتبع الزوار/السلة المتروكة: مسارات عامة بدون جلسة مسجلة، نفس مستوى الحماية
  // اللي كانت موجودة قبل التعديل (مفيش auth أصلاً هنا) — تزويرها مايأثرش على حساب مستخدم.
  '/api/traffic/visit',
  '/api/traffic/pageview',
  '/api/traffic/convert',
  '/api/traffic/funnel',
  '/api/abandoned-carts',
  '/api/abandoned-carts/recover',
  // Kashier server-to-server webhook — no browser CSRF token is available.
  '/api/payments/kashier/webhook',
]);

const csrfProtection = (req, res, next) => {
  if (SAFE_METHODS.has(req.method)) return next();
  if (EXEMPT_PATHS.has(req.path)) return next();

  const cookieToken = req.cookies?.[CSRF_COOKIE_NAME];
  const headerToken = req.headers['x-csrf-token'];

  if (!cookieToken || !headerToken || cookieToken !== headerToken) {
    return res.status(403).json({ message: 'طلب غير موثوق (CSRF). حدّث الصفحة وحاول مرة أخرى.' });
  }

  return next();
};

module.exports = { csrfProtection };
