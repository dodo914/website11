const jwt = require('jsonwebtoken');
const User = require('../models/User');

// بيتأكد إن فيه توكن صحيح جوه الهيدر Authorization: Bearer <token>
const protect = async (req, res, next) => {
  let token;
  const authHeader = req.headers.authorization;

  if (authHeader && authHeader.startsWith('Bearer ')) {
    try {
      token = authHeader.split(' ')[1];
      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      req.user = await User.findById(decoded.id).select('-password');
      if (!req.user) {
        return res.status(401).json({ message: 'المستخدم غير موجود' });
      }
      return next();
    } catch (err) {
      return res.status(401).json({ message: 'التوكن غير صالح أو منتهي' });
    }
  }

  return res.status(401).json({ message: 'لازم تسجل دخول الأول' });
};

// بيتأكد إن دور المستخدم مسموح له بالعملية دي
// استخدام: authorize('admin') أو authorize('admin', 'call_center')
const authorize = (...roles) => {
  return (req, res, next) => {
    if (!req.user || !roles.includes(req.user.role)) {
      return res.status(403).json({ message: 'مالكش صلاحية تعمل العملية دي' });
    }
    next();
  };
};

// بيحط req.user لو في توكن صحيح، وبيكمل عادي لو مفيش (للـ guests)
const optionalProtect = async (req, res, next) => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) return next();
  try {
    const token = authHeader.split(' ')[1];
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = await User.findById(decoded.id).select('-password');
  } catch (err) {
    // توكن غلط أو منتهي - نكمل كـ guest بدون خطأ
  }
  next();
};

module.exports = { protect, authorize, optionalProtect };