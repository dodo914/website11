const express = require('express');
const router = express.Router();
const {
  getProducts, getAllProductsAdmin, getProductById,
  createProduct, updateProduct, deleteProduct,
  uploadVariantImages,
} = require('../controllers/productController');
const { protect, authorize } = require('../middleware/auth');
const upload = require('../middleware/upload');

router.get('/', getProducts);
router.get('/admin', protect, authorize('admin'), getAllProductsAdmin);
router.get('/:id', getProductById);
router.post('/', protect, authorize('admin'), upload.array('images', 10), createProduct);
router.put('/:id', protect, authorize('admin'), upload.array('images', 10), updateProduct);
router.delete('/:id', protect, authorize('admin'), deleteProduct);
router.post('/:id/variants/:variantIndex/images', protect, authorize('admin'), upload.array('images', 10), uploadVariantImages);

module.exports = router;
