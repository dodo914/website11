const Settings = require('../models/Settings');
const { get, set, invalidateSettingsCaches, invalidateProductCaches, invalidateReviewCaches, CACHE_TTL, CACHE_KEYS } = require('../utils/cache');
const { logActivity } = require('../utils/activityLogger');

const buildSettingsDefaults = () => ({
  // ===== التحكم في أقسام الصفحة الرئيسية =====
  showFeaturedSection: true,
  showAboutSection: true,
  featuredSectionTitle: { ar: 'منتجات مميزة', en: 'Featured Products' },
  featuredDisplayStyle: 'grid',

  // ===== نظام الثيمات =====
  activeTheme: 'classic',
  customTheme: null,

  // ===== إعدادات تسجيل الدخول للعملاء =====
  customerLoginMethod: 'email_password',
  resendFromEmail: 'onboarding@resend.dev',

  freeShippingThreshold: 1500,
  defaultShippingCost: 90,
  showCountdownBar: true,
  showZipCode: false,
  showCountry: true,
  showPhone2: false,
  requiredPhone2: false,
  showCheckoutNotes: false,
  showReviews: true,
  defaultLowStockThreshold: 5,
  displayOutOfStockProducts: true,
  showRecommendations: true,
  showBundleOffers: true,
  showConfirmedExportForCallCenter: true,
  promotions: {
    guestDiscount: {
      enabled: true,
      percentage: 5,
      title: { ar: 'خصم 5%', en: 'Get 5% OFF' },
      message: { ar: 'اعمل حساب وخد خصم 5% على أول طلب ليك', en: 'Create an account and get 5% OFF your first order.' },
      buttonText: { ar: 'تسجيل الدخول / إنشاء حساب', en: 'Login / Register' },
    },
    welcomeOffer: {
      enabled: false,
      promotionId: null,
      image: '',
      title: { ar: 'عرض خاص 🎁', en: 'Special Offer 🎁' },
      description: { ar: 'احصل على عرض حصري لفترة محدودة', en: 'Get an exclusive offer for a limited time' },
      offerText: { ar: '', en: '' },
      buttonText: { ar: 'تسوق الآن', en: 'Shop Now' },
      destinationType: 'shop',
      productId: null,
      categoryId: null,
    },
  },
  campaigns: [],
  discountCodes: [
    { id: 1, code: 'WELCOME10', discountPercent: 10, isActive: true },
    { id: 2, code: 'SUMMER20', discountPercent: 20, isActive: true },
  ],
  expenses: [
    { id: 1, title: 'إعلان تمويلى فيسبوك', amount: 500 }
  ],
  contactMessages: [],
  faqs: [
    { id: 1, q: { ar: 'إيه هي سياسة الاسترجاع؟', en: 'What is the return policy?' }, a: { ar: 'تقدر ترجع المنتج خلال 14 يوم من الاستلام، بشرط يكون بحالته الأصلية.', en: 'You can return the product within 14 days of receipt, provided it is in its original condition.' } },
    { id: 2, q: { ar: 'مدة التوصيل قد إيه؟', en: 'How long does delivery take?' }, a: { ar: 'التوصيل بياخد من 3 لـ 5 أيام عمل حسب محافظتك.', en: 'Delivery takes 3 to 5 business days depending on your governorate.' } }
  ],
  productReviews: {},
  salesData: [
    { day: { ar: 'السبت', en: 'Sat' }, amount: 1200 },
    { day: { ar: 'الأحد', en: 'Sun' }, amount: 800 },
    { day: { ar: 'الإثنين', en: 'Mon' }, amount: 1500 },
    { day: { ar: 'الثلاثاء', en: 'Tue' }, amount: 2000 },
    { day: { ar: 'الأربعاء', en: 'Wed' }, amount: 950 },
    { day: { ar: 'الخميس', en: 'Thu' }, amount: 3000 },
    { day: { ar: 'الجمعة', en: 'Fri' }, amount: 2500 },
  ],
  // ===== نظام الولاء =====
  loyaltyProgram: {
    enabled: false,
    ordersRequired: 10,
    rewardType: 'percentage',
    rewardValue: 10,
    rewardProductId: null,
    codePrefix: 'LOYALTY',
    singleUse: true,
    specificProductId: null,
    title: { ar: 'مبروك! استحقيت خصم الولاء 🎉', en: 'Congratulations! You earned a loyalty reward 🎉' },
    message: { ar: 'كملت 10 طلبات وكسبت خصم خاص ليك!', en: 'You completed 10 orders and earned a special discount!' },
  },
});

const safeParseJson = (value) => {
  if (typeof value !== 'string') return null;
  const trimmed = value.trim();
  if (!trimmed) return null;
  if (!((trimmed.startsWith('{') && trimmed.endsWith('}')) || (trimmed.startsWith('[') && trimmed.endsWith(']')))) {
    return null;
  }

  try {
    return JSON.parse(trimmed);
  } catch (err) {
    return null;
  }
};

const normalizePlainObject = (value) => {
  if (!value) return {};
  if (value instanceof Map) {
    return Object.fromEntries(Array.from(value.entries()).map(([key, item]) => [key, sanitizeSettingsForMerge(item)]));
  }
  if (Array.isArray(value)) return value.map(item => sanitizeSettingsForMerge(item));
  if (typeof value === 'object') {
    const copy = {};
    Object.entries(value).forEach(([key, item]) => {
      // Never allow admin credentials or server-side provider secrets to be written through Settings.
      if (['_id', '__v', 'createdAt', 'updatedAt', 'adminPassword', 'adminEmail', 'resendApiKey', 'RESEND_API_KEY'].includes(key)) return;
      const parsedItem = safeParseJson(item);
      if (parsedItem !== null) {
        copy[key] = sanitizeSettingsForMerge(parsedItem);
        return;
      }
      copy[key] = sanitizeSettingsForMerge(item);
    });
    return copy;
  }
  return value;
};

const sanitizeSettingsForMerge = (value) => {
  if (typeof value === 'string') {
    const parsed = safeParseJson(value);
    if (parsed !== null) return sanitizeSettingsForMerge(parsed);
    return value;
  }

  if (!value || typeof value !== 'object') return value;
  if (Array.isArray(value)) return value.map(item => sanitizeSettingsForMerge(item));
  if (value instanceof Date) return new Date(value.getTime());
  if (value instanceof Map) return normalizePlainObject(value);

  return normalizePlainObject(value);
};

const mergeDeep = (target, source, seen = new WeakMap()) => {
  if (source === null || source === undefined) return source;
  if (source instanceof Date) return new Date(source.getTime());
  if (source instanceof Map) return new Map(source);

  if (Array.isArray(source)) {
    if (Array.isArray(target) && source.length === 0) {
      return [];
    }
    const output = Array.isArray(target) ? [...target] : [];
    source.forEach((item, index) => {
      output[index] = mergeDeep(output[index], item, seen);
    });
    return output;
  }

  if (source && typeof source === 'object') {
    if (seen.has(source)) return seen.get(source);
    const output = Array.isArray(target) ? [] : { ...(target || {}) };
    seen.set(source, output);

    Object.entries(source).forEach(([key, value]) => {
      if (value && typeof value === 'object' && !Array.isArray(value)) {
        output[key] = mergeDeep(output[key], value, seen);
      } else if (Array.isArray(value)) {
        if (value.length === 0) {
          output[key] = [];
          return;
        }
        output[key] = mergeDeep(Array.isArray(output[key]) ? output[key] : [], value, seen);
      } else if (value !== undefined) {
        output[key] = value;
      }
    });

    return output;
  }

  return source;
};

const normalizePromotionBlock = (value = {}) => {
  const defaults = buildSettingsDefaults().promotions;
  const guest = value?.guestDiscount || {};
  const welcome = value?.welcomeOffer || {};

  return {
    guestDiscount: {
      enabled: guest.enabled ?? defaults.guestDiscount.enabled,
      percentage: Number.isFinite(Number(guest.percentage)) ? Number(guest.percentage) : defaults.guestDiscount.percentage,
      title: guest.title && typeof guest.title === 'object'
        ? { ar: guest.title.ar ?? defaults.guestDiscount.title.ar, en: guest.title.en ?? defaults.guestDiscount.title.en }
        : defaults.guestDiscount.title,
      message: guest.message && typeof guest.message === 'object'
        ? { ar: guest.message.ar ?? defaults.guestDiscount.message.ar, en: guest.message.en ?? defaults.guestDiscount.message.en }
        : defaults.guestDiscount.message,
      buttonText: guest.buttonText && typeof guest.buttonText === 'object'
        ? { ar: guest.buttonText.ar ?? defaults.guestDiscount.buttonText.ar, en: guest.buttonText.en ?? defaults.guestDiscount.buttonText.en }
        : defaults.guestDiscount.buttonText,
    },
    welcomeOffer: {
      enabled: welcome.enabled ?? defaults.welcomeOffer.enabled,
      promotionId: welcome.promotionId ?? defaults.welcomeOffer.promotionId,
      image: welcome.image ?? defaults.welcomeOffer.image,
      title: welcome.title && typeof welcome.title === 'object'
        ? { ar: welcome.title.ar ?? defaults.welcomeOffer.title.ar, en: welcome.title.en ?? defaults.welcomeOffer.title.en }
        : defaults.welcomeOffer.title,
      description: welcome.description && typeof welcome.description === 'object'
        ? { ar: welcome.description.ar ?? defaults.welcomeOffer.description.ar, en: welcome.description.en ?? defaults.welcomeOffer.description.en }
        : defaults.welcomeOffer.description,
      offerText: welcome.offerText && typeof welcome.offerText === 'object'
        ? { ar: welcome.offerText.ar ?? defaults.welcomeOffer.offerText.ar, en: welcome.offerText.en ?? defaults.welcomeOffer.offerText.en }
        : defaults.welcomeOffer.offerText,
      buttonText: welcome.buttonText && typeof welcome.buttonText === 'object'
        ? { ar: welcome.buttonText.ar ?? defaults.welcomeOffer.buttonText.ar, en: welcome.buttonText.en ?? defaults.welcomeOffer.buttonText.en }
        : defaults.welcomeOffer.buttonText,
      destinationType: welcome.destinationType || defaults.welcomeOffer.destinationType,
      productId: welcome.productId != null ? String(welcome.productId) : defaults.welcomeOffer.productId,
      categoryId: welcome.categoryId != null ? String(welcome.categoryId) : defaults.welcomeOffer.categoryId,
    },
  };
};

const normalizeListField = (value, fallback = []) => {
  if (Array.isArray(value)) return value.filter(item => item !== null && item !== undefined);
  if (typeof value === 'string') {
    const parsed = safeParseJson(value);
    if (Array.isArray(parsed)) return parsed.filter(item => item !== null && item !== undefined);
    return fallback;
  }
  return fallback;
};

// ===== تطبيع مصفوفة الـ campaigns =====
// productId و categoryId قد يُخزَّنان في MongoDB كـ ObjectId فيرجعون كـ object،
// فنحوّلهم إلى string دايماً عشان مقارنة === في الفرونت تشتغل صح.
const normalizeCampaigns = (campaigns) => {
  if (!Array.isArray(campaigns)) return [];
  return campaigns.map((c) => {
    if (!c || typeof c !== 'object') return c;
    return {
      ...c,
      productId: c.productId != null ? String(c.productId) : null,
      categoryId: c.categoryId != null ? String(c.categoryId) : null,
    };
  });
};

const normalizedArrayReplacement = (value = []) => normalizeListField(value, []).map(item => sanitizeSettingsForMerge(item));

const normalizeObjectField = (value, fallback = {}) => {
  if (value && typeof value === 'object' && !Array.isArray(value)) return value;
  if (typeof value === 'string') {
    const parsed = safeParseJson(value);
    if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) return parsed;
  }
  return fallback;
};

const mergeSettingsPayload = (existing, incoming) => {
  const sanitizedExisting = sanitizeSettingsForMerge(existing);
  const sanitizedIncoming = sanitizeSettingsForMerge(incoming);
  const base = mergeDeep(buildSettingsDefaults(), sanitizedExisting);
  const merged = mergeDeep(base, sanitizedIncoming);

  // activeTheme: حقل string بسيط - بييجي تلقائياً مع mergeDeep بدون معالجة خاصة

  const listFields = ['categories', 'governorates', 'countries', 'homeSections', 'customPages', 'campaigns', 'discountCodes', 'expenses', 'contactMessages', 'faqs', 'salesData'];
  // loyaltyProgram treated as object field (below)
  listFields.forEach((field) => {
    if (Object.prototype.hasOwnProperty.call(sanitizedIncoming, field) && Array.isArray(sanitizedIncoming[field])) {
      const normalized = normalizedArrayReplacement(sanitizedIncoming[field]);
      merged[field] = field === 'campaigns' ? normalizeCampaigns(normalized) : normalized;
      return;
    }
    const nextValue = normalizeListField(merged[field], []);
    merged[field] = field === 'campaigns' ? normalizeCampaigns(nextValue) : nextValue;
  });

  const objectFields = ['storeName', 'logoText', 'heroTitle', 'heroSubtitle', 'aboutText', 'footerLocation', 'locationText', 'promotions', 'productReviews', 'loyaltyProgram'];
  objectFields.forEach((field) => {
    if (field === 'promotions') {
      merged[field] = normalizeObjectField(merged[field], buildSettingsDefaults().promotions);
      return;
    }
    if (field === 'productReviews') {
      // ===== دمج التقييمات بدل استبدالها بالكامل =====
      // مهم جداً: الأدمن بيبعت كائن productReviews من حالة الفرونت (قد يكون قديماً/غير محدّث)
      // لو استبدلناه بالكامل، هنفقد التقييمات الجديدة اللي زار العملاء ضافوها بعد آخر تحميل لإعدادات الأدمن.
      // الحل: ندمج بالمعرّف (review.id) — نحتفظ بأي تقييم قديم/جديد في DB، ونضيف أي تقييم جديد من الـ payload
      // بدون تكرار.
      const incomingReviews = normalizeObjectField(sanitizedIncoming.productReviews, {});
      const existingReviews = normalizeObjectField(sanitizedExisting.productReviews, {});
      const mergedReviews = { ...existingReviews };

      Object.entries(incomingReviews).forEach(([productId, reviews]) => {
        if (!Array.isArray(reviews)) return;
        const existingList = Array.isArray(mergedReviews[productId]) ? mergedReviews[productId] : [];
        const seenIds = new Set(existingList.map(r => r && r.id));
        const mergedList = [...existingList];
        reviews.forEach((review) => {
          if (!review || !review.id || !seenIds.has(review.id)) {
            mergedList.push(review);
            if (review && review.id) seenIds.add(review.id);
          }
        });
        mergedReviews[productId] = mergedList;
      });

      merged[field] = mergedReviews;
      return;
    }
    if (field === 'loyaltyProgram') {
      const defaults = buildSettingsDefaults().loyaltyProgram;
      const lp = merged[field] || {};
      merged[field] = {
        enabled: lp.enabled ?? defaults.enabled,
        ordersRequired: Number.isFinite(Number(lp.ordersRequired)) && Number(lp.ordersRequired) > 0 ? Number(lp.ordersRequired) : defaults.ordersRequired,
        rewardType: ['percentage','fixed','product'].includes(lp.rewardType) ? lp.rewardType : defaults.rewardType,
        rewardValue: Number.isFinite(Number(lp.rewardValue)) ? Number(lp.rewardValue) : defaults.rewardValue,
        rewardProductId: lp.rewardProductId != null ? String(lp.rewardProductId) : null,
        codePrefix: lp.codePrefix ? String(lp.codePrefix).trim().toUpperCase() : defaults.codePrefix,
        singleUse: lp.singleUse ?? defaults.singleUse,
        specificProductId: lp.specificProductId != null ? String(lp.specificProductId) : null,
        title: lp.title && typeof lp.title === 'object'
          ? { ar: lp.title.ar ?? defaults.title.ar, en: lp.title.en ?? defaults.title.en }
          : defaults.title,
        message: lp.message && typeof lp.message === 'object'
          ? { ar: lp.message.ar ?? defaults.message.ar, en: lp.message.en ?? defaults.message.en }
          : defaults.message,
      };
      return;
    }
    merged[field] = normalizeObjectField(merged[field], {});
  });

  const defaults = buildSettingsDefaults().promotions;
  const incomingGuest = sanitizedIncoming?.promotions?.guestDiscount || {};
  const hasGuestEnabledOverride = Object.prototype.hasOwnProperty.call(incomingGuest, 'enabled');
  const hasGuestPercentageOverride = Object.prototype.hasOwnProperty.call(incomingGuest, 'percentage');

  const nextPromotions = normalizePromotionBlock(merged.promotions);
  if (!hasGuestEnabledOverride && nextPromotions.guestDiscount.enabled === false) {
    nextPromotions.guestDiscount.enabled = defaults.guestDiscount.enabled;
  }
  if (!hasGuestPercentageOverride && Number(nextPromotions.guestDiscount.percentage) === 0) {
    nextPromotions.guestDiscount.percentage = defaults.guestDiscount.percentage;
  }

  return {
    ...merged,
    promotions: nextPromotions,
  };
};

const transformSettingsForMongoose = (payload = {}) => {
  const normalized = sanitizeSettingsForMerge(payload);

  if (normalized.productReviews && typeof normalized.productReviews === 'object' && !(normalized.productReviews instanceof Map)) {
    const productReviewsMap = new Map();
    Object.entries(normalized.productReviews).forEach(([productId, reviews]) => {
      if (Array.isArray(reviews)) {
        productReviewsMap.set(productId, reviews.map(item => sanitizeSettingsForMerge(item)));
      } else if (reviews !== undefined && reviews !== null) {
        productReviewsMap.set(productId, [sanitizeSettingsForMerge(reviews)]);
      }
    });
    normalized.productReviews = productReviewsMap;
  }

  return normalized;
};

const syncEnvFile = (body = {}) => {
  const envPath = require('path').resolve(__dirname, '../.env');
  if (!require('fs').existsSync(envPath)) return;

  const values = {
    META_API_KEY: body.metaApiKey ?? '',
    META_PIXEL_ID: body.metaPixelId ?? '',
    TIKTOK_API_KEY: body.tiktokApiKey ?? '',
    TIKTOK_PIXEL_ID: body.tiktokPixelId ?? '',
    GOOGLE_API_KEY: body.googleApiKey ?? '',
    GOOGLE_PIXEL_ID: body.googlePixelId ?? '',
    SNAPCHAT_API_KEY: body.snapchatApiKey ?? '',
    SNAPCHAT_PIXEL_ID: body.snapchatPixelId ?? '',
  };

  Object.entries(values).forEach(([key, value]) => {
    process.env[key] = String(value ?? '');
  });

  let envContent = require('fs').readFileSync(envPath, 'utf8');
  Object.entries(values).forEach(([key, value]) => {
    const normalizedValue = String(value ?? '').replace(/\r?\n/g, ' ');
    const regex = new RegExp(`^${key}=.*$`, 'm');
    if (regex.test(envContent)) {
      envContent = envContent.replace(regex, `${key}=${normalizedValue}`);
    } else {
      envContent += `\n${key}=${normalizedValue}`;
    }
  });

  require('fs').writeFileSync(envPath, envContent);
};

const getOrCreateSettings = async () => {
  let settings = await Settings.findOne();
  if (!settings) settings = await Settings.create({});
  return settings;
};

const serializeSettings = (settings) => {
  if (!settings) return {};
  const plain = settings.toObject ? settings.toObject() : settings;
  const normalized = {
    ...plain,
    productReviews: plain.productReviews instanceof Map
      ? Object.fromEntries(plain.productReviews.entries())
      : (plain.productReviews || {}),
    // نطبّع campaigns هنا مباشرةً قبل ما تتمر لـ mergeSettingsPayload
    // عشان ObjectId من MongoDB يتحول لـ string قبل أي مقارنة في الفرونت
    campaigns: normalizeCampaigns(Array.isArray(plain.campaigns) ? plain.campaigns : []),
  };
  return mergeSettingsPayload({}, normalized);
};

const PUBLIC_SECRET_FIELDS = new Set([
  'adminEmail', 'adminPassword', 'adminPhone',
  'metaApiKey', 'tiktokApiKey', 'googleApiKey', 'snapchatApiKey',
  'resendFromEmail',
  'contactMessages', 'expenses', 'salesData',
]);

const serializePublicSettings = (settings) => {
  const serialized = serializeSettings(settings);
  const safe = { ...serialized };
  PUBLIC_SECRET_FIELDS.forEach((field) => delete safe[field]);
  return safe;
};

// GET /api/settings/public  (عام - إعدادات آمنة بس)
const getPublicSettings = async (req, res) => {
  try {
    const cached = get(CACHE_KEYS.SETTINGS_PUBLIC);
    if (cached) {
      return res.json(cached);
    }

    const settings = await getOrCreateSettings();
    const serialized = serializePublicSettings(settings);
    
    set(CACHE_KEYS.SETTINGS_PUBLIC, serialized, CACHE_TTL.SETTINGS_PUBLIC);
    
    res.json(serialized);
  } catch (err) {
    console.error('Error fetching public settings:', err);
    res.status(500).json({ message: 'حصل خطأ في جلب الإعدادات', error: err.message });
  }
};

// GET /api/settings/admin  (أدمن بس)
const getAdminSettings = async (req, res) => {
  try {
    const cached = get(CACHE_KEYS.SETTINGS_ADMIN);
    if (cached) {
      return res.json(cached);
    }

    const settings = await getOrCreateSettings();
    const serialized = serializeSettings(settings);
    
    set(CACHE_KEYS.SETTINGS_ADMIN, serialized, CACHE_TTL.SETTINGS_ADMIN);
    
    res.json(serialized);
  } catch (err) {
    console.error('Error fetching admin settings:', err);
    res.status(500).json({ message: 'حصل خطأ في جلب الإعدادات', error: err.message });
  }
};

// PUT /api/settings  (أدمن بس)
let settingsWriteQueue = Promise.resolve();

const updateSettings = async (req, res) => {
  const runUpdate = async () => {
    try {
      const rawBody = sanitizeSettingsForMerge(req.body);

      const settings = await getOrCreateSettings();
      const plainSettings = settings && settings.toObject ? settings.toObject() : settings;
      const mergedPayload = mergeSettingsPayload(plainSettings, rawBody);
      const payloadForSave = transformSettingsForMongoose(mergedPayload);

      Object.keys(payloadForSave).forEach((field) => {
        if (Object.prototype.hasOwnProperty.call(payloadForSave, field)) {
          settings[field] = payloadForSave[field];
          settings.markModified(field);
        }
      });

      await settings.save();
      syncEnvFile(payloadForSave);

      const serialized = serializeSettings(settings);

      invalidateSettingsCaches();
      invalidateProductCaches();

      logActivity(req, {
        action: 'update',
        entityType: 'settings',
        description: `${req.user?.name || 'أدمن'} حدّث إعدادات المتجر`,
      });

      return res.json({ success: true, data: serialized });
    } catch (err) {
      console.error('Error updating settings:', err);
      return res.status(500).json({ message: 'حصل خطأ في حفظ الإعدادات', error: err.message });
    }
  };

  const nextWrite = settingsWriteQueue.then(runUpdate, runUpdate);
  settingsWriteQueue = nextWrite.then(() => undefined, () => undefined);
  return nextWrite;
};

// GET /api/settings/pixels
const getPublicPixels = async (req, res) => {
  try {
    const cached = get(CACHE_KEYS.SETTINGS_PIXELS);
    if (cached) {
      return res.json(cached);
    }

    const settings = await getOrCreateSettings();
    const pixels = {
      metaPixelId: settings.metaPixelId || process.env.META_PIXEL_ID || '',
      tiktokPixelId: settings.tiktokPixelId || process.env.TIKTOK_PIXEL_ID || '',
      googlePixelId: settings.googlePixelId || process.env.GOOGLE_PIXEL_ID || '',
      snapchatPixelId: settings.snapchatPixelId || process.env.SNAPCHAT_PIXEL_ID || '',
    };
    
    set(CACHE_KEYS.SETTINGS_PIXELS, pixels, CACHE_TTL.SETTINGS_PIXELS);
    
    res.json(pixels);
  } catch (err) {
    console.error('Error fetching pixels:', err);
    res.status(500).json({ message: 'حصل خطأ في جلب البيكسلات', error: err.message });
  }
};

// POST /api/settings/contact  (عام - رسالة تواصل من العميل)
const addContactMessage = async (req, res) => {
  try {
    const { name, phone, message } = req.body || {};

    if (!name || !phone || !message) {
      return res.status(400).json({ message: 'جميع الحقول مطلوبة' });
    }

    const settings = await getOrCreateSettings();
    const nextMessages = Array.isArray(settings.contactMessages) ? [...settings.contactMessages] : [];
    const newMessage = {
      id: Date.now(),
      name: String(name).trim(),
      phone: String(phone).trim(),
      message: String(message).trim(),
      date: new Date().toISOString(),
    };

    nextMessages.unshift(newMessage);
    settings.contactMessages = nextMessages;
    await settings.save();
    invalidateSettingsCaches();

    res.status(201).json({ message: newMessage });
  } catch (err) {
    console.error('Error adding contact message:', err);
    res.status(500).json({ message: 'حصل خطأ في إرسال الرسالة', error: err.message });
  }
};

// POST /api/settings/reviews  (عام - إضافة تقييم لمنتج)
const addProductReview = async (req, res) => {
  try {
    const { productId, name, rating, comment } = req.body;
    
    if (!productId || !name || !rating || !comment) {
      return res.status(400).json({ message: 'جميع الحقول مطلوبة' });
    }
    
    if (rating < 1 || rating > 5) {
      return res.status(400).json({ message: 'التقييم يجب أن يكون بين 1 و 5' });
    }
    
    const settings = await getOrCreateSettings();
    const reviews = settings.productReviews instanceof Map
      ? Object.fromEntries(settings.productReviews.entries())
      : (settings.productReviews || {});
    const productReviews = Array.isArray(reviews[productId]) ? reviews[productId] : [];

    const newReview = {
      id: Date.now(),
      name: String(name).trim(),
      rating: Number(rating),
      comment: String(comment).trim(),
      date: new Date().toISOString(),
    };

    reviews[productId] = [newReview, ...productReviews];
    settings.productReviews = reviews;
    await settings.save();
    if (settings.productReviews instanceof Map) {
      settings.productReviews = new Map(settings.productReviews.entries());
    }

    invalidateReviewCaches(productId);
    // ===== إبطال كاش الإعدادات أيضاً حتى تظهر التقييمات الجديدة فوراً =====
    // التقييمات تُقرأ من settings.productReviews عبر /api/settings/admin و /api/settings/public
    // لو فضلنا مبطلّين كاش الإعدادات بس، المستخدم هيكمل يشوف التقييمات القديمة (cache stale)
    invalidateSettingsCaches();

    res.status(201).json({ review: newReview, productId });
  } catch (err) {
    console.error('Error adding review:', err);
    res.status(500).json({ message: 'حصل خطأ في إضافة التقييم', error: err.message });
  }
};

// GET /api/settings/reviews/:productId  (عام - جلب تقييمات منتج)
const getProductReviews = async (req, res) => {
  try {
    const { productId } = req.params;
    
    // Try cache first
    const cacheKey = CACHE_KEYS.REVIEWS(productId);
    const cached = get(cacheKey);
    if (cached) {
      return res.json(cached);
    }

    const settings = await getOrCreateSettings();
    const reviews = settings.productReviews instanceof Map
      ? Object.fromEntries(settings.productReviews.entries())
      : (settings.productReviews || {});
    const productReviews = Array.isArray(reviews[productId]) ? reviews[productId] : [];

    set(cacheKey, productReviews, CACHE_TTL.REVIEWS);

    res.json(productReviews);
  } catch (err) {
    console.error('Error fetching reviews:', err);
    res.status(500).json({ message: 'حصل خطأ في جلب التقييمات', error: err.message });
  }
};

// GET /api/settings/store-health  (أدمن بس)
// بيحسب "جاهزية المتجر" كنسبة مئوية بناءً على عناصر أساسية: اللوجو، الثيم، المنتجات،
// الشحن، وسيلة الدفع، الدومين، وSEO. كل عنصر بيتحقق من بيانات حقيقية في الداتا بيز.
const getStoreHealth = async (req, res) => {
  try {
    const Product = require('../models/Product');
    const settings = await getOrCreateSettings();
    const plain = settings.toObject ? settings.toObject() : settings;

    const [productsCount, productsWithSeoCount] = await Promise.all([
      Product.countDocuments({}),
      Product.countDocuments({ $or: [{ 'metaTitle.ar': { $ne: null, $ne: '' } }, { 'metaTitle.en': { $ne: null, $ne: '' } }, { slug: { $ne: null, $ne: '' } }] }),
    ]);

    const hasLogo = !!(plain.useLogoImage && plain.logoImage) || !!(plain.logoText && (plain.logoText.ar || plain.logoText.en));
    const hasTheme = !!plain.activeTheme;
    const hasProducts = productsCount > 0;
    const hasShipping = Array.isArray(plain.governorates) && plain.governorates.length > 0;
    const hasPayment = Array.isArray(plain.paymentMethods) && plain.paymentMethods.some((m) => m && m.enabled);
    const hasDomain = !!(process.env.FRONTEND_URL || process.env.CLIENT_URL);
    const hasSeo = productsCount > 0 && productsWithSeoCount > 0;

    const checklist = [
      { key: 'logo', label: { ar: 'الشعار', en: 'Logo' }, done: hasLogo },
      { key: 'theme', label: { ar: 'التصميم (الثيم)', en: 'Theme' }, done: hasTheme },
      { key: 'products', label: { ar: 'المنتجات', en: 'Products' }, done: hasProducts },
      { key: 'shipping', label: { ar: 'الشحن', en: 'Shipping' }, done: hasShipping },
      { key: 'payment', label: { ar: 'وسيلة الدفع', en: 'Payment' }, done: hasPayment },
      { key: 'domain', label: { ar: 'الدومين', en: 'Domain' }, done: hasDomain },
      { key: 'seo', label: { ar: 'تحسين محركات البحث (SEO)', en: 'SEO' }, done: hasSeo },
    ];

    const doneCount = checklist.filter((c) => c.done).length;
    const percentage = Math.round((doneCount / checklist.length) * 100);

    res.json({ percentage, checklist });
  } catch (err) {
    console.error('Error computing store health:', err);
    res.status(500).json({ message: 'حصل خطأ في حساب جاهزية المتجر', error: err.message });
  }
};

module.exports = {
  getOrCreateSettings,
  getPublicSettings, getAdminSettings, updateSettings, getPublicPixels,
  addContactMessage, addProductReview, getProductReviews, mergeSettingsPayload, transformSettingsForMongoose, buildSettingsDefaults,
  getStoreHealth,
};