const Product = require('../models/Product');
const { uploadImageToCloudinary, deleteImageFromCloudinary, parseCloudinaryPublicId } = require('../utils/uploadToCloudinary');
const { get, set, invalidateProductCaches, CACHE_TTL, CACHE_KEYS } = require('../utils/cache');
const { logActivity } = require('../utils/activityLogger');

const getProductLabel = (p) => (p && p.name && (p.name.ar || p.name.en)) || '';

const normalizeIncomingImage = (item) => {
  if (!item) return null;
  if (typeof item === 'string') {
    const publicId = parseCloudinaryPublicId(item);
    return { url: item, publicId: publicId || undefined };
  }
  if (typeof item === 'object') {
    const url = item.url || item;
    const publicId = item.publicId || parseCloudinaryPublicId(url);
    return url ? { url, publicId: publicId || undefined } : null;
  }
  return null;
};

const normalizeImageArray = (images) => (Array.isArray(images) ? images.map(normalizeIncomingImage).filter(Boolean) : []);

const normalizeVariantImageArray = (images) => (Array.isArray(images) ? images.map((img) => {
  if (!img) return null;
  if (typeof img === 'string') return { url: img, publicId: undefined };
  return img;
}).filter(Boolean) : []);

const parseJsonLikeValue = (value) => {
  if (value === undefined || value === null) return null;
  if (typeof value === 'string') {
    const trimmed = value.trim();
    if (!trimmed) return null;

    try {
      return JSON.parse(trimmed);
    } catch (err) {
      if (trimmed.startsWith('{') || trimmed.startsWith('[')) {
        try {
          const cleaned = trimmed
            .replace(/\s*\+\s*['"]?/g, '')
            .replace(/\r?\n/g, ' ')
            .replace(/([{,]\s*)([A-Za-z0-9_$]+)(\s*:)/g, '$1"$2"$3')
            .replace(/'([^'\\]*(?:\\.[^'\\]*)*)'/g, '"$1"')
            .replace(/\s{2,}/g, ' ')
            .trim();

          if (cleaned && cleaned !== trimmed) {
            return JSON.parse(cleaned);
          }

          return Function(`"use strict"; return (${trimmed});`)();
        } catch (innerErr) {
          return value;
        }
      }

      return value;
    }
  }
  return value;
};

const normalizeOfferArray = (offers) => {
  if (!offers) return [];

  const rawList = Array.isArray(offers) ? offers : [offers];
  const normalized = rawList
    .filter(Boolean)
    .map((offer) => {
      if (typeof offer === 'string') {
        const parsed = parseJsonLikeValue(offer);
        if (!parsed || typeof parsed !== 'object') return null;
        return normalizeOfferArray([parsed])[0];
      }

      if (!offer || typeof offer !== 'object') return null;

      return {
        id: offer.id ?? null,
        name: offer.name ?? '',
        type: offer.type ?? 'percentage',
        minQty: Number(offer.minQty ?? 1) || 1,
        discountPercent: Number(offer.discountPercent ?? offer.percentage ?? 0) || 0,
        percentage: Number(offer.percentage ?? offer.discountPercent ?? 0) || 0,
        fixedAmount: Number(offer.fixedAmount ?? 0) || 0,
        buyQty: Number(offer.buyQty ?? 0) || 0,
        freeQty: Number(offer.freeQty ?? 0) || 0,
        active: offer.active !== false,
      };
    })
    .filter(Boolean);

  return normalized;
};

const normalizeBodyPayload = (reqBody) => {
  if (!reqBody) return {};

  if (typeof reqBody === 'string') {
    const parsed = parseJsonLikeValue(reqBody);
    return parsed && typeof parsed === 'object' ? parsed : {};
  }

  if (typeof reqBody === 'object') {
    const hasWrappedData = Object.prototype.hasOwnProperty.call(reqBody, 'data');
    if (hasWrappedData) {
      const parsed = parseJsonLikeValue(reqBody.data);
      if (parsed && typeof parsed === 'object') {
        const merged = { ...parsed, ...reqBody };
        delete merged.data;
        return merged;
      }
    }

    const normalized = { ...reqBody };
    ['images', 'variants', 'offers', 'bundle', 'recommendedIds', 'colors', 'sizes'].forEach((key) => {
      if (Object.prototype.hasOwnProperty.call(normalized, key) && typeof normalized[key] === 'string') {
        const candidate = normalized[key].trim();
        if (candidate.startsWith('{') || candidate.startsWith('[')) {
          const parsed = parseJsonLikeValue(normalized[key]);
          if (parsed !== normalized[key]) {
            normalized[key] = parsed;
          }
        }
      }
    });

    return normalized;
  }

  return reqBody;
};

// ============================================================
// Canonical sizeStock format: Array of { size, sku, stock }
//   [{ size: "S", sku: "...", stock: 10 }, ...]
//
// Legacy data may be stored as Object: { "S": { sku, stock } }
// We safely convert Object → Array. Valid Arrays are preserved.
// Never convert valid data to [].
// ============================================================
const normalizeSizeStock = (sizeStock) => {
  if (Array.isArray(sizeStock)) {
    return sizeStock
      .map((s) => ({
        size: s && s.size != null ? String(s.size) : null,
        sku: s && s.sku != null ? String(s.sku) : '',
        stock: Math.max(0, Number(s && s.stock) || 0),
      }))
      .filter((s) => s.size);
  }
  if (sizeStock && typeof sizeStock === 'object') {
    // Legacy Object format: { "S": { sku, stock } }
    return Object.entries(sizeStock)
      .map(([size, entry]) => ({
        size: String(size),
        sku: entry && entry.sku != null ? String(entry.sku) : '',
        stock: Math.max(0, Number(entry && entry.stock) || 0),
      }))
      .filter((s) => s.size);
  }
  return [];
};

const normalizeVariantsArray = (variants) => (Array.isArray(variants) ? variants.map((v) => ({
  ...v,
  images: normalizeVariantImageArray(v.images),
  sizeStock: normalizeSizeStock(v.sizeStock),
})) : []);

const normalizeObjectIdValue = (value) => {
  if (value === undefined || value === null) return value;
  if (typeof value === 'string') return value;
  if (typeof value.toString === 'function') return value.toString();
  return value;
};

const normalizeProductResponse = (product) => {
  if (!product) return product;
  const normalized = { ...product, id: product.id || normalizeObjectIdValue(product._id) };
  if (Array.isArray(normalized.images)) {
    normalized.images = normalized.images.map((img) => {
      if (!img) return null;
      if (typeof img === 'string') return img;
      return img.url || null;
    }).filter(Boolean);
  }
  if (Array.isArray(normalized.variants)) {
    normalized.variants = normalized.variants.map((variant) => ({
      ...variant,
      // Canonical variant id: prefer custom `id`, fall back to Mongo `_id`
      id: variant.id || normalizeObjectIdValue(variant._id),
      images: Array.isArray(variant.images)
        ? variant.images.map((img) => (typeof img === 'string' ? img : img?.url)).filter(Boolean)
        : [],
      sizeStock: normalizeSizeStock(variant.sizeStock),
    }));
  }
  if (Array.isArray(normalized.recommendedIds)) {
    normalized.recommendedIds = normalized.recommendedIds.map(normalizeObjectIdValue);
  }
  if (normalized.bundle && Array.isArray(normalized.bundle.productIds)) {
    normalized.bundle.productIds = normalized.bundle.productIds.map(normalizeObjectIdValue);
  }
  return normalized;
};

const normalizeProductArrayResponse = (products) => Array.isArray(products) ? products.map(normalizeProductResponse) : [];

const findRemovedImages = (existing = [], incoming = []) => {
  const incomingUrls = new Set((incoming || []).map(img => img.url));
  return (existing || []).filter(img => img.url && !incomingUrls.has(img.url));
};

const getVariantKey = (variant) => variant.id || variant._id?.toString();

const findRemovedVariantImages = (existingVariants = [], incomingVariants = []) => {
  const incomingByKey = new Map((incomingVariants || []).map(v => [getVariantKey(v), v]));
  return (existingVariants || []).flatMap((existingVariant, index) => {
    const key = getVariantKey(existingVariant) || String(index);
    const incomingVariant = incomingByKey.get(key) || incomingVariants[index] || { images: [] };
    const incomingUrls = new Set((incomingVariant.images || []).map(img => img.url));
    return (existingVariant.images || []).filter(img => img.url && !incomingUrls.has(img.url));
  });
};

// GET /api/products  (عام - لكل الزوار) - مع caching
const getProducts = async (req, res) => {
  try {
    // Try cache first
    const cached = get(CACHE_KEYS.PRODUCTS);
    if (cached) {
      return res.json(cached);
    }

    // Fetch from database
    const products = await Product.find({ visibility: 'published' })
      .sort({ createdAt: -1 })
      .lean();
    
    const normalizedProducts = normalizeProductArrayResponse(products);
    // Cache the results
    set(CACHE_KEYS.PRODUCTS, normalizedProducts, CACHE_TTL.PRODUCTS);
    
    res.json(normalizedProducts);
  } catch (err) {
    console.error('Error fetching products:', err);
    res.status(500).json({ message: 'حصل خطأ في جلب المنتجات', error: err.message });
  }
};

// GET /api/products/admin  (كل المنتجات حتى المخفية - أدمن بس) - مع caching
const getAllProductsAdmin = async (req, res) => {
  try {
    // Try cache first
    const cached = get(CACHE_KEYS.PRODUCT_ADMIN);
    if (cached) {
      return res.json(cached);
    }

    // Fetch from database
    const products = await Product.find()
      .sort({ createdAt: -1 })
      .lean();
    
    const normalizedProducts = normalizeProductArrayResponse(products);
    // Cache the results
    set(CACHE_KEYS.PRODUCT_ADMIN, normalizedProducts, CACHE_TTL.PRODUCTS);
    
    res.json(normalizedProducts);
  } catch (err) {
    console.error('Error fetching admin products:', err);
    res.status(500).json({ message: 'حصل خطأ في جلب المنتجات', error: err.message });
  }
};

// GET /api/products/:id
const getProductById = async (req, res) => {
  try {
    const { id } = req.params;
    
    // Try cache first
    const cacheKey = CACHE_KEYS.PRODUCT_DETAIL(id);
    const cached = get(cacheKey);
    if (cached) {
      return res.json(cached);
    }

    // Fetch from database
    const product = await Product.findById(id).lean();
    if (!product) {
      return res.status(404).json({ message: 'المنتج مش موجود' });
    }

    const normalizedProduct = normalizeProductResponse(product);
    // Cache the result
    set(cacheKey, normalizedProduct, CACHE_TTL.PRODUCT_DETAIL);
    
    res.json(normalizedProduct);
  } catch (err) {
    console.error('Error fetching product:', err);
    res.status(500).json({ message: 'حصل خطأ في جلب المنتج', error: err.message });
  }
};

// POST /api/products  (أدمن بس) - بيانات المنتج + صور (multipart/form-data)
const createProduct = async (req, res) => {
  try {
    const body = normalizeBodyPayload(req.body);
    const files = req.files || [];

    const uploadedImages = [];
    for (const file of files) {
      try {
        const image = await uploadImageToCloudinary(file.buffer, file.originalname, file.mimetype);
        uploadedImages.push(image);
      } catch (err) {
        console.error('Cloudinary upload failed, falling back to base64 storage:', err.message);
        const dataUrl = `data:${file.mimetype};base64,${file.buffer.toString('base64')}`;
        uploadedImages.push({ url: dataUrl, publicId: undefined, _fallback: true });
      }
    }

    const options = {
      ...body,
      images: [...normalizeImageArray(body.images), ...uploadedImages],
      variants: normalizeVariantsArray(body.variants),
      offers: normalizeOfferArray(body.offers),
    };

    if (!Array.isArray(options.offers) && Array.isArray(body.offers)) {
      options.offers = body.offers.map((offer) => normalizeOfferArray([offer])[0]).filter(Boolean);
    }

    const product = await Product.create(options);

    // Invalidate caches
    invalidateProductCaches();

    const normalizedProduct = normalizeProductResponse(product.toObject ? product.toObject() : product);

    logActivity(req, {
      action: 'create',
      entityType: 'product',
      entityId: product._id,
      entityLabel: getProductLabel(normalizedProduct),
    });

    res.status(201).json({ success: true, data: normalizedProduct });
  } catch (err) {
    console.error('Error creating product:', err);
    res.status(500).json({ message: 'حصل خطأ في إضافة المنتج', error: err.message });
  }
};

// PUT /api/products/:id  (أدمن بس)
const updateProduct = async (req, res) => {
  try {
    const product = await Product.findById(req.params.id);
    if (!product) {
      return res.status(404).json({ message: 'المنتج مش موجود' });
    }

    const body = normalizeBodyPayload(req.body);
    const files = req.files || [];

    const uploadedImages = [];
    for (const file of files) {
      try {
        const image = await uploadImageToCloudinary(file.buffer, file.originalname, file.mimetype);
        uploadedImages.push(image);
      } catch (err) {
        console.error('Cloudinary upload failed, falling back to base64 storage:', err.message);
        const dataUrl = `data:${file.mimetype};base64,${file.buffer.toString('base64')}`;
        uploadedImages.push({ url: dataUrl, publicId: undefined, _fallback: true });
      }
    }

    const incomingImages = [...normalizeImageArray(body.images), ...uploadedImages];
    const incomingVariants = normalizeVariantsArray(body.variants);
    const incomingOffers = normalizeOfferArray(body.offers);

    if (!Array.isArray(incomingOffers) || incomingOffers.length === 0) {
      const parsedOffers = Array.isArray(body.offers) ? body.offers : [];
      const rebuiltOffers = parsedOffers
        .map((offer) => normalizeOfferArray([offer])[0])
        .filter(Boolean);
      if (rebuiltOffers.length > 0) {
        incomingOffers.push(...rebuiltOffers);
      }
    }

    const removedProductImages = findRemovedImages(product.images, incomingImages);
    for (const img of removedProductImages) {
      await deleteImageFromCloudinary(img);
    }

    const removedVariantImages = findRemovedVariantImages(product.variants, incomingVariants);
    for (const img of removedVariantImages) {
      await deleteImageFromCloudinary(img);
    }

    const safeBody = { ...body };
    delete safeBody.data;
    delete safeBody.images;
    delete safeBody.variants;
    delete safeBody.offers;
    delete safeBody.recommendedIds;
    delete safeBody.bundle;
    // ===== إزالة الحقول المحمية التي تسبب VersionError في Mongoose =====
    // الفرونت بيبعت أحياناً كائن المنتج الكامل (بما فيه _id و __v و createdAt و updatedAt)
    // لو اتحطت __v بقيمة قديمة، Mongoose بيعمل optimistic concurrency check ويفشل الحفظ.
    delete safeBody._id;
    delete safeBody.id;
    delete safeBody.__v;
    delete safeBody.createdAt;
    delete safeBody.updatedAt;

    const finalOffers = body.offers !== undefined
      ? normalizeOfferArray(body.offers)
      : Array.isArray(product.offers)
        ? product.offers
        : [];

    const normalizedOfferPayload = Array.isArray(finalOffers) && finalOffers.length > 0
      ? finalOffers
      : (Array.isArray(incomingOffers) ? incomingOffers : []);


    // ===== معالجة recommendedIds و bundle صراحةً =====
    const incomingRecommendedIds = body.recommendedIds !== undefined
      ? (Array.isArray(body.recommendedIds) ? body.recommendedIds : [])
      : (Array.isArray(product.recommendedIds) ? product.recommendedIds.map(normalizeObjectIdValue) : []);

    const incomingBundle = body.bundle !== undefined
      ? {
          productIds: Array.isArray(body.bundle && body.bundle.productIds) ? body.bundle.productIds : [],
          discountPercent: Number((body.bundle && body.bundle.discountPercent) || 0),
        }
      : {
          productIds: Array.isArray(product.bundle && product.bundle.productIds) ? product.bundle.productIds.map(normalizeObjectIdValue) : [],
          discountPercent: Number((product.bundle && product.bundle.discountPercent) || 0),
        };

    product.images = incomingImages;
    product.variants = incomingVariants;
    product.offers = normalizedOfferPayload;
    product.recommendedIds = incomingRecommendedIds;
    product.bundle = incomingBundle;
    product.markModified('images');
    product.markModified('variants');
    product.markModified('offers');
    product.markModified('recommendedIds');
    product.markModified('bundle');

    Object.keys(safeBody).forEach((key) => {
      if (key === 'offers') return;
      product.set(key, safeBody[key]);
    });
    product.set({
      images: product.images,
      variants: product.variants,
      offers: product.offers,
      recommendedIds: product.recommendedIds,
      bundle: product.bundle,
    });

    await product.save();

    const reloadedProduct = await Product.findById(req.params.id).lean();

    // Data loss check removed - was causing false positives when offers normalize to empty

    invalidateProductCaches();

    const normalized = normalizeProductResponse(reloadedProduct || (product.toObject ? product.toObject() : product));

    const priceChanged = safeBody.price !== undefined && Number(safeBody.price) !== Number(reloadedProduct?.price);
    logActivity(req, {
      action: 'update',
      entityType: 'product',
      entityId: req.params.id,
      entityLabel: getProductLabel(normalized),
      description: priceChanged
        ? `${req.user?.name || 'أدمن'} غيّر سعر المنتج "${getProductLabel(normalized)}"`
        : undefined,
    });

    res.json(normalized);
  } catch (err) {
    console.error('Error updating product:', err);
    res.status(500).json({ message: 'حصل خطأ في تعديل المنتج', error: err.message });
  }
};

// DELETE /api/products/:id  (أدمن بس)
const deleteProduct = async (req, res) => {
  try {
    const product = await Product.findById(req.params.id);
    if (!product) {
      return res.status(404).json({ message: 'المنتج مش موجود' });
    }

    // مسح كل صور المنتج من Cloudinary
    for (const img of product.images || []) {
      await deleteImageFromCloudinary(img);
    }
    for (const v of product.variants || []) {
      for (const img of v.images || []) {
        await deleteImageFromCloudinary(img);
      }
    }

    const deletedLabel = getProductLabel(product);
    await product.deleteOne();

    // Invalidate caches
    invalidateProductCaches();

    logActivity(req, {
      action: 'delete',
      entityType: 'product',
      entityId: req.params.id,
      entityLabel: deletedLabel,
    });

    res.json({ success: true, data: { id: req.params.id, deleted: true } });
  } catch (err) {
    console.error('Error deleting product:', err);
    res.status(500).json({ message: 'حصل خطأ في حذف المنتج', error: err.message });
  }
};

// POST /api/products/:id/variants/:variantIndex/images  (أدمن بس)
// بيرفع صور إضافية لفاريانت (لون) معين ويضيفها لصوره الموجودة
const uploadVariantImages = async (req, res) => {
  try {
    const product = await Product.findById(req.params.id);
    if (!product) {
      return res.status(404).json({ message: 'المنتج مش موجود' });
    }

    const idx = Number(req.params.variantIndex);
    if (!product.variants[idx]) {
      return res.status(404).json({ message: 'الفاريانت مش موجود' });
    }

    const files = req.files || [];
    const uploadedImages = [];
    for (const file of files) {
      try {
        const image = await uploadImageToCloudinary(file.buffer, file.originalname, file.mimetype);
        uploadedImages.push(image);
      } catch (err) {
        console.error('Cloudinary upload failed for variant images, falling back to base64 storage:', err.message);
        const dataUrl = `data:${file.mimetype};base64,${file.buffer.toString('base64')}`;
        uploadedImages.push({ url: dataUrl, publicId: undefined, _fallback: true });
      }
    }

    product.variants[idx].images = [...(product.variants[idx].images || []), ...uploadedImages];
    await product.save();

    // Invalidate caches
    invalidateProductCaches();

    res.json(normalizeProductResponse(product.toObject ? product.toObject() : product));
  } catch (err) {
    console.error('Error uploading variant images:', err);
    res.status(500).json({ message: 'حصل خطأ في رفع صور الفاريانت', error: err.message });
  }
};

module.exports = {
  getProducts, getAllProductsAdmin, getProductById,
  createProduct, updateProduct, deleteProduct,
  uploadVariantImages,
};