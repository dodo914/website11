const AbandonedCart = require('../models/AbandonedCart');

// POST /api/abandoned-carts — يتبعت لما العميل يدخل Checkout بدون ما يكمل
const upsertAbandonedCart = async (req, res) => {
  try {
    const {
      sessionId, customerId, customerPhone, customerEmail,
      items, subtotal, governorate,
    } = req.body;

    if (!sessionId) {
      return res.status(400).json({ message: 'sessionId مطلوب' });
    }

    // لو السلة فاضية نحذف أي سجل سابق ليها
    if (!Array.isArray(items) || items.length === 0) {
      await AbandonedCart.deleteOne({ sessionId });
      return res.json({ message: 'cart cleared' });
    }

    const doc = await AbandonedCart.findOneAndUpdate(
      { sessionId },
      {
        sessionId,
        customerId: customerId || null,
        customerPhone: customerPhone || null,
        customerEmail: customerEmail || null,
        items,
        subtotal: subtotal || 0,
        governorate: governorate || null,
        lastSeen: new Date(),
        recoveredAt: null,
      },
      { upsert: true, new: true }
    );

    res.json({ ok: true, id: doc._id });
  } catch (err) {
    console.error('abandonedCart upsert error:', err);
    res.status(500).json({ message: 'خطأ في الخادم' });
  }
};

// PUT /api/abandoned-carts/recover — لما يكمل أوردر حقيقي نحدد السلة كمتعافية
const markRecovered = async (req, res) => {
  try {
    const { sessionId } = req.body;
    if (!sessionId) return res.status(400).json({ message: 'sessionId مطلوب' });
    await AbandonedCart.findOneAndUpdate({ sessionId }, { recoveredAt: new Date() });
    res.json({ ok: true });
  } catch (err) {
    console.error('abandonedCart recover error:', err);
    res.status(500).json({ message: 'خطأ في الخادم' });
  }
};

// GET /api/abandoned-carts — للأدمن فقط
const getAbandonedCarts = async (req, res) => {
  try {
    const since = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);

    // جلب السلات مع populate بيانات العميل لو موجودة
    const carts = await AbandonedCart.find({
      createdAt: { $gte: since },
    })
      .populate('customerId', 'name email phone')
      .sort({ createdAt: -1 })
      .limit(500)
      .lean();

    // تنظيف وإثراء البيانات
    const enriched = carts.map(cart => {
      const customerInfo = cart.customerId;
      return {
        ...cart,
        // بيانات العميل المنظمة
        customerName: customerInfo?.name || null,
        customerEmail: cart.customerEmail || customerInfo?.email || null,
        customerPhone: cart.customerPhone || customerInfo?.phone || null,
        isGuest: !cart.customerId,
        // حساب وقت ترك السلة بشكل مقروء
        minutesSinceAbandoned: Math.round((Date.now() - new Date(cart.createdAt).getTime()) / 60000),
      };
    });

    res.json(enriched);
  } catch (err) {
    console.error('getAbandonedCarts error:', err);
    res.status(500).json({ message: 'خطأ في الخادم' });
  }
};

module.exports = { upsertAbandonedCart, markRecovered, getAbandonedCarts };