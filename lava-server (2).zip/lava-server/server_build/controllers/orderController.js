const Order = require('../models/Order');
const Product = require('../models/Product');
const Settings = require('../models/Settings');
const { get, set, invalidateProductCaches, CACHE_TTL, CACHE_KEYS } = require('../utils/cache');
const { uploadImageToCloudinary } = require('../utils/uploadToCloudinary');

const roundTwo = (value) => Math.round(Number(value || 0) * 100) / 100;

const calculateEffectiveProductPrice = (product, settings) => {
  const saleActive = settings?.showCountdownBar && settings?.saleEndDate && new Date(settings.saleEndDate).getTime() > Date.now();
  if (saleActive && product.salePrice != null && product.salePrice !== '' && Number(product.salePrice) < Number(product.price)) {
    return roundTwo(product.salePrice);
  }
  return roundTwo(product.price);
};

// ===== توليد كود ولاء عشوائي وفريد =====
const generateLoyaltyCode = (prefix) => {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let code = (prefix || 'LOYALTY') + '-';
  for (let i = 0; i < 8; i++) {
    code += chars[Math.floor(Math.random() * chars.length)];
  }
  return code;
};

// POST /api/orders  (عام - عميل مسجل أو ضيف)
const createOrder = async (req, res) => {
  try {
    // لو الطلب جه multipart/form-data (فيه اسكرين شوت تحويل)، البيانات بتكون جوا حقل data كنص JSON
    let orderData;
    if (req.body && typeof req.body.data === 'string') {
      try {
        orderData = JSON.parse(req.body.data);
      } catch (err) {
        return res.status(400).json({ message: 'بيانات الطلب غير صالحة' });
      }
    } else {
      orderData = { ...req.body };
    }

    if (req.user) {
      orderData.customerId = req.user._id;
      orderData.customerEmail = req.user.email;
    }

    if (!Array.isArray(orderData.items) || orderData.items.length === 0) {
      return res.status(400).json({ message: 'الطلب يجب أن يحتوي على عناصر صالحة' });
    }

    const settings = await Settings.findOne();

    // ===== التحقق من بيانات الدفع الإلكتروني (محفظة يدوية) =====
    const paymentMethod = orderData.paymentMethod === 'wallet' ? 'wallet' : 'cod';
    let walletPaymentData = null;

    if (paymentMethod === 'wallet') {
      const methods = settings?.paymentMethods || [];
      const chosenMethodId = orderData.walletPayment && orderData.walletPayment.methodId;
      const method = methods.find((m) => String(m._id) === String(chosenMethodId) && m.enabled);

      if (!method) {
        return res.status(400).json({ message: 'وسيلة الدفع المختارة غير متاحة' });
      }

      const senderPhone = (orderData.walletPayment && orderData.walletPayment.senderPhone) || '';
      const transferDate = (orderData.walletPayment && orderData.walletPayment.transferDate) || '';

      if (method.transferDetailsRequired && (!senderPhone.trim() || !transferDate.trim())) {
        return res.status(400).json({ message: 'من فضلك ادخل رقم التحويل وتاريخه' });
      }

      if (method.screenshotRequired && !req.file) {
        return res.status(400).json({ message: 'من فضلك ارفع صورة تأكيد التحويل' });
      }

      walletPaymentData = {
        methodId: String(method._id),
        methodName: (method.name && (method.name.ar || method.name.en)) || '',
        walletPhoneNumber: method.phoneNumber || '',
        senderPhone: senderPhone || null,
        transferDate: transferDate || null,
        screenshotUrl: null,
        screenshotPublicId: null,
        confirmed: false,
      };

      if (req.file) {
        const uploaded = await uploadImageToCloudinary(req.file.buffer, req.file.originalname, req.file.mimetype);
        walletPaymentData.screenshotUrl = uploaded.url;
        walletPaymentData.screenshotPublicId = uploaded.publicId || null;
      }
    }

    let expectedSubtotal = 0;
    const validatedItems = [];

    for (const item of orderData.items) {
      if (!item.productId || !item.variantId || !item.size || !item.quantity || Number(item.quantity) <= 0) {
        return res.status(400).json({ message: 'بيانات أحد عناصر الطلب غير كاملة أو غير صحيحة' });
      }

      const product = await Product.findById(item.productId);
      if (!product || (product.visibility || 'published') !== 'published') {
        return res.status(400).json({ message: 'أحد المنتجات في الطلب غير متاح حالياً' });
      }

      const variant = (product.variants || []).find(v =>
        String(v._id) === String(item.variantId) ||
        (v.id != null && String(v.id) === String(item.variantId))
      );
      if (!variant) {
        return res.status(400).json({ message: 'الفاريانت المحدد غير موجود' });
      }

      const canonicalVariantId = variant._id ? String(variant._id) : (variant.id != null ? String(variant.id) : null);
      if (!canonicalVariantId) {
        return res.status(400).json({ message: 'الفاريانت المحدد غير صالح' });
      }

      const sizeEntry = (variant.sizeStock || []).find(s => s.size === item.size);
      if (!sizeEntry || sizeEntry.stock < Number(item.quantity)) {
        return res.status(400).json({ message: `الكمية المطلوبة من منتج ${product.name?.en || product.name?.ar || 'unknown'} غير متوفرة` });
      }

      const effectivePrice = calculateEffectiveProductPrice(product, settings);
      const basePrice = roundTwo(product.price);

      const isBundleItem = !!item.isBundleItem;
      const bundleDiscount = isBundleItem ? Math.min(Math.max(Number(item.bundleDiscount || 0), 0), 80) : 0;

      let finalItemPrice;
      if (isBundleItem && bundleDiscount > 0) {
        finalItemPrice = roundTwo(basePrice * (1 - bundleDiscount / 100));
      } else {
        finalItemPrice = effectivePrice;
      }

      if (finalItemPrice < 0) {
        return res.status(400).json({ message: 'السعر المرسل غير صحيح، حاول مرة أخرى' });
      }

      const quantity = Number(item.quantity);
      const primaryImage = (product.images && product.images[0])
        ? (typeof product.images[0] === 'string' ? product.images[0] : (product.images[0].url || ''))
        : '';

      const validatedItem = {
        productId: item.productId,
        variantId: canonicalVariantId,
        size: item.size,
        price: finalItemPrice,
        originalPrice: basePrice,
        quantity,
        costPrice: Number(product.costPrice || 0),
        name: product.name || { ar: '', en: '' },
        productImage: primaryImage,
        isBundleItem,
        bundleDiscount,
      };

      if (variant.color) validatedItem.color = variant.color;
      if (variant.hex) validatedItem.colorHex = variant.hex;

      validatedItems.push(validatedItem);
      expectedSubtotal += finalItemPrice * quantity;
    }

    expectedSubtotal = roundTwo(expectedSubtotal);
    const shippingCost = roundTwo(orderData.shippingCost);
    const submittedSubtotal = roundTwo(orderData.subtotal);
    const submittedTotal = roundTwo(orderData.totalAmount);

    // ===== التحقق من الخصومات =====
    let discount = 0;
    let firstOrderDiscountApplied = false;

    // ===== التحقق من كود الولاء (مرة واحدة فقط للعميل) =====
    let loyaltyCodeApplied = false;
    let usedLoyaltyCode = null;

    if (req.user && orderData.discountType === 'loyalty_code' && orderData.discountCode) {
      const User = require('../models/User');
      const freshUser = await User.findById(req.user._id);

      if (freshUser) {
        const code = String(orderData.discountCode).trim().toUpperCase();
        const hasCode = (freshUser.loyaltyCodes || []).includes(code);
        const alreadyUsed = (freshUser.loyaltyCodesUsed || []).includes(code);

        if (hasCode && !alreadyUsed) {
          // حساب الخصم من إعدادات الولاء
          const lp = settings?.loyaltyProgram;
          if (lp && lp.enabled) {
            // لو الكود لمنتج معين، نتحقق إن المنتج ده في الطلب
            const specificProductId = lp.specificProductId;
            const specificProductInOrder = specificProductId
              ? validatedItems.some(it => String(it.productId) === String(specificProductId))
              : true;

            if (specificProductInOrder) {
              if (lp.rewardType === 'percentage') {
                discount = roundTwo(expectedSubtotal * (Number(lp.rewardValue) / 100));
              } else if (lp.rewardType === 'fixed') {
                discount = roundTwo(Math.min(Number(lp.rewardValue), expectedSubtotal));
              }
              loyaltyCodeApplied = true;
              usedLoyaltyCode = code;
            }
          }
        }
      }

    } else if (req.user && orderData.discountType === 'first_order') {
      const User = require('../models/User');
      const freshUser = await User.findById(req.user._id);
      const isEligible = freshUser && !freshUser.firstOrderDiscountUsed;

      if (isEligible) {
        const guestDiscount = settings?.promotions?.guestDiscount;
        const percentage = Number.isFinite(Number(guestDiscount?.percentage)) ? Number(guestDiscount.percentage) : 0;
        if (guestDiscount?.enabled && percentage > 0) {
          discount = roundTwo(expectedSubtotal * (percentage / 100));
          firstOrderDiscountApplied = true;
        }
      }

    } else {
      // خصم عادي (كود خصم أو عروض)
      discount = roundTwo(orderData.discount);
    }

    const expectedTotal = roundTwo(expectedSubtotal + shippingCost - discount);

    if (submittedTotal <= 0) {
      return res.status(400).json({ message: 'قيمة الطلب غير متطابقة مع الأسعار الحالية' });
    }

    const order = await Order.create({
      ...orderData,
      items: validatedItems,
      subtotal: expectedSubtotal,
      discount,
      totalAmount: expectedTotal,
      paymentMethod,
      walletPayment: walletPaymentData || undefined,
    });

    // تحديث المخزون
    for (const item of order.items) {
      const byMongoId = await Product.updateOne(
        { _id: item.productId, 'variants._id': item.variantId, 'variants.sizeStock.size': item.size },
        { $inc: { 'variants.$[v].sizeStock.$[s].stock': -item.quantity } },
        { arrayFilters: [{ 'v._id': String(item.variantId) }, { 's.size': item.size }] }
      );
      if (!byMongoId.modifiedCount) {
        await Product.updateOne(
          { _id: item.productId, 'variants.id': item.variantId, 'variants.sizeStock.size': item.size },
          { $inc: { 'variants.$[v].sizeStock.$[s].stock': -item.quantity } },
          { arrayFilters: [{ 'v.id': String(item.variantId) }, { 's.size': item.size }] }
        );
      }
    }

    invalidateProductCaches();

    // ===== تحديث firstOrderDiscountUsed =====
    if (firstOrderDiscountApplied && req.user) {
      const User = require('../models/User');
      await User.findByIdAndUpdate(req.user._id, { firstOrderDiscountUsed: true });
    }

    // ===== تحديث نظام الولاء =====
    if (req.user) {
      const User = require('../models/User');
      const freshUser = await User.findById(req.user._id);

      if (freshUser) {
        const updateFields = {};

        // وضّع كود الولاء المستخدم
        if (loyaltyCodeApplied && usedLoyaltyCode) {
          updateFields.$addToSet = { loyaltyCodesUsed: usedLoyaltyCode };
        }

        // زيّد عداد الطلبات
        const newCount = (freshUser.loyaltyOrderCount || 0) + 1;
        updateFields.$set = { loyaltyOrderCount: newCount };

        // تحقق إذا العميل وصل للعدد المطلوب واستحق مكافأة
        const lp = settings?.loyaltyProgram;
        if (lp && lp.enabled && lp.ordersRequired > 0) {
          const ordersRequired = Number(lp.ordersRequired);
          // بيستحق مكافأة كل ما يكمل العدد المطلوب (مثلاً كل 10 طلبات)
          if (newCount > 0 && newCount % ordersRequired === 0) {
            // ولّد كود جديد
            let newCode;
            let attempts = 0;
            do {
              newCode = generateLoyaltyCode(lp.codePrefix || 'LOYALTY');
              attempts++;
            } while (
              (freshUser.loyaltyCodes || []).includes(newCode) && attempts < 10
            );

            // أضف الكود لقايمة أكواده
            if (!updateFields.$addToSet) updateFields.$addToSet = {};
            updateFields.$addToSet.loyaltyCodes = newCode;

            // حفظ التحديثات
            await User.findByIdAndUpdate(req.user._id, updateFields);

            // أرجع كود المكافأة مع الاستجابة
            return res.status(201).json({
              ...order.toObject(),
              loyaltyReward: {
                earned: true,
                code: newCode,
                rewardType: lp.rewardType,
                rewardValue: lp.rewardValue,
                specificProductId: lp.specificProductId || null,
                title: lp.title,
                message: lp.message,
                orderCount: newCount,
              }
            });
          }
        }

        // حفظ التحديثات العادية
        await User.findByIdAndUpdate(req.user._id, updateFields);
      }
    }

    res.status(201).json(order);
  } catch (err) {
    console.error('Error creating order:', err);
    res.status(500).json({ message: 'حصل خطأ في إنشاء الطلب', error: err.message });
  }
};

// GET /api/orders  (أدمن / كول سنتر / باكر بس)
const getOrders = async (req, res) => {
  try {
    const cacheKey = 'orders:all';
    const cached = get(cacheKey);
    if (cached) {
      return res.json(cached);
    }

    const orders = await Order.find()
      .sort({ createdAt: -1 })
      .populate('customerId', 'name email phone')
      .lean();

    const enriched = await Promise.all(
      orders.map(async (order) => {
        const enrichedItems = await Promise.all(
          (order.items || []).map(async (item) => {
            try {
              const product = await Product.findById(item.productId).lean();
              if (!product) return item;

              const variant = (product.variants || []).find(v =>
                String(v._id) === String(item.variantId) ||
                String(v._id) === String(item.variantId?.toString?.() || item.variantId)
              );

              const productName = item.name && (item.name.ar || item.name.en) ? item.name : (product.name || {});
              const productImage = item.productImage || (product.images && product.images[0]
                ? (typeof product.images[0] === 'string' ? product.images[0] : (product.images[0].url || ''))
                : '');
              const colorInfo = item.color || (variant ? variant.color : null);
              const colorHex = item.colorHex || (variant ? variant.hex : null);

              return {
                ...item,
                productName,
                images: productImage ? [productImage] : (product.images || []),
                color: colorInfo,
                colorHex,
                size: item.size,
                isBundleItem: item.isBundleItem || false,
                bundleDiscount: item.bundleDiscount || 0,
                originalPrice: item.originalPrice || item.price,
              };
            } catch (err) {
              return item;
            }
          })
        );

        return { ...order, items: enrichedItems };
      })
    );

    set(cacheKey, enriched, 30);
    res.json(enriched);
  } catch (err) {
    console.error('Error fetching orders:', err);
    res.status(500).json({ message: 'حصل خطأ في جلب الطلبات', error: err.message });
  }
};

// GET /api/orders/mine  (عميل مسجل)
const getMyOrders = async (req, res) => {
  try {
    const orders = await Order.find({ customerId: req.user._id })
      .sort({ createdAt: -1 })
      .lean();
    res.json(orders);
  } catch (err) {
    console.error('Error fetching my orders:', err);
    res.status(500).json({ message: 'حصل خطأ في جلب طلباتك', error: err.message });
  }
};

// PUT /api/orders/:id/status  (أدمن / كول سنتر)
const updateOrderStatus = async (req, res) => {
  try {
    const order = await Order.findById(req.params.id);
    if (!order) {
      return res.status(404).json({ message: 'الطلب مش موجود' });
    }
    if (req.body.status) order.status = req.body.status;
    await order.save();
    require('../utils/cache').del('orders:all');
    res.json(order);
  } catch (err) {
    console.error('Error updating order status:', err);
    res.status(500).json({ message: 'حصل خطأ في تحديث حالة الطلب', error: err.message });
  }
};

// PUT /api/orders/:id/packer-status  (أدمن / باكر)
const updatePackerStatus = async (req, res) => {
  try {
    const order = await Order.findById(req.params.id);
    if (!order) {
      return res.status(404).json({ message: 'الطلب مش موجود' });
    }
    if (req.body.packerStatus) order.packerStatus = req.body.packerStatus;
    await order.save();
    require('../utils/cache').del('orders:all');
    res.json(order);
  } catch (err) {
    console.error('Error updating packer status:', err);
    res.status(500).json({ message: 'حصل خطأ في تحديث حالة التجهيز', error: err.message });
  }
};

// PUT /api/orders/:id/confirm-payment  (أدمن / كول سنتر - تأكيد استلام فلوس الدفع الإلكتروني)
const confirmWalletPayment = async (req, res) => {
  try {
    const order = await Order.findById(req.params.id);
    if (!order) {
      return res.status(404).json({ message: 'الطلب مش موجود' });
    }
    if (order.paymentMethod !== 'wallet') {
      return res.status(400).json({ message: 'الطلب ده مش مدفوع دفع إلكتروني' });
    }
    const confirmed = !!req.body.confirmed;
    order.walletPayment.confirmed = confirmed;
    order.walletPayment.confirmedAt = confirmed ? new Date() : null;
    await order.save();
    require('../utils/cache').del('orders:all');
    res.json(order);
  } catch (err) {
    console.error('Error confirming wallet payment:', err);
    res.status(500).json({ message: 'حصل خطأ في تأكيد الدفع', error: err.message });
  }
};

// GET /api/orders/loyalty-info  (عميل مسجل - يجيب بياناته في نظام الولاء)
const getLoyaltyInfo = async (req, res) => {
  try {
    const User = require('../models/User');
    const freshUser = await User.findById(req.user._id).select('loyaltyOrderCount loyaltyCodes loyaltyCodesUsed');
    if (!freshUser) return res.status(404).json({ message: 'المستخدم غير موجود' });

    const settings = await Settings.findOne();
    const lp = settings?.loyaltyProgram || {};

    const availableCodes = (freshUser.loyaltyCodes || []).filter(
      c => !(freshUser.loyaltyCodesUsed || []).includes(c)
    );

    res.json({
      orderCount: freshUser.loyaltyOrderCount || 0,
      ordersRequired: lp.ordersRequired || 10,
      availableCodes,
      usedCodes: freshUser.loyaltyCodesUsed || [],
      loyaltyEnabled: lp.enabled || false,
      rewardType: lp.rewardType || 'percentage',
      rewardValue: lp.rewardValue || 0,
      specificProductId: lp.specificProductId || null,
      nextRewardIn: lp.enabled && lp.ordersRequired
        ? lp.ordersRequired - ((freshUser.loyaltyOrderCount || 0) % lp.ordersRequired)
        : null,
    });
  } catch (err) {
    console.error('Error fetching loyalty info:', err);
    res.status(500).json({ message: 'حصل خطأ في جلب بيانات الولاء', error: err.message });
  }
};

// exports moved to bottom of file
// ============================================================
// GET /api/orders/payments-dashboard  (أدمن فقط)
// إحصائيات شاملة للمدفوعات
// ============================================================
const getPaymentsDashboard = async (req, res) => {
  try {
    const orders = await Order.find().lean();

    const stats = {
      totalRevenue: 0,
      pendingAmount: 0,
      failedAmount: 0,
      refundedAmount: 0,
      byCodAmount: 0,
      byWalletAmount: 0,

      totalOrders: orders.length,
      pendingCount: 0,
      failedCount: 0,
      refundedCount: 0,
      codCount: 0,
      walletCount: 0,

      // تفصيل وسائل الدفع الإلكتروني
      walletMethods: {},

      // إيصالات في انتظار المراجعة (wallet + مش confirmed)
      pendingProofReview: [],
    };

    for (const order of orders) {
      const amount = Number(order.totalAmount || 0);
      const payStatus = order.paymentStatus || 'pending';
      const payMethod = order.paymentMethod || 'cod';

      // إجمالي الإيرادات المؤكدة
      if (payStatus === 'paid' || (payMethod === 'cod' && order.status === 'تم التأكيد')) {
        stats.totalRevenue += amount;
      }

      // حسب حالة الدفع
      if (payStatus === 'pending') { stats.pendingAmount += amount; stats.pendingCount++; }
      if (payStatus === 'failed')  { stats.failedAmount += amount; stats.failedCount++; }
      if (payStatus === 'refunded') { stats.refundedAmount += amount; stats.refundedCount++; }

      // حسب وسيلة الدفع
      if (payMethod === 'cod') {
        stats.byCodAmount += amount;
        stats.codCount++;
      } else if (payMethod === 'wallet') {
        stats.byWalletAmount += amount;
        stats.walletCount++;

        // تفصيل الوسائل (InstaPay / VodafoneCash ...)
        const methodName = order.walletPayment?.methodName || 'أخرى';
        if (!stats.walletMethods[methodName]) {
          stats.walletMethods[methodName] = { count: 0, amount: 0 };
        }
        stats.walletMethods[methodName].count++;
        stats.walletMethods[methodName].amount += amount;

        // إيصالات في انتظار مراجعة
        if (order.walletPayment && !order.walletPayment.confirmed && order.walletPayment.screenshotUrl) {
          stats.pendingProofReview.push({
            _id: order._id,
            customerName: order.customerName,
            customerPhone: order.customerPhone,
            totalAmount: order.totalAmount,
            createdAt: order.createdAt,
            methodName,
            screenshotUrl: order.walletPayment.screenshotUrl,
            senderPhone: order.walletPayment.senderPhone,
            transferDate: order.walletPayment.transferDate,
            walletPhoneNumber: order.walletPayment.walletPhoneNumber,
          });
        }
      }
    }

    // تقريب الأرقام
    stats.totalRevenue = Math.round(stats.totalRevenue * 100) / 100;
    stats.pendingAmount = Math.round(stats.pendingAmount * 100) / 100;
    stats.failedAmount = Math.round(stats.failedAmount * 100) / 100;
    stats.refundedAmount = Math.round(stats.refundedAmount * 100) / 100;
    stats.byCodAmount = Math.round(stats.byCodAmount * 100) / 100;
    stats.byWalletAmount = Math.round(stats.byWalletAmount * 100) / 100;

    // ترتيب الإيصالات من الأحدث للأقدم
    stats.pendingProofReview.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

    res.json(stats);
  } catch (err) {
    console.error('Error fetching payments dashboard:', err);
    res.status(500).json({ message: 'حصل خطأ في جلب إحصائيات المدفوعات', error: err.message });
  }
};

// ============================================================
// GET /api/orders/shipping-dashboard  (أدمن فقط)
// إحصائيات شاملة للشحن
// ============================================================
const getShippingDashboard = async (req, res) => {
  try {
    const orders = await Order.find().lean();

    const stats = {
      pending: 0,
      preparing: 0,
      shipped: 0,
      delivered: 0,
      failedDelivery: 0,
      returned: 0,

      // توزيع شركات الشحن
      companies: {},

      // الطلبات اللي عندها مشاكل
      issues: [],

      // الطلبات المشحونة (عندها tracking)
      shippedOrders: [],
    };

    for (const order of orders) {
      const shippingStatus = order.shippingStatus || 'pending';

      switch (shippingStatus) {
        case 'pending':       stats.pending++;       break;
        case 'preparing':     stats.preparing++;     break;
        case 'shipped':       stats.shipped++;       break;
        case 'delivered':     stats.delivered++;     break;
        case 'failed_delivery': stats.failedDelivery++; break;
        case 'returned':      stats.returned++;      break;
      }

      // توزيع شركات الشحن
      if (order.shippingCompany) {
        if (!stats.companies[order.shippingCompany]) {
          stats.companies[order.shippingCompany] = { count: 0, delivered: 0, failed: 0 };
        }
        stats.companies[order.shippingCompany].count++;
        if (shippingStatus === 'delivered') stats.companies[order.shippingCompany].delivered++;
        if (shippingStatus === 'failed_delivery' || shippingStatus === 'returned') {
          stats.companies[order.shippingCompany].failed++;
        }
      }

      // مشاكل الشحن
      if (shippingStatus === 'failed_delivery' || shippingStatus === 'returned' || order.shippingNotes) {
        stats.issues.push({
          _id: order._id,
          customerName: order.customerName,
          customerPhone: order.customerPhone,
          governorate: order.governorate,
          shippingStatus,
          shippingCompany: order.shippingCompany,
          trackingNumber: order.trackingNumber,
          shippingNotes: order.shippingNotes,
          totalAmount: order.totalAmount,
          createdAt: order.createdAt,
        });
      }

      // الطلبات المشحونة مع tracking
      if (order.trackingNumber) {
        stats.shippedOrders.push({
          _id: order._id,
          customerName: order.customerName,
          customerPhone: order.customerPhone,
          governorate: order.governorate,
          shippingStatus,
          shippingCompany: order.shippingCompany,
          trackingNumber: order.trackingNumber,
          shippedAt: order.shippedAt,
          totalAmount: order.totalAmount,
        });
      }
    }

    stats.issues.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    stats.shippedOrders.sort((a, b) => new Date(b.shippedAt || 0) - new Date(a.shippedAt || 0));

    res.json(stats);
  } catch (err) {
    console.error('Error fetching shipping dashboard:', err);
    res.status(500).json({ message: 'حصل خطأ في جلب إحصائيات الشحن', error: err.message });
  }
};

// ============================================================
// PUT /api/orders/:id/shipping  (أدمن فقط)
// تحديث بيانات الشحن (شركة / tracking / حالة)
// ============================================================
const updateOrderShipping = async (req, res) => {
  try {
    const order = await Order.findById(req.params.id);
    if (!order) return res.status(404).json({ message: 'الطلب مش موجود' });

    const { shippingStatus, shippingCompany, trackingNumber, shippingNotes } = req.body;

    if (shippingStatus) order.shippingStatus = shippingStatus;
    if (shippingCompany !== undefined) order.shippingCompany = shippingCompany;
    if (trackingNumber !== undefined) order.trackingNumber = trackingNumber;
    if (shippingNotes !== undefined) order.shippingNotes = shippingNotes;

    // سجّل تواريخ تلقائية
    if (shippingStatus === 'shipped' && !order.shippedAt) order.shippedAt = new Date();
    if (shippingStatus === 'delivered' && !order.deliveredAt) order.deliveredAt = new Date();

    await order.save();
    require('../utils/cache').del('orders:all');
    res.json(order);
  } catch (err) {
    console.error('Error updating order shipping:', err);
    res.status(500).json({ message: 'حصل خطأ في تحديث بيانات الشحن', error: err.message });
  }
};

// ============================================================
// PUT /api/orders/:id/payment-status  (أدمن فقط)
// تحديث حالة الدفع (paid / failed / refunded)
// ============================================================
const updatePaymentStatus = async (req, res) => {
  try {
    const order = await Order.findById(req.params.id);
    if (!order) return res.status(404).json({ message: 'الطلب مش موجود' });

    const allowed = ['pending', 'paid', 'failed', 'refunded'];
    if (!allowed.includes(req.body.paymentStatus)) {
      return res.status(400).json({ message: 'حالة الدفع غير صحيحة' });
    }
    order.paymentStatus = req.body.paymentStatus;
    await order.save();
    require('../utils/cache').del('orders:all');
    res.json(order);
  } catch (err) {
    console.error('Error updating payment status:', err);
    res.status(500).json({ message: 'حصل خطأ في تحديث حالة الدفع', error: err.message });
  }
};

module.exports = {
  createOrder, getOrders, getMyOrders, updateOrderStatus, updatePackerStatus,
  getLoyaltyInfo, confirmWalletPayment,
  // ===== جديد =====
  getPaymentsDashboard, getShippingDashboard, updateOrderShipping, updatePaymentStatus,
};
