const TrafficEvent = require('../models/TrafficEvent');
const FunnelEvent  = require('../models/FunnelEvent');

// ─── ثوابت ────────────────────────────────────────────────────────────────
const SESSION_TIMEOUT_MS = 30 * 60 * 1000; // 30 دقيقة خمول

// ─── تحديد المصدر من الـ UTM أو الـ Referrer ──────────────────────────────
const detectSource = (utm_source, referrer) => {
  if (utm_source) {
    const s = utm_source.toLowerCase();
    if (s.includes('facebook') || s.includes('fb')) return 'facebook';
    if (s.includes('instagram') || s.includes('ig')) return 'instagram';
    if (s.includes('tiktok'))   return 'tiktok';
    if (s.includes('google')   || s.includes('adwords')) return 'google';
    if (s.includes('snapchat') || s.includes('snap'))    return 'snapchat';
    return utm_source.toLowerCase();
  }
  if (referrer) {
    const r = referrer.toLowerCase();
    if (r.includes('facebook.com') || r.includes('fb.com'))  return 'facebook';
    if (r.includes('instagram.com'))  return 'instagram';
    if (r.includes('tiktok.com'))     return 'tiktok';
    if (r.includes('google.com') || r.includes('google.'))   return 'google';
    if (r.includes('snapchat.com'))   return 'snapchat';
    if (r.includes('youtube.com'))    return 'youtube';
    if (r.includes('twitter.com') || r.includes('x.com'))    return 'twitter';
    return 'other';
  }
  return 'direct';
};

// ─── تحديد الجهاز من User-Agent ───────────────────────────────────────────
const detectDevice = (ua = '') => {
  if (!ua) return 'unknown';
  if (/tablet|ipad/i.test(ua))                   return 'tablet';
  if (/mobile|android|iphone|ipod/i.test(ua))    return 'mobile';
  return 'desktop';
};

// ══════════════════════════════════════════════════════════════════════════
// POST /api/traffic/visit  — session_start
// الفرونت هو اللي بيقرر لو الـ session جديدة (بناءً على lastActivity في localStorage)
// البكند بيسجّل بدون dedup — كل sessionId جديد = record جديد
// ══════════════════════════════════════════════════════════════════════════
const recordVisit = async (req, res) => {
  try {
    const {
      visitorId, sessionId,
      utm_source, utm_medium, utm_campaign, utm_term, utm_content,
      referrer, page,
    } = req.body;

    if (!visitorId || !sessionId) {
      return res.status(400).json({ message: 'visitorId و sessionId مطلوبان' });
    }

    // تحقق: هل الـ sessionId ده موجود أصلاً (حماية من duplicate في حالة network retry)
    const existing = await TrafficEvent.findOne({ sessionId }).select('_id').lean();
    if (existing) return res.json({ ok: true, duplicate: true });

    const source = detectSource(utm_source, referrer);
    const device = detectDevice(req.headers['user-agent']);

    await TrafficEvent.create({
      visitorId,
      sessionId,
      source,
      utm_source:   utm_source   || null,
      utm_medium:   utm_medium   || null,
      utm_campaign: utm_campaign || null,
      utm_term:     utm_term     || null,
      utm_content:  utm_content  || null,
      referrer:     referrer     || null,
      landingPage:  page || '/',
      page:         page || '/',
      device,
      lastActivity: new Date(),
      converted: false,
    });

    // سجّل أول خطوة في الـ funnel تلقائياً
    await FunnelEvent.updateOne(
      { sessionId, step: 'visit' },
      { $setOnInsert: { visitorId, sessionId, step: 'visit' } },
      { upsert: true }
    );

    res.json({ ok: true });
  } catch (err) {
    if (err.code === 11000) return res.json({ ok: true, duplicate: true });
    console.error('recordVisit error:', err);
    res.status(500).json({ message: 'خطأ في الخادم' });
  }
};

// ══════════════════════════════════════════════════════════════════════════
// POST /api/traffic/pageview  — page_view (navigation داخل نفس الـ session)
// ══════════════════════════════════════════════════════════════════════════
const recordPageView = async (req, res) => {
  try {
    const { sessionId, page, visitorId } = req.body;
    if (!sessionId) return res.status(400).json({ message: 'sessionId مطلوب' });

    // upsert: لو الـ session_start الأصلية فشلت لأي سبب (سيرفر واقف وقتها،
    // مشكلة شبكة مؤقتة...) بنضمن على الأقل إن الزيارة تتسجل من هنا بدل ما
    // تتفقد بالكامل - أفضل من findOneAndUpdate عادي اللي كان بيعمل no-op
    // صامت لو الـ TrafficEvent مش موجود أصلاً.
    await TrafficEvent.findOneAndUpdate(
      { sessionId },
      {
        $inc: { pageViewCount: 1 },
        $set: { page: page || '/', lastActivity: new Date() },
        $setOnInsert: {
          visitorId: visitorId || sessionId,
          source: 'direct',
          landingPage: page || '/',
        },
      },
      { sort: { createdAt: -1 }, upsert: true }
    );

    res.json({ ok: true });
  } catch (err) {
    console.error('recordPageView error:', err);
    res.status(500).json({ message: 'خطأ في الخادم' });
  }
};

// ══════════════════════════════════════════════════════════════════════════
// PUT /api/traffic/convert
// ══════════════════════════════════════════════════════════════════════════
const markConverted = async (req, res) => {
  try {
    const { sessionId, orderId, orderAmount, visitorId } = req.body;
    if (!sessionId) return res.status(400).json({ message: 'sessionId مطلوب' });

    // upsert دفاعي: لو الـ session دي أصلاً متسجلتش (session_start فشلت)،
    // برضو لازم نسجّل إن الأوردر ده جه من زيارة حقيقية بدل ما نضيّع الربط
    // بين الأوردر ومصدر الزيارة بالكامل.
    await TrafficEvent.findOneAndUpdate(
      { sessionId },
      {
        $set: { converted: true, orderId: orderId || null, orderAmount: orderAmount || null, lastActivity: new Date() },
        $setOnInsert: { visitorId: visitorId || sessionId, source: 'direct' },
      },
      { sort: { createdAt: -1 }, upsert: true }
    );

    res.json({ ok: true });
  } catch (err) {
    console.error('markConverted error:', err);
    res.status(500).json({ message: 'خطأ في الخادم' });
  }
};

// ══════════════════════════════════════════════════════════════════════════
// POST /api/traffic/funnel  — خطوات الفانيل
// ══════════════════════════════════════════════════════════════════════════
const recordFunnelStep = async (req, res) => {
  try {
    const { visitorId, sessionId, step } = req.body;
    const validSteps = ['visit', 'product_view', 'add_to_cart', 'checkout', 'purchase'];
    if (!sessionId || !validSteps.includes(step)) {
      return res.status(400).json({ message: 'sessionId أو step غير صحيح' });
    }

    await FunnelEvent.updateOne(
      { sessionId, step },
      { $setOnInsert: { visitorId: visitorId || sessionId, sessionId, step } },
      { upsert: true }
    );

    // حدّث lastActivity في الـ TrafficEvent
    if (['add_to_cart', 'checkout', 'purchase'].includes(step)) {
      await TrafficEvent.findOneAndUpdate(
        { sessionId },
        { $set: { lastActivity: new Date() } },
        { sort: { createdAt: -1 } }
      );
    }

    res.json({ ok: true });
  } catch (err) {
    if (err.code === 11000) return res.json({ ok: true, duplicate: true });
    console.error('recordFunnelStep error:', err);
    res.status(500).json({ message: 'خطأ في الخادم' });
  }
};

// ══════════════════════════════════════════════════════════════════════════
// GET /api/traffic/stats
// ══════════════════════════════════════════════════════════════════════════
const getStats = async (req, res) => {
  try {
    const days  = parseInt(req.query.days) || 30;
    const since = new Date(Date.now() - days * 24 * 60 * 60 * 1000);

    // ─── Traffic events ────────────────────────────────────────────────
    const events = await TrafficEvent.find({ createdAt: { $gte: since } }).lean();

    const sourceMap = {};
    const dailyMap  = {};

    for (const e of events) {
      const src = e.source || 'direct';
      if (!sourceMap[src]) {
        sourceMap[src] = { visitors: new Set(), sessions: new Set(), orders: 0, revenue: 0 };
      }
      sourceMap[src].visitors.add(e.visitorId || e.sessionId);
      sourceMap[src].sessions.add(e.sessionId);
      if (e.converted) {
        sourceMap[src].orders++;
        sourceMap[src].revenue += e.orderAmount || 0;
      }

      const day = e.createdAt.toISOString().slice(0, 10);
      if (!dailyMap[day]) dailyMap[day] = { visitors: new Set(), sessions: 0, orders: 0, revenue: 0 };
      dailyMap[day].visitors.add(e.visitorId || e.sessionId);
      dailyMap[day].sessions++;
      if (e.converted) {
        dailyMap[day].orders++;
        dailyMap[day].revenue += e.orderAmount || 0;
      }
    }

    // Unique visitors = unique visitorId  |  Sessions = unique sessionId
    const totalVisitors = new Set(events.map(e => e.visitorId || e.sessionId)).size;
    const totalSessions = new Set(events.map(e => e.sessionId)).size;
    const totalPageViews = events.reduce((sum, e) => sum + (e.pageViewCount || 1), 0);
    const totalOrders   = events.filter(e => e.converted).length;
    const totalRevenue  = Math.round(events.filter(e => e.converted).reduce((s, e) => s + (e.orderAmount || 0), 0));

    const bySource = Object.entries(sourceMap).map(([source, data]) => ({
      source,
      visitors:       data.visitors.size,
      visits:         data.sessions.size,   // للتوافق مع الـ UI القديم
      orders:         data.orders,
      revenue:        Math.round(data.revenue),
      conversionRate: data.visitors.size > 0
        ? ((data.orders / data.visitors.size) * 100).toFixed(1)
        : '0.0',
      revenuePerVisit: data.visitors.size > 0
        ? Math.round(data.revenue / data.visitors.size)
        : 0,
    })).sort((a, b) => b.visitors - a.visitors);

    const deviceMap = {};
    for (const e of events) {
      const d = e.device || 'unknown';
      deviceMap[d] = (deviceMap[d] || 0) + 1;
    }

    const daily = Object.entries(dailyMap)
      .sort(([a], [b]) => a.localeCompare(b))
      .map(([date, data]) => ({
        date,
        visits:  data.sessions,
        visitors: data.visitors.size,
        orders:  data.orders,
        revenue: Math.round(data.revenue),
      }));

    // ─── Funnel ────────────────────────────────────────────────────────
    const STEPS = ['visit', 'product_view', 'add_to_cart', 'checkout', 'purchase'];
    const funnelCounts = await FunnelEvent.aggregate([
      { $match: { createdAt: { $gte: since } } },
      {
        $group: {
          _id: '$step',
          uniqueVisitors: { $addToSet: '$visitorId' },
          uniqueSessions: { $addToSet: '$sessionId' },
        },
      },
      {
        $project: {
          step:     '$_id',
          visitors: { $size: '$uniqueVisitors' },
          sessions: { $size: '$uniqueSessions' },
          _id: 0,
        },
      },
    ]);

    const funnelMap = {};
    for (const r of funnelCounts) funnelMap[r.step] = { visitors: r.visitors, sessions: r.sessions };

    const topVisitors = funnelMap['visit']?.visitors || 1;

    const funnel = STEPS.map((step, i) => {
      const curr = funnelMap[step]?.visitors || 0;
      const prev = i === 0 ? curr : (funnelMap[STEPS[i - 1]]?.visitors || 0);
      return {
        step,
        count:       curr,
        sessions:    funnelMap[step]?.sessions || 0,
        dropoffRate: prev > 0 ? (((prev - curr) / prev) * 100).toFixed(1) : '0.0',
        convFromTop: topVisitors > 0 ? ((curr / topVisitors) * 100).toFixed(1) : '0.0',
      };
    });

    res.json({
      summary: {
        totalVisitors,   // ← unique visitorId
        totalSessions,   // ← unique sessionId
        totalPageViews,
        totalOrders,
        totalRevenue,
        overallConversionRate: totalVisitors > 0
          ? ((totalOrders / totalVisitors) * 100).toFixed(1)
          : '0.0',
      },
      bySource,
      byDevice: Object.entries(deviceMap).map(([device, count]) => ({ device, count })),
      daily,
      funnel,
      days,
    });
  } catch (err) {
    console.error('getStats error:', err);
    res.status(500).json({ message: 'خطأ في الخادم' });
  }
};

module.exports = { recordVisit, recordPageView, markConverted, recordFunnelStep, getStats };