// ===== قائمة أسباب الاسترجاع الموحّدة (Customer-facing) =====
// كل سبب له كود ثابت (بيتخزن في الطلب) ونص عربي/إنجليزي للعرض، وفلاج
// feeApplies بيحدد هل العميل بيتحمل رسوم شحن الاسترجاع ولا المتجر.
//
// - أسباب بسبب المتجر (عيب في المنتج / استلم منتج غلط) => مجاني بالكامل،
//   المتجر بيتحمل تكلفة شحن الاسترجاع.
// - أسباب باختيار العميل (مقاس مش مظبوط / غيّر رأيه / سبب تاني) => العميل
//   بيتحمل رسوم شحن الاسترجاع (المبلغ نفسه في Settings.returnFeeAmount).
//
// ملحوظة مهمة: نفس الأكواد (code) دي لازم تفضل متطابقة تمامًا مع القايمة
// المكررة في الفرونت (lava-client/src/App.jsx - RETURN_REASONS) عشان القيمة
// اللي العميل يختارها تتقبل من السيرفر. لو حبيت تضيف سبب جديد، ضيفه هنا
// وهناك بنفس الـ code بالظبط.
const RETURN_REASONS = [
  { code: 'defective', ar: 'المنتج فيه عيب / وصل تالف', en: 'Item is defective / arrived damaged', feeApplies: false },
  { code: 'wrong_item', ar: 'استلمت منتج مختلف عن اللي طلبته', en: 'Received a different item than ordered', feeApplies: false },
  { code: 'wrong_size', ar: 'المقاس مش مظبوط', en: 'Wrong size', feeApplies: true },
  { code: 'changed_mind', ar: 'غيرت رأيي / مش عاجبني المنتج', en: 'Changed my mind / not what I expected', feeApplies: true },
  { code: 'other', ar: 'سبب تاني', en: 'Other reason', feeApplies: true },
];

const RETURN_REASON_CODES = RETURN_REASONS.map((r) => r.code);

const isValidReasonCode = (code) => RETURN_REASON_CODES.includes(code);

// هل السبب ده بيستوجب رسوم شحن استرجاع على العميل؟
// لو الكود مش معروف (null/فاضي/قيمة قديمة قبل ما الميزة دي تتضاف)، بنتعامل
// معاه كـ "بيستوجب رسوم" fail-safe عشان منفوتش رسوم كان المفروض تتحصل، والأدمن
// دايمًا يقدر يشيل الرسوم يدويًا وقت المراجعة لو شاف إن السبب فعلاً عيب.
const doesReasonApplyFee = (code) => {
  const found = RETURN_REASONS.find((r) => r.code === code);
  return found ? found.feeApplies : true;
};

module.exports = { RETURN_REASONS, RETURN_REASON_CODES, isValidReasonCode, doesReasonApplyFee };