const Order = require('../models/Order');
const Product = require('../models/Product');
const Settings = require('../models/Settings');
const { get, set, invalidateProductCaches, CACHE_TTL, CACHE_KEYS } = require('../utils/cache');
const { uploadImageToCloudinary, deleteImageFromCloudinary } = require('../utils/uploadToCloudinary');
const {
  decrementOrderItems,
  restoreOrderItems,
  logMovement,
  logMovementsBulk,
} = require('../utils/inventory');
const { parsePagination, buildListResponse } = require('../utils/pagination');
const { buildPaymentUrl, isConfigured: isKashierConfigured, refundPayment: refundKashierPayment, getOrderStatus: getKashierOrderStatus } = require('../services/kashierService');
const { createPaymentIntention: createPaymobIntention, isConfigured: isPaymobConfigured, refundPayment: refundPaymobPayment, getTransactionStatus: getPaymobTransactionStatus } = require('../services/paymobService');
// ملحوظة إصلاح: كان بيستخدم موديل ShippingProvider (Mongo collection) ودالة
// getProvider(key).getRate(...) غير موجودة أصلاً في services/shipping. الموديل
// ده معملوش عليه أي route يكتب فيه بيانات (Dead/Orphaned model) وبالتالي
// findOne كان يرجع null دايمًا، والدالة getRate مكنتش موجودة أصلاً (كانت
// هتعمل crash لو الشرط اتحقق). الكود اتشال ومكانه استخدام نظام الشحن
// الحقيقي الشغال فعليًا في services/shipping (نفس اللي بيستخدمه /api/shipping).
const { publicConfig, rates: getShippingRates, createShipmentForOrder, getCapabilities } = require('../services/shipping');
// ===== Phase 2: تحقق موحّد من رقم الهاتف المصري + بيانات العنوان الأساسية =====
// نفس الدالة مستخدمة هنا وفي authController (حفظ عنوان الحساب) - مصدر واحد
// للتحقق، مش خاص بشركة شحن معينة (شوف utils/addressValidation.js).
const { validateEgyptianPhone, validateCoreAddress } = require('../utils/addressValidation');
// ===== قائمة أسباب الاسترجاع الموحّدة + هل السبب بيستوجب رسوم شحن استرجاع =====
const { isValidReasonCode, doesReasonApplyFee } = require('../utils/returnReasons');

// أقصى كمية منطقية للعنصر الواحد في الطلب (حماية من قيم غير منطقية/هجومية)
const MAX_ITEM_QUANTITY = 1000;

// كمية صحيحة (integer) وأكبر من صفر وأقل من الحد الأقصى المنطقي
const isValidQuantity = (q) => Number.isInteger(q) && q > 0 && q <= MAX_ITEM_QUANTITY;

// حالات الطلب اللي معناها "الطلب اتلغى/اترفض/رجع" وبالتالي لازم يرجع المخزون
const STOCK_RESTORING_STATUSES = new Set(['ملغي', 'Cancelled', 'مرتجع', 'Returned']);

const roundTwo = (value) => Math.round(Number(value || 0) * 100) / 100;

const calculateEffectiveProductPrice = (product, settings) => {
  // لازم نفس أولوية حساب السعر المستخدمة في الفرونت (getEffectivePrice في App.jsx):
  // 1) خصم العداد التنازلي (onSale + salePrice) لو العداد شغال فعلاً
  // 2) خصم دائم ثابت (permanentSalePrice) — مستقل عن العداد، وكان ناقص هنا
  //    وده اللي كان بيخلي الطلب يتحسب بالسعر الأصلي كامل في Kashier حتى لو
  //    الموقع نفسه كان عارض السعر بعد الخصم الدائم.
  // 3) السعر الأصلي
  const saleActive = settings?.showCountdownBar && settings?.saleEndDate && new Date(settings.saleEndDate).getTime() > Date.now();
  if (saleActive && product.onSale && product.salePrice != null && product.salePrice !== '' && Number(product.salePrice) < Number(product.price)) {
    return roundTwo(product.salePrice);
  }
  if (product.permanentSalePrice != null && product.permanentSalePrice !== '' && Number(product.permanentSalePrice) > 0 && Number(product.permanentSalePrice) < Number(product.price)) {
    return roundTwo(product.permanentSalePrice);
  }
  return roundTwo(product.price);
};

// ===== حساب سعر الشحن سيرفر-سايد من إعدادات المتجر (مش من قيمة العميل) =====
// نفس المنطق المستخدم في الفرونت (calculateCartTotals): لو السلة وصلت لحد الشحن
// المجاني يبقى الشحن صفر، وإلا بنجيب سعر المحافظة المطابقة، وإلا نرجع لسعر الشحن الافتراضي.
const computeShippingCost = (settings, governorateName, subtotal) => {
  const freeThreshold = Number.isFinite(Number(settings?.freeShippingThreshold))
    ? Number(settings.freeShippingThreshold)
    : 1500;

  if (subtotal >= freeThreshold) return 0;

  const governorates = Array.isArray(settings?.governorates) ? settings.governorates : [];
  const name = String(governorateName || '').trim();
  const gov = name
    ? governorates.find((g) => g?.name?.ar === name || g?.name?.en === name)
    : null;

  if (gov && Number.isFinite(Number(gov.cost))) {
    return roundTwo(gov.cost);
  }

  const defaultCost = Number.isFinite(Number(settings?.defaultShippingCost))
    ? Number(settings.defaultShippingCost)
    : 90;
  return roundTwo(defaultCost);
};

// ===== توليد كود ولاء عشوائي وفريد =====
const generateLoyaltyCode = (prefix) => {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let code = (prefix || 'LOYALTY') + '-';
  for (let i = 0; i < 8; i++) {
    code += chars[Math.floor(Math.random() * chars.length)];
  }
  return code;
};

// POST /api/orders  (عام - عميل مسجل أو ضيف)
const createOrder = async (req, res) => {
  let uploadedScreenshot = null;
  try {
    // لو الطلب جه multipart/form-data (فيه اسكرين شوت تحويل)، البيانات بتكون جوا حقل data كنص JSON
    let orderData;
    if (req.body && typeof req.body.data === 'string') {
      try {
        orderData = JSON.parse(req.body.data);
      } catch (err) {
        return res.status(400).json({ message: 'بيانات الطلب غير صالحة' });
      }
    } else {
      orderData = { ...req.body };
    }

    if (req.user) {
      orderData.customerId = req.user._id;
      orderData.customerEmail = req.user.email;
    }

    if (!Array.isArray(orderData.items) || orderData.items.length === 0) {
      return res.status(400).json({ message: 'الطلب يجب أن يحتوي على عناصر صالحة' });
    }

    // ============================================================
    // ===== Phase 2: تحقق سيرفر-سايد إلزامي من الهاتف وبيانات العنوان =====
    // ده تحقق authoritative (السيرفر هو المصدر الحقيقي) - بغض النظر عن أي
    // تحقق تم في الفرونت. بيرفض أرقام زي "11" قبل ما يوصل لأي حاجة تانية
    // (خصم مخزون / إنشاء طلب / إنشاء شحنة). التحقق ده عام لكل شركات الشحن،
    // مش خاص ببوسطة (شوف utils/addressValidation.js).
    // الحقول الإضافية (district/buildingNumber/floor/apartment/landmark) لو
    // اتبعتت جوه shippingAddress بتتقبل زي ما هي من غير إلزام هنا - كل شركة
    // شحن هتتأكد من احتياجاتها الدقيقة بنفسها وقت إنشاء الشحنة (Phase 3).
    // ============================================================
    const incomingShippingAddress = (orderData.shippingAddress && typeof orderData.shippingAddress === 'object')
      ? orderData.shippingAddress
      : {};

    const phoneCheck = validateEgyptianPhone(orderData.customerPhone, { label: 'رقم الهاتف' });
    if (!phoneCheck.ok) {
      return res.status(400).json({ message: phoneCheck.message });
    }
    if (orderData.customerPhone2) {
      const phone2Check = validateEgyptianPhone(orderData.customerPhone2, { required: false, label: 'رقم الهاتف الإضافي' });
      if (!phone2Check.ok) {
        return res.status(400).json({ message: phone2Check.message });
      }
    }

    const coreAddressCheck = validateCoreAddress({
      fullName: orderData.customerName,
      phone: orderData.customerPhone,
      governorate: orderData.governorate,
      detailedAddress: orderData.address,
    });
    if (!coreAddressCheck.ok) {
      return res.status(400).json({ message: `بيانات الشحن ناقصة: ${coreAddressCheck.missing.join('، ')}` });
    }

    const settings = await Settings.findOne();
    // ملحوظة: الفرونت بيبعت اختيار العميل لشركة الشحن في حقل اسمه
    // "shippingProviderId" (راجع src/App.jsx و src/api/orders.js) مش
    // "shippingProvider"، فكان الشرط القديم "if (shippingProviderKey)"
    // متحققش عمليًا خالص وده سبب إضافي إن الكود القديم كان Dead Code.
    // بنقرأ الحقل الصح هنا، ونتحقق منه على نظام الشحن الحقيقي (env-based
    // providers في services/shipping) بدل موديل Mongo يتيم.
    const shippingProviderKey = String(orderData.shippingProviderId || orderData.shippingProvider || '').trim().toLowerCase();
    if (shippingProviderKey) {
      const providersConfig = publicConfig();
      const providerInfo = providersConfig[shippingProviderKey];
      if (!providerInfo || !providerInfo.enabled) {
        return res.status(400).json({ message: 'شركة الشحن المختارة غير متاحة حاليًا' });
      }
      const countryCode = String(orderData.shippingCountryCode || '').toUpperCase();
      if (countryCode && providerInfo.countries?.length && !providerInfo.countries.includes(countryCode)) {
        return res.status(400).json({ message: 'شركة الشحن المختارة لا تخدم دولة التوصيل' });
      }
      // بنخزن اختيار العميل في shippingCompany (نفس الحقل اللي بيستخدمه
      // shippingController بعد إنشاء الشحنة فعليًا) عشان منعملش تعارض مع
      // shippingProviderId اللي معناه الحقيقي في الـSchema هو "رقم الشحنة
      // من شركة الشحن نفسها" بعد إنشائها (مش اختيار العميل قبل الطلب).
      orderData.shippingCompany = shippingProviderKey;
    }


    // ===== التحقق من طريقة الدفع =====
    // codEnabled يتحكم في الدفع عند الاستلام بشكل مستقل.
    // manualEnabled يتحكم في وسائل الدفع اليدوية (محافظ/إنستاباي) فقط.
    // Kashier له مفتاح مستقل ويحوّل العميل إلى صفحة الدفع المستضافة خارج الموقع.
    const paymentSettings = settings?.paymentSettings || { manualEnabled: true, codEnabled: true, kashierEnabled: false, paymobEnabled: false };
    const requestedPaymentMethod = String(orderData.paymentMethod || 'cod').toLowerCase();
    const paymentMethod = ['cod', 'wallet', 'kashier', 'paymob'].includes(requestedPaymentMethod) ? requestedPaymentMethod : 'cod';
    let walletPaymentData = null;

    // اختياري بالكامل: لو العميل اختار من موقعك وسيلة فرعية محددة جوه Kashier
    // أو Paymob (مثلاً "كارت" أو "محفظة")، بيوصل هنا كـ gatewaySubMethod.
    // لو مبعتش أو قيمة غير معروفة، بيتجاهل تمامًا وكل حاجة تشتغل زي القديم
    // (صفحة الدفع بتعرض كل الوسائل المتاحة على الحساب).
    const requestedSubMethod = String(orderData.gatewaySubMethod || '').trim().toLowerCase();
    const gatewaySubMethod = ['card', 'wallet'].includes(requestedSubMethod) ? requestedSubMethod : null;

    if (paymentMethod === 'cod' && paymentSettings.codEnabled === false) {
      return res.status(400).json({ message: 'الدفع عند الاستلام غير متاح حالياً' });
    }

    // ===== الدفع عند الاستلام (COD) + شركة الشحن =====
    // مش كل شركات الشحن بتدعم COD فعليًا عبر الـAPI (مثلاً DHL في المشروع
    // ده حاليًا مفيش لها تنفيذ COD موثّق - راجع services/shipping/
    // capabilities.js). لو سمحنا بطلب COD مع شركة زي دي، الشحنة هتتعمل
    // "مدفوعة مقدمًا" عند شركة الشحن من غير ما تعرف إنها المفروض تحصّل
    // فلوس من العميل - يعني نقص فعلي في الفلوس عند التسليم. فبنمنع
    // التوليفة دي من الأساس وقت إنشاء الطلب نفسه (مش بس وقت إنشاء الشحنة).
    if (paymentMethod === 'cod' && shippingProviderKey) {
      const providerCaps = getCapabilities(shippingProviderKey);
      if (providerCaps && providerCaps.supportsCOD !== true) {
        return res.status(400).json({ message: 'شركة الشحن المختارة لا تدعم الدفع عند الاستلام - برجاء اختيار وسيلة دفع أخرى أو شركة شحن مختلفة' });
      }
    }

    if (paymentMethod === 'wallet') {
      if (paymentSettings.manualEnabled !== true) {
        return res.status(400).json({ message: 'الدفع اليدوي غير متاح حالياً' });
      }
      
      const methods = settings?.paymentMethods || [];
      const chosenMethodId = orderData.walletPayment && orderData.walletPayment.methodId;
      const method = methods.find((m) => String(m._id) === String(chosenMethodId) && m.enabled);

      if (!method) {
        return res.status(400).json({ message: 'وسيلة الدفع المختارة غير متاحة' });
      }

      const senderPhone = (orderData.walletPayment && orderData.walletPayment.senderPhone) || '';
      const transferDate = (orderData.walletPayment && orderData.walletPayment.transferDate) || '';

      if (method.transferDetailsRequired && (!senderPhone.trim() || !transferDate.trim())) {
        return res.status(400).json({ message: 'من فضلك ادخل رقم التحويل وتاريخه' });
      }

      if (method.screenshotRequired && !req.file) {
        return res.status(400).json({ message: 'من فضلك ارفع صورة تأكيد التحويل' });
      }

      walletPaymentData = {
        methodId: String(method._id),
        methodName: (method.name && (method.name.ar || method.name.en)) || '',
        walletPhoneNumber: method.phoneNumber || '',
        senderPhone: senderPhone || null,
        transferDate: transferDate || null,
        screenshotUrl: null,
        screenshotPublicId: null,
        confirmed: false,
      };

      if (req.file) {
        const uploaded = await uploadImageToCloudinary(req.file.buffer, req.file.safeOriginalName || req.file.originalname, req.file.detectedMime || req.file.mimetype, { folder: 'payment-screenshots' });
        walletPaymentData.screenshotUrl = uploaded.url;
        walletPaymentData.screenshotPublicId = uploaded.publicId || null;
      }
    }

    if (paymentMethod === 'kashier') {
      if (paymentSettings.kashierEnabled !== true) {
        return res.status(400).json({ message: 'الدفع الإلكتروني عبر Kashier غير متاح حالياً' });
      }
      if (!isKashierConfigured()) {
        return res.status(503).json({ message: 'Kashier غير مُعد على السيرفر. أضف مفاتيح Kashier إلى .env أولاً.' });
      }
    }

    if (paymentMethod === 'paymob') {
      if (paymentSettings.paymobEnabled !== true) {
        return res.status(400).json({ message: 'الدفع الإلكتروني عبر Paymob غير متاح حالياً' });
      }
      if (!isPaymobConfigured()) {
        return res.status(503).json({ message: 'Paymob غير مُعد على السيرفر. أضف مفاتيح Paymob إلى .env أولاً.' });
      }
    }

    let expectedSubtotal = 0;
    const validatedItems = [];

    for (const item of orderData.items) {
      const parsedQuantity = Number(item.quantity);
      if (!item.productId || !item.variantId || !item.size || !isValidQuantity(parsedQuantity)) {
        return res.status(400).json({ message: 'بيانات أحد عناصر الطلب غير كاملة أو غير صحيحة' });
      }

      const product = await Product.findById(item.productId);
      if (!product || (product.visibility || 'published') !== 'published') {
        return res.status(400).json({ message: 'أحد المنتجات في الطلب غير متاح حالياً' });
      }

      const variant = (product.variants || []).find(v =>
        String(v._id) === String(item.variantId) ||
        (v.id != null && String(v.id) === String(item.variantId))
      );
      if (!variant) {
        return res.status(400).json({ message: 'الفاريانت المحدد غير موجود' });
      }

      const canonicalVariantId = variant._id ? String(variant._id) : (variant.id != null ? String(variant.id) : null);
      if (!canonicalVariantId) {
        return res.status(400).json({ message: 'الفاريانت المحدد غير صالح' });
      }

      const sizeEntry = (variant.sizeStock || []).find(s => s.size === item.size);
      if (!sizeEntry || sizeEntry.stock < Number(item.quantity)) {
        return res.status(400).json({ message: `الكمية المطلوبة من منتج ${product.name?.en || product.name?.ar || 'unknown'} غير متوفرة` });
      }

      const effectivePrice = calculateEffectiveProductPrice(product, settings);
      const basePrice = roundTwo(product.price);

      const isBundleItem = !!item.isBundleItem;
      const bundleDiscount = isBundleItem ? Math.min(Math.max(Number(item.bundleDiscount || 0), 0), 80) : 0;

      let finalItemPrice;
      if (isBundleItem && bundleDiscount > 0) {
        finalItemPrice = roundTwo(basePrice * (1 - bundleDiscount / 100));
      } else {
        finalItemPrice = effectivePrice;
      }

      if (finalItemPrice < 0) {
        return res.status(400).json({ message: 'السعر المرسل غير صحيح، حاول مرة أخرى' });
      }

      const quantity = Number(item.quantity);
      const primaryImage = (product.images && product.images[0])
        ? (typeof product.images[0] === 'string' ? product.images[0] : (product.images[0].url || ''))
        : '';

      const validatedItem = {
        productId: item.productId,
        variantId: canonicalVariantId,
        size: item.size,
        price: finalItemPrice,
        originalPrice: basePrice,
        quantity,
        costPrice: Number(product.costPrice || 0),
        name: product.name || { ar: '', en: '' },
        productImage: primaryImage,
        isBundleItem,
        bundleDiscount,
      };

      if (variant.color) validatedItem.color = variant.color;
      if (variant.hex) validatedItem.colorHex = variant.hex;

      validatedItems.push(validatedItem);
      expectedSubtotal += finalItemPrice * quantity;
    }

    expectedSubtotal = roundTwo(expectedSubtotal);

    // ===== حساب سعر الشحن =====
    // لو العميل اختار شركة مفعلة: نحسب السعر من الـ carrier API على السيرفر
    // (Aramex/DHL). Bosta تستخدم السعر الذي حدده التاجر لأن Bosta لا تنشر
    // Rate Calculator API عامًا في توثيقها الحالي. لو لم يوجد تكامل فعلي،
    // نرجع للنظام القديم الخاص بالمحافظات.
    let shippingCost = computeShippingCost(settings, orderData.governorate, expectedSubtotal);
    if (shippingProviderKey && expectedSubtotal < (Number(settings?.freeShippingThreshold) || 1500)) {
      // بنعيد حساب السعر من نفس الـaggregator الحقيقي اللي بيستخدمه
      // /api/shipping/rates (services/shipping/index.js -> rates()) بدل
      // اختراع/استدعاء دالة getRate مكنتش موجودة. لو الشركة معندهاش Rate
      // API حقيقي (أو حصل خطأ اتصال)، منمنعش الطلب - بنرجع لسعر المحافظات
      // الافتراضي بدل ما نكسر الـCheckout بالكامل.
      try {
        const quoteOrder = {
          _id: 'checkout-quote',
          subtotal: expectedSubtotal,
          countryCode: String(orderData.shippingCountryCode || '').toUpperCase(),
          country: orderData.country,
          governorate: orderData.governorate || '',
          address: orderData.address || '',
          zipCode: orderData.zipCode || '',
          customerName: orderData.customerName || '',
          customerPhone: orderData.customerPhone || '',
          totalAmount: orderData.totalAmount,
          paymentMethod: requestedPaymentMethod,
        };
        const allRates = await getShippingRates(quoteOrder, {});
        const matched = allRates.find(r => r.provider === shippingProviderKey && Number.isFinite(Number(r.amount)));
        if (matched) shippingCost = roundTwo(matched.amount);
      } catch (rateErr) {
        console.error('Shipping rate recalculation failed:', rateErr.message);
      }
    }
    const submittedSubtotal = roundTwo(orderData.subtotal);
    const submittedTotal = roundTwo(orderData.totalAmount);

    // ===== التحقق من الخصومات =====
    let discount = 0;
    let discountType = 'none';
    let firstOrderDiscountApplied = false;
    let appliedDiscountCodeDoc = null;

    // ===== التحقق من كود الولاء (مرة واحدة فقط للعميل) =====
    let loyaltyCodeApplied = false;
    let usedLoyaltyCode = null;

    if (req.user && orderData.discountType === 'loyalty_code' && orderData.discountCode) {
      const User = require('../models/User');
      const freshUser = await User.findById(req.user._id);

      if (freshUser) {
        const code = String(orderData.discountCode).trim().toUpperCase();
        const hasCode = (freshUser.loyaltyCodes || []).includes(code);
        const alreadyUsed = (freshUser.loyaltyCodesUsed || []).includes(code);

        if (hasCode && !alreadyUsed) {
          // حساب الخصم من إعدادات الولاء
          const lp = settings?.loyaltyProgram;
          if (lp && lp.enabled) {
            // لو الكود لمنتج معين، نتحقق إن المنتج ده في الطلب
            const specificProductId = lp.specificProductId;
            const specificProductInOrder = specificProductId
              ? validatedItems.some(it => String(it.productId) === String(specificProductId))
              : true;

            if (specificProductInOrder) {
              if (lp.rewardType === 'percentage') {
                discount = roundTwo(expectedSubtotal * (Number(lp.rewardValue) / 100));
              } else if (lp.rewardType === 'fixed') {
                discount = roundTwo(Math.min(Number(lp.rewardValue), expectedSubtotal));
              }
              loyaltyCodeApplied = true;
              usedLoyaltyCode = code;
              discountType = 'loyalty_code';
            }
          }
        }
      }

    } else if (req.user && orderData.discountType === 'first_order') {
      const User = require('../models/User');
      const freshUser = await User.findById(req.user._id);
      const isEligible = freshUser && !freshUser.firstOrderDiscountUsed;

      if (isEligible) {
        const guestDiscount = settings?.promotions?.guestDiscount;
        const percentage = Number.isFinite(Number(guestDiscount?.percentage)) ? Number(guestDiscount.percentage) : 0;
        if (guestDiscount?.enabled && percentage > 0) {
          discount = roundTwo(expectedSubtotal * (percentage / 100));
          firstOrderDiscountApplied = true;
          discountType = 'first_order';
        }
      }

    } else if (orderData.discountType === 'code' && orderData.discountCode) {
      // ===== كود خصم عادي — بيتحسب من نسبة الكود المخزّنة في الإعدادات، مش من رقم العميل =====
      const code = String(orderData.discountCode).trim().toUpperCase();
      const codes = settings?.discountCodes || [];
      const foundCode = codes.find((c) => String(c?.code || '').trim().toUpperCase() === code && c?.isActive);

      if (foundCode) {
        const maxUses = Number(foundCode.maxUses) || 0;
        const usageCount = Number(foundCode.usageCount) || 0;
        const usageOk = !(maxUses > 0 && usageCount >= maxUses);
        const productOk = !foundCode.specificProductId
          || validatedItems.some((it) => String(it.productId) === String(foundCode.specificProductId));

        if (usageOk && productOk) {
          const percentage = Math.min(Math.max(Number(foundCode.discountPercent) || 0, 0), 100);
          discount = roundTwo(expectedSubtotal * (percentage / 100));
          discountType = 'code';
          appliedDiscountCodeDoc = foundCode;
        }
      }

    } else if (orderData.discountType === 'promotion') {
      // ===== عروض الحملات (Buy X Get Y / خصم كمية) =====
      // محرك حساب العروض ده معقد وبيتحسب حاليًا في الفرونت (calculateCartPromotions).
      // كإجراء أمان فوري: بنقبل الرقم المرسل من العميل بس بسقف أقصى آمن (70% من السلة)
      // بدل ما نصدّقه زي ما هو، عشان مايبقاش فيه طلب مجاني أو بقيمة سالبة.
      // التوصية: نقل نفس منطق calculateCartPromotions للباك اند عشان يتحسب من غير أي ثقة في العميل.
      const requestedDiscount = roundTwo(orderData.discount);
      const MAX_PROMO_DISCOUNT_RATIO = 0.7;
      discount = Math.min(Math.max(requestedDiscount, 0), roundTwo(expectedSubtotal * MAX_PROMO_DISCOUNT_RATIO));
      discountType = 'promotion';
    }

    // ===== سقف أمان نهائي: الخصم مايتخطاش قيمة السلة أبداً تحت أي ظرف =====
    discount = Math.min(Math.max(roundTwo(discount), 0), expectedSubtotal);

    const expectedTotal = roundTwo(expectedSubtotal + shippingCost - discount);

    if (expectedTotal < 0) {
      return res.status(400).json({ message: 'قيمة الطلب غير صحيحة' });
    }

    if (submittedTotal <= 0) {
      return res.status(400).json({ message: 'قيمة الطلب غير متطابقة مع الأسعار الحالية' });
    }

    // ============================================================
    // ===== خصم المخزون Atomic قبل إنشاء الطلب (منع overselling) =====
    // كل عنصر بيتخصم بعملية atomic واحدة في MongoDB بشرط
    // (stock >= quantity) داخل نفس الـ update، مش قراءة ثم خصم لاحقًا.
    // لو أي عنصر فشل (مخزون غير كافي فعليًا وقت التنفيذ، حتى لو عدة طلبات
    // جت في نفس اللحظة بالظبط)، بيتم إرجاع أي عناصر سابقة اتخصمت في نفس
    // الطلب فورًا (rollback)، ولا يتم إنشاء order، ولا إرسال أي confirmation.
    // ============================================================
    const decrementResult = await decrementOrderItems(validatedItems);
    if (!decrementResult.ok) {
      const failedItem = decrementResult.failedItem;
      const failedName = validatedItems.find(
        (it) => it.productId === failedItem.productId && it.variantId === failedItem.variantId && it.size === failedItem.size
      );
      return res.status(409).json({
        code: 'OUT_OF_STOCK',
        message: `الكمية المطلوبة من منتج ${failedName?.name?.ar || failedName?.name?.en || 'unknown'} غير متوفرة`,
      });
    }

    // ============================================================
    // ===== Phase 2: بناء shippingAddress المنظّم (عام لكل شركات الشحن) =====
    // بنبني الحقل الجديد دايمًا (حتى لو الفرونت لسه بيبعت الحقول القديمة
    // بس)، بالـfallback للحقول المسطّحة (customerName/customerPhone/
    // governorate/address/...) - عشان يبقى جاهز لـPhase 3 من غير ما نحتاج
    // أي migration على الطلبات الجديدة، ومن غير ما نغيّر أو نمسح أي حقل
    // قديم (الحقول القديمة بتتحفظ زي ما هي بالظبط من orderData نفسها).
    // ============================================================
    const normalizedShippingAddress = {
      fullName: incomingShippingAddress.fullName || orderData.customerName || null,
      phone: incomingShippingAddress.phone || orderData.customerPhone || null,
      phone2: incomingShippingAddress.phone2 || orderData.customerPhone2 || null,
      email: incomingShippingAddress.email || orderData.customerEmail || null,
      governorate: incomingShippingAddress.governorate || orderData.governorate || null,
      district: incomingShippingAddress.district || null,
      detailedAddress: incomingShippingAddress.detailedAddress || orderData.address || null,
      buildingNumber: incomingShippingAddress.buildingNumber || null,
      floor: incomingShippingAddress.floor || null,
      apartment: incomingShippingAddress.apartment || null,
      landmark: incomingShippingAddress.landmark || null,
      country: incomingShippingAddress.country || orderData.country || null,
      zipCode: incomingShippingAddress.zipCode || orderData.zipCode || null,
    };

    let order;
    try {
      order = await Order.create({
        ...orderData,
        items: validatedItems,
        subtotal: expectedSubtotal,
        discount,
        shippingCost,
        totalAmount: expectedTotal,
        paymentMethod,
        walletPayment: walletPaymentData || undefined,
        shippingAddress: normalizedShippingAddress,
      });
    } catch (createErr) {
      // ===== فشل إنشاء الـ order بعد ما اتخصم المخزون: لازم نرجّع الكمية فورًا =====
      // عشان الكمية متضيعش (تتحجز من غير ما يبقى ليها order فعلي).
      await restoreOrderItems(validatedItems);
      await logMovementsBulk(validatedItems, 'stock_released', {
        note: 'rollback بسبب فشل إنشاء الطلب بعد خصم المخزون',
      });
      throw createErr;
    }

    // ===== سجّل حركة "بيع" لكل عنصر تم خصمه فعليًا مع ربطه بالطلب =====
    await logMovementsBulk(validatedItems, 'stock_sold', {
      orderId: order._id,
      userId: req.user ? req.user._id : null,
    });

    // ===== زيادة عداد استخدام كود الخصم (لو كان الطلب استخدم كود خصم عادي) =====
    if (appliedDiscountCodeDoc) {
      try {
        await Settings.updateOne(
          { 'discountCodes.code': appliedDiscountCodeDoc.code },
          { $inc: { 'discountCodes.$.usageCount': 1 } }
        );
      } catch (codeErr) {
        console.error('تعذّر تحديث عداد استخدام كود الخصم:', codeErr.message);
      }
    }

    // ============================================================
    // ===== تأكيد الطلب (إيميل/واتساب) — معزول تمامًا عن مسار إنشاء الطلب =====
    // بدل ما نستدعي Brevo هنا ونستنى الرد منه (اتصال شبكة خارجي بطيء ممكن
    // يعلّق الـ HTTP request)، بنكتفي بعمل insert سريع في MarketingMessage
    // (عملية DB محلية خفيفة) والـ background worker (marketingWorker.js) هو
    // اللي فعليًا بيكلم Brevo لاحقًا. لو فشل الإرسال، الطلب يبقى اتعمل
    // بنجاح برضو، والـ worker بيعمل retry محدود، ولو استمر الفشل بتتحدث
    // حالة emailConfirmation.status لـ 'failed' من غير ما تأثر على الطلب.
    // الـ unique index على (kind, entityId, step, channel) في MarketingMessage
    // بيمنع تكرار جدولة نفس رسالة تأكيد الطلب أكتر من مرة (idempotency).
    // ============================================================
    try {
      const marketing = settings?.marketing;
      if (paymentMethod !== 'kashier' && paymentMethod !== 'paymob' && marketing?.enabled && marketing?.orderConfirmation) {
        const channel = marketing.orderConfirmationChannel === 'whatsapp' ? 'whatsapp' : 'email';
        const hasTarget = channel === 'email' ? !!order.customerEmail : !!order.customerPhone;

        if (hasTarget) {
          const MarketingMessage = require('../models/MarketingMessage');
          try {
            await MarketingMessage.create({
              kind: 'order_confirmation',
              channel,
              recipientEmail: channel === 'email' ? String(order.customerEmail).trim().toLowerCase() : undefined,
              recipientPhone: channel === 'whatsapp' ? String(order.customerPhone || '').replace(/\D/g, '') : undefined,
              subject: `تأكيد طلبك #${order._id}`,
              entityId: order._id.toString(),
              step: 0,
              scheduledAt: new Date(),
              status: 'pending',
            });
            order.emailConfirmation = { enabled: true, confirmed: false, confirmedAt: null, messageId: null, status: 'pending' };
          } catch (queueErr) {
            // E11000 = already queued لنفس الطلب/القناة (نادراً، لو حصل retry على نفس الـ request) — تجاهل بأمان.
            if (queueErr?.code !== 11000) throw queueErr;
          }
          await order.save();
        }
      }
    } catch (e) {
      // Never fail an otherwise valid order because queueing the confirmation message failed.
      console.error('Order confirmation queueing failed:', { message: e?.message, code: e?.code });
    }

    // المخزون اتخصم فعلاً (atomic) قبل إنشاء الطلب فوق — هنا بس نلغي الكاش
    invalidateProductCaches();
    require('../utils/cache').del('orders:all');

    // ===== تحديث firstOrderDiscountUsed =====
    if (firstOrderDiscountApplied && req.user) {
      const User = require('../models/User');
      await User.findByIdAndUpdate(req.user._id, { firstOrderDiscountUsed: true });
    }

    // ===== تحديث نظام الولاء =====
    // الطلب الإلكتروني عبر Kashier لا يُحسب كطلب مكتمل قبل وصول تأكيد الدفع.
    if (req.user && paymentMethod !== 'kashier' && paymentMethod !== 'paymob') {
      const User = require('../models/User');
      const freshUser = await User.findById(req.user._id);

      if (freshUser) {
        const updateFields = {};

        // وضّع كود الولاء المستخدم
        if (loyaltyCodeApplied && usedLoyaltyCode) {
          updateFields.$addToSet = { loyaltyCodesUsed: usedLoyaltyCode };
        }

        // زيّد عداد الطلبات
        const newCount = (freshUser.loyaltyOrderCount || 0) + 1;
        updateFields.$set = { loyaltyOrderCount: newCount };

        // تحقق إذا العميل وصل للعدد المطلوب واستحق مكافأة
        const lp = settings?.loyaltyProgram;
        if (lp && lp.enabled && lp.ordersRequired > 0) {
          const ordersRequired = Number(lp.ordersRequired);
          // بيستحق مكافأة كل ما يكمل العدد المطلوب (مثلاً كل 10 طلبات)
          if (newCount > 0 && newCount % ordersRequired === 0) {
            // ولّد كود جديد
            let newCode;
            let attempts = 0;
            do {
              newCode = generateLoyaltyCode(lp.codePrefix || 'LOYALTY');
              attempts++;
            } while (
              (freshUser.loyaltyCodes || []).includes(newCode) && attempts < 10
            );

            // أضف الكود لقايمة أكواده
            if (!updateFields.$addToSet) updateFields.$addToSet = {};
            updateFields.$addToSet.loyaltyCodes = newCode;

            // حفظ التحديثات
            await User.findByIdAndUpdate(req.user._id, updateFields);

            // أرجع كود المكافأة مع الاستجابة
            return res.status(201).json({
              ...order.toObject(),
              loyaltyReward: {
                earned: true,
                code: newCode,
                rewardType: lp.rewardType,
                rewardValue: lp.rewardValue,
                specificProductId: lp.specificProductId || null,
                title: lp.title,
                message: lp.message,
                orderCount: newCount,
              }
            });
          }
        }

        // حفظ التحديثات العادية
        await User.findByIdAndUpdate(req.user._id, updateFields);
      }
    }

    if (paymentMethod === 'kashier') {
      try {
        const paymentUrl = buildPaymentUrl({
          orderId: order._id.toString(),
          amount: order.totalAmount,
          customerEmail: order.customerEmail,
          customerPhone: order.customerPhone,
          allowedMethods: gatewaySubMethod ? [gatewaySubMethod] : undefined,
        });

        invalidateProductCaches();
        require('../utils/cache').del('orders:all');
        return res.status(201).json({
          ...order.toObject(),
          paymentUrl,
          requiresPayment: true,
        });
      } catch (paymentErr) {
        console.error('Kashier checkout creation failed:', paymentErr);
        // The order already reserved stock. Release it because no payment session was created.
        try {
          await restoreOrderItems(order.items);
          await logMovementsBulk(order.items, 'stock_released', {
            orderId: order._id,
            note: 'rollback because Kashier checkout session could not be created',
          });
          order.stockRestored = true;
          order.stockRestoredAt = new Date();
          order.paymentStatus = 'failed';
          await order.save();
          invalidateProductCaches();
        } catch (rollbackErr) {
          console.error('Kashier checkout rollback failed:', rollbackErr);
        }
        return res.status(502).json({ message: 'تعذر تجهيز صفحة الدفع عبر Kashier. لم يتم إتمام الدفع.' });
      }
    }

    if (paymentMethod === 'paymob') {
      try {
        const { paymentUrl } = await createPaymobIntention({
          orderId: order._id.toString(),
          amount: order.totalAmount,
          customerName: order.customerName,
          customerEmail: order.customerEmail,
          customerPhone: order.customerPhone,
          address: order.address,
          governorate: order.governorate,
          country: order.country,
          preferredMethod: gatewaySubMethod || undefined,
        });

        invalidateProductCaches();
        require('../utils/cache').del('orders:all');
        return res.status(201).json({
          ...order.toObject(),
          paymentUrl,
          requiresPayment: true,
        });
      } catch (paymentErr) {
        console.error('Paymob checkout creation failed:', paymentErr);
        // The order already reserved stock. Release it because no payment session was created.
        try {
          await restoreOrderItems(order.items);
          await logMovementsBulk(order.items, 'stock_released', {
            orderId: order._id,
            note: 'rollback because Paymob checkout session could not be created',
          });
          order.stockRestored = true;
          order.stockRestoredAt = new Date();
          order.paymentStatus = 'failed';
          await order.save();
          invalidateProductCaches();
        } catch (rollbackErr) {
          console.error('Paymob checkout rollback failed:', rollbackErr);
        }
        return res.status(502).json({ message: 'تعذر تجهيز صفحة الدفع عبر Paymob. لم يتم إتمام الدفع.' });
      }
    }

    // ============================================================
    // ===== إرسال تلقائي لشركة الشحن فور تأكيد الطلب (COD / تحويل يدوي) =====
    // بيحصل بعد ما الطلب اتأكد فعليًا (مش لطلبات Kashier/Paymob لسه مستنية
    // الدفع - دي بترجع فوق قبل ما توصل هنا). لو فشل الإرسال (شركة الشحن مش
    // مفعّلة، بيانات ناقصة، مشكلة اتصال...) الطلب يفضل موجود بنجاح برضو،
    // وبنسجل الخطأ في shippingError عشان الأدمن يقدر يعمل Retry يدوي من
    // لوحة الشحن (زرار "إرسال لشركة الشحن").
    // ============================================================
    if (order.shippingCompany) {
      try {
        const shipResult = await createShipmentForOrder(order, settings?.shippingIntegrations || {});
        if (shipResult.ok) {
          order.trackingNumber = shipResult.result.trackingNumber || shipResult.result.shipmentId || null;
          order.shippingProviderId = shipResult.result.shipmentId || shipResult.result.trackingNumber || null;
          order.shippingLabelUrl = shipResult.result.labelUrl || null;
          order.shippingStatus = 'shipped';
          order.shippingError = null;
          order.shippingErrorCode = null;
          order.shippedAt = new Date();
          order.shippingCreatedAt = new Date();
        } else {
          // ملحوظة (بند 7 في طلب Phase 3): لو الكود BOSTA_SUBSCRIPTION_REQUIRED،
          // ده مش bug في الكود - حساب بوسطة نفسه محتاج Active Bundle
          // Subscription. الطلب نفسه بيفضل موجود بنجاح زي أي فشل شحن تاني،
          // والأدمن يقدر يعمل Retry بعد ما يفعّل الحساب من عند بوسطة.
          order.shippingStatus = 'failed';
          order.shippingError = shipResult.message;
          order.shippingErrorCode = shipResult.code || null;
        }
        order.shippingUpdatedAt = new Date();
        await order.save();
      } catch (autoShipErr) {
        // لازم الطلب يفضل موجود حتى لو فشل الإرسال التلقائي لأي سبب غير متوقع
        console.error('Auto shipment creation failed:', autoShipErr);
        try {
          order.shippingStatus = 'failed';
          order.shippingError = autoShipErr.message || 'فشل إنشاء الشحنة تلقائيًا';
          order.shippingUpdatedAt = new Date();
          await order.save();
        } catch (saveErr) {
          console.error('Failed to save shippingError after auto-ship failure:', saveErr);
        }
      }
    }

    res.status(201).json(order);
  } catch (err) {
    console.error('Error creating order:', err);
    if (uploadedScreenshot) {
      await deleteImageFromCloudinary(uploadedScreenshot);
    }
    if (err?.code === 'CLOUDINARY_UPLOAD_FAILED') {
      return res.status(err.statusCode || 502).json({
        message: 'تعذر رفع صورة الدفع إلى التخزين. لم يتم إنشاء الطلب.',
      });
    }
    return res.status(500).json({ message: 'حصل خطأ في إنشاء الطلب' });
  }
};

// يبني فلتر Mongo من query params الاختيارية — فلترة server-side بالكامل
// (بدل ما الفرونت يحمّل كل الطلبات ويفلتر في المتصفح).
const buildOrderFilter = (query = {}) => {
  const filter = {};
  if (query.status) filter.status = query.status;
  if (query.paymentStatus) filter.paymentStatus = query.paymentStatus;
  if (query.paymentMethod) filter.paymentMethod = query.paymentMethod;
  if (query.shippingStatus) filter.shippingStatus = query.shippingStatus;
  if (query.customerPhone) filter.customerPhone = String(query.customerPhone).trim();
  if (query.customerEmail) filter.customerEmail = String(query.customerEmail).trim().toLowerCase();
  if (query.trackingNumber) filter.trackingNumber = String(query.trackingNumber).trim();

  if (query.dateFrom || query.dateTo) {
    filter.createdAt = {};
    if (query.dateFrom) filter.createdAt.$gte = new Date(query.dateFrom);
    if (query.dateTo) filter.createdAt.$lte = new Date(query.dateTo);
  }

  if (query.search) {
    const term = String(query.search).trim();
    if (term) {
      const regex = new RegExp(term.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i');
      filter.$or = [{ customerName: regex }, { customerPhone: regex }, { customerEmail: regex }];
    }
  }

  return filter;
};

// يجيب بيانات المنتجات المرتبطة بعناصر مجموعة orders بعملية واحدة (bulk fetch
// بـ $in) بدل عمل Product.findById لكل عنصر في كل order على حدة (N+1 قديم).
const enrichOrdersWithProductData = async (orders) => {
  const productIds = new Set();
  for (const order of orders) {
    for (const item of order.items || []) {
      if (item.productId) productIds.add(String(item.productId));
    }
  }

  if (productIds.size === 0) return orders;

  const products = await Product.find({ _id: { $in: Array.from(productIds) } }).lean();
  const productMap = new Map(products.map((p) => [String(p._id), p]));

  return orders.map((order) => {
    const enrichedItems = (order.items || []).map((item) => {
      const product = productMap.get(String(item.productId));
      if (!product) return item;

      const variant = (product.variants || []).find((v) =>
        String(v._id) === String(item.variantId) ||
        String(v._id) === String(item.variantId?.toString?.() || item.variantId)
      );

      const productName = item.name && (item.name.ar || item.name.en) ? item.name : (product.name || {});
      const productImage = item.productImage || (product.images && product.images[0]
        ? (typeof product.images[0] === 'string' ? product.images[0] : (product.images[0].url || ''))
        : '');
      const colorInfo = item.color || (variant ? variant.color : null);
      const colorHex = item.colorHex || (variant ? variant.hex : null);

      return {
        ...item,
        productName,
        images: productImage ? [productImage] : (product.images || []),
        color: colorInfo,
        colorHex,
        size: item.size,
        isBundleItem: item.isBundleItem || false,
        bundleDiscount: item.bundleDiscount || 0,
        originalPrice: item.originalPrice || item.price,
      };
    });

    return { ...order, items: enrichedItems };
  });
};

// GET /api/orders  (أدمن / كول سنتر / باكر بس)
const getOrders = async (req, res) => {
  try {
    const { isPaginated, page, limit, skip } = parsePagination(req.query, { maxLimit: 100, defaultLimit: 50 });
    const filter = buildOrderFilter(req.query);
    const hasFilters = Object.keys(filter).length > 0;

    // المسار السريع القديم (بدون فلاتر/pagination صريحة): كاش زي ما كان
    if (!isPaginated && !hasFilters) {
      const cacheKey = 'orders:all';
      const cached = get(cacheKey);
      if (cached) {
        return res.json(cached);
      }

      const orders = await Order.find()
        .sort({ createdAt: -1 })
        .limit(1000) // سقف أمان حتى في المسار القديم
        .populate('customerId', 'name email phone')
        .lean();

      const enriched = await enrichOrdersWithProductData(orders);

      set(cacheKey, enriched, 30);
      return res.json(enriched);
    }

    // مسار الفلترة/الـ pagination الحقيقية
    const [orders, total] = await Promise.all([
      Order.find(filter)
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(limit)
        .populate('customerId', 'name email phone')
        .lean(),
      Order.countDocuments(filter),
    ]);

    const enriched = await enrichOrdersWithProductData(orders);
    res.json(buildListResponse({ isPaginated: true, page, limit, items: enriched, total }));
  } catch (err) {
    console.error('Error fetching orders:', err);
    res.status(500).json({ message: 'حصل خطأ في جلب الطلبات', error: err.message });
  }
};

// GET /api/orders/mine  (عميل مسجل)
const getMyOrders = async (req, res) => {
  try {
    const { isPaginated, page, limit, skip } = parsePagination(req.query, { maxLimit: 100, defaultLimit: 50 });

    if (!isPaginated) {
      const orders = await Order.find({ customerId: req.user._id })
        .sort({ createdAt: -1 })
        .limit(500) // سقف أمان
        .lean();
      return res.json(orders);
    }

    const filter = { customerId: req.user._id };
    const [orders, total] = await Promise.all([
      Order.find(filter).sort({ createdAt: -1 }).skip(skip).limit(limit).lean(),
      Order.countDocuments(filter),
    ]);

    res.json(buildListResponse({ isPaginated: true, page, limit, items: orders, total }));
  } catch (err) {
    console.error('Error fetching my orders:', err);
    res.status(500).json({ message: 'حصل خطأ في جلب طلباتك', error: err.message });
  }
};

// يبعت رسالة تسويقية (إيميل/واتساب) لو الأدمن حدد رسالة لحالة الطلب أو حالة الشحن دي.
// لا يوقف أو يفشّل تحديث الحالة لو الإرسال فشل.
const queueStatusNotification = async (order, statusValue) => {
  try {
    const settings = await Settings.findOne().select('marketing').lean();
    const marketing = settings?.marketing;
    const rule = marketing?.statusNotifications
      ? (marketing.statusChannels || []).find(s => s.enabled && s.status === statusValue)
      : null;
    if (!rule) return;
    const channel = rule.channel === 'whatsapp' ? 'whatsapp' : 'email';
    const hasTarget = channel === 'email' ? !!order.customerEmail : !!order.customerPhone;
    if (!hasTarget) return;
    const MarketingMessage = require('../models/MarketingMessage');
    const render = (tpl) => String(tpl || '').replace(/\{\{\s*([\w.-]+)\s*\}\}/g, (_, k) => {
      const ctx = { customerName: order.customerName, orderId: String(order._id), status: statusValue, total: order.totalAmount };
      return ctx[k] == null ? '' : String(ctx[k]);
    });
    await MarketingMessage.create({
      kind: 'order_status',
      channel,
      recipientEmail: channel === 'email' ? String(order.customerEmail).trim().toLowerCase() : undefined,
      recipientPhone: channel === 'whatsapp' ? String(order.customerPhone || '').replace(/\D/g, '') : undefined,
      subject: render(rule.subject) || `تحديث حالة طلبك #${order._id}`,
      content: render(rule.content) || `طلبك #${order._id} بقى: ${statusValue}`,
      // entityId يشمل الحالة نفسها علشان كل حالة تتبعت مرة واحدة، وأي حالة جديدة تتبعت برضو.
      entityId: `${order._id}:${statusValue}`,
      step: 0,
      scheduledAt: new Date(),
      status: 'pending',
    });
  } catch (notifyErr) {
    console.error('Order status notification queue failed:', notifyErr.message);
  }
};

// PUT /api/orders/:id/status  (أدمن / كول سنتر)
const updateOrderStatus = async (req, res) => {
  try {
    const order = await Order.findById(req.params.id);
    if (!order) {
      return res.status(404).json({ message: 'الطلب مش موجود' });
    }
    const statusChanged = req.body.status && req.body.status !== order.status;
    const newStatus = req.body.status;
    if (req.body.status) order.status = req.body.status;

    // ===== تفاصيل الإرجاع — بتتسجل بس لو الحالة الجديدة "مرتجع" =====
    // returnReason و returnShippingCost اختياريين، بيتبعتوا من الأدمن وقت
    // تغيير الحالة (مثلاً من مودال تأكيد الإرجاع في الفرونت).
    if (statusChanged && (newStatus === 'مرتجع' || newStatus === 'Returned')) {
      if (typeof req.body.returnReason === 'string' && req.body.returnReason.trim()) {
        order.returnReason = req.body.returnReason.trim().slice(0, 500);
      }
      if (req.body.returnShippingCost !== undefined && req.body.returnShippingCost !== null && req.body.returnShippingCost !== '') {
        const cost = Number(req.body.returnShippingCost);
        if (Number.isFinite(cost) && cost >= 0) order.returnShippingCost = cost;
      }
    }

    // ============================================================
    // ===== إرجاع المخزون عند الإلغاء/الرفض/الارتجاع =====
    // بيحصل مرة واحدة بس لكل order (محمي بـ stockRestored) حتى لو حد نادى
    // على الـ endpoint ده أكتر من مرة أو تم تغيير الحالة لـ "ملغي" مرتين.
    // ============================================================
    if (statusChanged && STOCK_RESTORING_STATUSES.has(newStatus) && !order.stockRestored) {
      // نعلّم الطلب كـ "تم إرجاع مخزونه" بشرط atomic (findOneAndUpdate) قبل
      // أي إرجاع فعلي، عشان نقفل الـ race لو نفس الـ endpoint اتنادى مرتين
      // في نفس اللحظة بالظبط (مثلاً دبل كليك من الأدمن، أو retry من الفرونت).
      const lockResult = await Order.findOneAndUpdate(
        { _id: order._id, stockRestored: false },
        { $set: { stockRestored: true, stockRestoredAt: new Date() } },
        { new: true }
      );

      if (lockResult) {
        await restoreOrderItems(order.items);
        await logMovementsBulk(order.items, 'stock_returned', {
          orderId: order._id,
          userId: req.user ? req.user._id : null,
          note: `إرجاع مخزون بسبب تغيير حالة الطلب إلى: ${newStatus}`,
        });
        invalidateProductCaches();
        order.stockRestored = true;
        order.stockRestoredAt = lockResult.stockRestoredAt;
      }
    }

    await order.save();
    require('../utils/cache').del('orders:all');

    if (statusChanged) await queueStatusNotification(order, order.status);

    res.json(order);
  } catch (err) {
    console.error('Error updating order status:', err);
    res.status(500).json({ message: 'حصل خطأ في تحديث حالة الطلب', error: err.message });
  }
};

// PUT /api/orders/:id/packer-status  (أدمن / باكر)
const updatePackerStatus = async (req, res) => {
  try {
    const order = await Order.findById(req.params.id);
    if (!order) {
      return res.status(404).json({ message: 'الطلب مش موجود' });
    }
    const packerStatusChanged = req.body.packerStatus && req.body.packerStatus !== order.packerStatus;
    if (req.body.packerStatus) order.packerStatus = req.body.packerStatus;
    await order.save();
    require('../utils/cache').del('orders:all');

    if (packerStatusChanged) await queueStatusNotification(order, order.packerStatus);

    res.json(order);
  } catch (err) {
    console.error('Error updating packer status:', err);
    res.status(500).json({ message: 'حصل خطأ في تحديث حالة التجهيز', error: err.message });
  }
};

// PUT /api/orders/:id/confirm-payment  (أدمن / كول سنتر - تأكيد استلام فلوس الدفع الإلكتروني)
const confirmWalletPayment = async (req, res) => {
  try {
    const order = await Order.findById(req.params.id);
    if (!order) {
      return res.status(404).json({ message: 'الطلب مش موجود' });
    }
    if (order.paymentMethod !== 'wallet') {
      return res.status(400).json({ message: 'الطلب ده مش مدفوع دفع إلكتروني' });
    }
    const confirmed = !!req.body.confirmed;
    order.walletPayment.confirmed = confirmed;
    order.walletPayment.confirmedAt = confirmed ? new Date() : null;
    await order.save();
    require('../utils/cache').del('orders:all');
    res.json(order);
  } catch (err) {
    console.error('Error confirming wallet payment:', err);
    res.status(500).json({ message: 'حصل خطأ في تأكيد الدفع', error: err.message });
  }
};

// GET /api/orders/loyalty-info  (عميل مسجل - يجيب بياناته في نظام الولاء)
const getLoyaltyInfo = async (req, res) => {
  try {
    const User = require('../models/User');
    const freshUser = await User.findById(req.user._id).select('loyaltyOrderCount loyaltyCodes loyaltyCodesUsed');
    if (!freshUser) return res.status(404).json({ message: 'المستخدم غير موجود' });

    const settings = await Settings.findOne();
    const lp = settings?.loyaltyProgram || {};

    const availableCodes = (freshUser.loyaltyCodes || []).filter(
      c => !(freshUser.loyaltyCodesUsed || []).includes(c)
    );

    res.json({
      orderCount: freshUser.loyaltyOrderCount || 0,
      ordersRequired: lp.ordersRequired || 10,
      availableCodes,
      usedCodes: freshUser.loyaltyCodesUsed || [],
      loyaltyEnabled: lp.enabled || false,
      rewardType: lp.rewardType || 'percentage',
      rewardValue: lp.rewardValue || 0,
      specificProductId: lp.specificProductId || null,
      nextRewardIn: lp.enabled && lp.ordersRequired
        ? lp.ordersRequired - ((freshUser.loyaltyOrderCount || 0) % lp.ordersRequired)
        : null,
    });
  } catch (err) {
    console.error('Error fetching loyalty info:', err);
    res.status(500).json({ message: 'حصل خطأ في جلب بيانات الولاء', error: err.message });
  }
};

// exports moved to bottom of file
// ============================================================
// GET /api/orders/payments-dashboard  (أدمن فقط)
// إحصائيات شاملة للمدفوعات — aggregation في الداتابيز بدل تحميل كل الطلبات
// في الميموري (كان قبل كده Order.find().lean() على كل الطلبات، وده مش
// scalable لو عدد الطلبات كبير).
// ============================================================
const getPaymentsDashboard = async (req, res) => {
  try {
    const [totals] = await Order.aggregate([
      {
        $group: {
          _id: null,
          totalOrders: { $sum: 1 },
          totalRevenue: {
            $sum: {
              $cond: [
                // الإيراد ميتحسبش إلا لما الطلب "يتسلم" فعليًا - سواء عن طريق تتبع
                // شركة شحن (shippingStatus=delivered) أو طلب متابع يدويًا/استلام من
                // المتجر (status='تم التسليم') - بغض النظر عن طريقة الدفع (COD،
                // كاشير، Paymob، محفظة). قبل كده كان مختلف حسب طريقة الدفع (COD
                // بيتحسب من وقت "تم التأكيد" بس، وأونلاين من وقت "paid") وده كان بيدي
                // صورة غير دقيقة لصافي الأرباح لأن الشحنة ممكن ترجع/تفشل بعد الشحن.
                { $or: [
                  { $eq: ['$shippingStatus', 'delivered'] },
                  { $eq: ['$status', 'تم التسليم'] },
                ] },
                { $subtract: [{ $ifNull: ['$totalAmount', 0] }, { $ifNull: ['$refundedAmount', 0] }] }, 0,
              ],
            },
          },
          pendingAmount: { $sum: { $cond: [{ $eq: [{ $ifNull: ['$paymentStatus', 'pending'] }, 'pending'] }, { $ifNull: ['$totalAmount', 0] }, 0] } },
          pendingCount: { $sum: { $cond: [{ $eq: [{ $ifNull: ['$paymentStatus', 'pending'] }, 'pending'] }, 1, 0] } },
          failedAmount: { $sum: { $cond: [{ $eq: ['$paymentStatus', 'failed'] }, { $ifNull: ['$totalAmount', 0] }, 0] } },
          failedCount: { $sum: { $cond: [{ $eq: ['$paymentStatus', 'failed'] }, 1, 0] } },
          refundedAmount: { $sum: { $ifNull: ['$refundedAmount', 0] } },
          refundedCount: { $sum: { $cond: [{ $gt: [{ $ifNull: ['$refundedAmount', 0] }, 0] }, 1, 0] } },
          byCodAmount: { $sum: { $cond: [{ $eq: [{ $ifNull: ['$paymentMethod', 'cod'] }, 'cod'] }, { $ifNull: ['$totalAmount', 0] }, 0] } },
          codCount: { $sum: { $cond: [{ $eq: [{ $ifNull: ['$paymentMethod', 'cod'] }, 'cod'] }, 1, 0] } },
          byWalletAmount: { $sum: { $cond: [{ $eq: ['$paymentMethod', 'wallet'] }, { $ifNull: ['$totalAmount', 0] }, 0] } },
          walletCount: { $sum: { $cond: [{ $eq: ['$paymentMethod', 'wallet'] }, 1, 0] } },
          byKashierAmount: { $sum: { $cond: [{ $eq: ['$paymentMethod', 'kashier'] }, { $ifNull: ['$totalAmount', 0] }, 0] } },
          kashierCount: { $sum: { $cond: [{ $eq: ['$paymentMethod', 'kashier'] }, 1, 0] } },
          byPaymobAmount: { $sum: { $cond: [{ $eq: ['$paymentMethod', 'paymob'] }, { $ifNull: ['$totalAmount', 0] }, 0] } },
          paymobCount: { $sum: { $cond: [{ $eq: ['$paymentMethod', 'paymob'] }, 1, 0] } },
        },
      },
    ]);

    const walletMethodsAgg = await Order.aggregate([
      { $match: { paymentMethod: 'wallet' } },
      {
        $group: {
          _id: { $ifNull: ['$walletPayment.methodName', 'أخرى'] },
          count: { $sum: 1 },
          amount: { $sum: { $ifNull: ['$totalAmount', 0] } },
        },
      },
    ]);

    const walletMethods = {};
    walletMethodsAgg.forEach((m) => {
      walletMethods[m._id] = { count: m.count, amount: m.amount };
    });

    // إيصالات في انتظار المراجعة — بحد أقصى آمن (أحدث 200 بدل تحميل الكل)
    const pendingProofReviewDocs = await Order.find({
      paymentMethod: 'wallet',
      'walletPayment.confirmed': false,
      'walletPayment.screenshotUrl': { $ne: null },
    })
      .select('customerName customerPhone totalAmount createdAt walletPayment')
      .sort({ createdAt: -1 })
      .limit(200)
      .lean();

    const pendingProofReview = pendingProofReviewDocs.map((order) => ({
      _id: order._id,
      customerName: order.customerName,
      customerPhone: order.customerPhone,
      totalAmount: order.totalAmount,
      createdAt: order.createdAt,
      methodName: order.walletPayment?.methodName || 'أخرى',
      screenshotUrl: order.walletPayment?.screenshotUrl,
      senderPhone: order.walletPayment?.senderPhone,
      transferDate: order.walletPayment?.transferDate,
      walletPhoneNumber: order.walletPayment?.walletPhoneNumber,
    }));

    const t = totals || {
      totalOrders: 0, totalRevenue: 0, pendingAmount: 0, pendingCount: 0,
      failedAmount: 0, failedCount: 0, refundedAmount: 0, refundedCount: 0,
      byCodAmount: 0, codCount: 0, byWalletAmount: 0, walletCount: 0,
    };

    res.json({
      totalRevenue: Math.round((t.totalRevenue || 0) * 100) / 100,
      pendingAmount: Math.round((t.pendingAmount || 0) * 100) / 100,
      failedAmount: Math.round((t.failedAmount || 0) * 100) / 100,
      refundedAmount: Math.round((t.refundedAmount || 0) * 100) / 100,
      byCodAmount: Math.round((t.byCodAmount || 0) * 100) / 100,
      byWalletAmount: Math.round((t.byWalletAmount || 0) * 100) / 100,
      totalOrders: t.totalOrders || 0,
      pendingCount: t.pendingCount || 0,
      failedCount: t.failedCount || 0,
      refundedCount: t.refundedCount || 0,
      codCount: t.codCount || 0,
      walletCount: t.walletCount || 0,
      byKashierAmount: Math.round((t.byKashierAmount || 0) * 100) / 100,
      kashierCount: t.kashierCount || 0,
      byPaymobAmount: Math.round((t.byPaymobAmount || 0) * 100) / 100,
      paymobCount: t.paymobCount || 0,
      walletMethods,
      pendingProofReview,
    });
  } catch (err) {
    console.error('Error fetching payments dashboard:', err);
    res.status(500).json({ message: 'حصل خطأ في جلب إحصائيات المدفوعات', error: err.message });
  }
};

// ============================================================
// GET /api/orders/shipping-dashboard  (أدمن فقط)
// إحصائيات شاملة للشحن — aggregation بدل تحميل كل الطلبات في الميموري
// ============================================================
const getShippingDashboard = async (req, res) => {
  try {
    const statusCountsAgg = await Order.aggregate([
      { $group: { _id: { $ifNull: ['$shippingStatus', 'pending'] }, count: { $sum: 1 } } },
    ]);

    const stats = {
      pending: 0, preparing: 0, shipped: 0, delivered: 0, failedDelivery: 0, returned: 0,
      companies: {},
      issues: [],
      shippedOrders: [],
    };

    const statusKeyMap = {
      pending: 'pending', preparing: 'preparing', shipped: 'shipped',
      delivered: 'delivered', failed_delivery: 'failedDelivery', returned: 'returned',
    };
    statusCountsAgg.forEach((s) => {
      const key = statusKeyMap[s._id];
      if (key) stats[key] = s.count;
    });

    const companiesAgg = await Order.aggregate([
      { $match: { shippingCompany: { $ne: null } } },
      {
        $group: {
          _id: '$shippingCompany',
          count: { $sum: 1 },
          delivered: { $sum: { $cond: [{ $eq: ['$shippingStatus', 'delivered'] }, 1, 0] } },
          failed: { $sum: { $cond: [{ $in: ['$shippingStatus', ['failed_delivery', 'returned']] }, 1, 0] } },
        },
      },
    ]);
    companiesAgg.forEach((c) => {
      stats.companies[c._id] = { count: c.count, delivered: c.delivered, failed: c.failed };
    });

    // مشاكل الشحن — بحد أقصى آمن (أحدث 200)
    const issuesDocs = await Order.find({
      $or: [
        { shippingStatus: 'failed_delivery' },
        { shippingStatus: 'returned' },
        { shippingNotes: { $nin: [null, ''] } },
      ],
    })
      .select('customerName customerPhone governorate shippingStatus shippingCompany trackingNumber shippingNotes totalAmount createdAt')
      .sort({ createdAt: -1 })
      .limit(200)
      .lean();
    stats.issues = issuesDocs;

    // الطلبات المشحونة مع tracking — بحد أقصى آمن (أحدث 200)
    const shippedDocs = await Order.find({ trackingNumber: { $ne: null } })
      .select('customerName customerPhone governorate shippingStatus shippingCompany trackingNumber shippedAt totalAmount')
      .sort({ shippedAt: -1 })
      .limit(200)
      .lean();
    stats.shippedOrders = shippedDocs;

    res.json(stats);
  } catch (err) {
    console.error('Error fetching shipping dashboard:', err);
    res.status(500).json({ message: 'حصل خطأ في جلب إحصائيات الشحن', error: err.message });
  }
};

// ============================================================
// PUT /api/orders/:id/shipping  (أدمن فقط)
// تحديث بيانات الشحن (شركة / tracking / حالة)
// ============================================================
const updateOrderShipping = async (req, res) => {
  try {
    const order = await Order.findById(req.params.id);
    if (!order) return res.status(404).json({ message: 'الطلب مش موجود' });

    const { shippingStatus, shippingCompany, trackingNumber, shippingNotes, returnTrackingNumber, returnStatus } = req.body;

    if (shippingStatus) order.shippingStatus = shippingStatus;
    if (shippingCompany !== undefined) order.shippingCompany = shippingCompany;
    if (trackingNumber !== undefined) order.trackingNumber = trackingNumber;
    if (shippingNotes !== undefined) order.shippingNotes = shippingNotes;
    // ===== إدخال يدوي لبيانات مرتجع شركة الشحن =====
    // مفيش شركة شحن من الأربعة عندها Return API رسمي متاح حاليًا (شوف
    // services/shipping/capabilities.js)، فالأدمن بيروح موقع شركة الشحن
    // بنفسه، يعمل طلب استرجاع، ولما تدّيله رقم تتبع بيدخله هنا يدويًا.
    if (returnTrackingNumber !== undefined) order.returnTrackingNumber = returnTrackingNumber;
    if (returnStatus !== undefined) order.returnStatus = returnStatus;

    // سجّل تواريخ تلقائية
    if (shippingStatus === 'shipped' && !order.shippedAt) order.shippedAt = new Date();
    if (shippingStatus === 'delivered' && !order.deliveredAt) order.deliveredAt = new Date();

    await order.save();
    require('../utils/cache').del('orders:all');
    res.json(order);
  } catch (err) {
    console.error('Error updating order shipping:', err);
    res.status(500).json({ message: 'حصل خطأ في تحديث بيانات الشحن', error: err.message });
  }
};

// ============================================================
// PUT /api/orders/:id/payment-status  (أدمن فقط)
// تحديث حالة الدفع (paid / failed / refunded)
// ============================================================
const updatePaymentStatus = async (req, res) => {
  try {
    const order = await Order.findById(req.params.id);
    if (!order) return res.status(404).json({ message: 'الطلب مش موجود' });

    const allowed = ['pending', 'paid', 'failed', 'refunded'];
    if (!allowed.includes(req.body.paymentStatus)) {
      return res.status(400).json({ message: 'حالة الدفع غير صحيحة' });
    }
    order.paymentStatus = req.body.paymentStatus;
    await order.save();
    require('../utils/cache').del('orders:all');
    res.json(order);
  } catch (err) {
    console.error('Error updating payment status:', err);
    res.status(500).json({ message: 'حصل خطأ في تحديث حالة الدفع', error: err.message });
  }
};

// PUT /api/orders/:id/refund  (أدمن - استرجاع فلوس Kashier/Paymob كامل أو جزئي)
// بيستخدم مراجع بوابة الدفع (paymentGateway) اللي بتتسجل تلقائيًا وقت الدفع
// عشان ينادي refund API بتاع البوابة نفسها، فالفلوس ترجع فعليًا لكارت/محفظة
// العميل — مش مجرد تغيير شكل الحالة عندنا.
const refundOrderPayment = async (req, res) => {
  try {
    const order = await Order.findById(req.params.id);
    if (!order) return res.status(404).json({ message: 'الطلب مش موجود' });

    if (!['kashier', 'paymob'].includes(order.paymentMethod)) {
      return res.status(400).json({ message: 'الاسترجاع الإلكتروني ده متاح بس لطلبات Kashier و Paymob' });
    }
    if (order.paymentStatus !== 'paid') {
      return res.status(400).json({ message: 'الطلب ده مش في حالة "مدفوع"، مينفعش تسترجع فلوسه' });
    }

    const alreadyRefundedLocal = Math.round(Number(order.refundedAmount || 0) * 100) / 100;

    // ===== Reconciliation: ask the gateway itself directly, first =====
    // Protects against double refunds when a refund was issued straight from
    // the Kashier/Paymob dashboard and our local record hasn't caught up yet
    // (most commonly because the webhook isn't configured/reachable — e.g.
    // still running on localhost). This works whether or not the webhook is
    // set up, since it asks the gateway instead of waiting for it to tell us.
    let alreadyRefunded = alreadyRefundedLocal;
    try {
      if (order.paymentMethod === 'kashier' && order.paymentGateway?.kashierOrderId) {
        const status = await getKashierOrderStatus(order.paymentGateway.kashierOrderId);
        if (status && Number.isFinite(status.totalRefundedAmount) && status.totalRefundedAmount > alreadyRefundedLocal + 0.01) {
          const diff = Math.round((status.totalRefundedAmount - alreadyRefundedLocal) * 100) / 100;
          order.refunds = order.refunds || [];
          order.refunds.push({
            amount: diff,
            reason: 'Refund detected directly from Kashier (issued outside this app — reconciled automatically before attempting a new one)',
            at: new Date(),
            by: null,
            gatewayResponse: status.raw,
          });
          order.refundedAmount = status.totalRefundedAmount;
          alreadyRefunded = status.totalRefundedAmount;
        }
      } else if (order.paymentMethod === 'paymob' && order.paymentGateway?.transactionId) {
        const status = await getPaymobTransactionStatus(order.paymentGateway.transactionId);
        if (status && status.isRefunded && alreadyRefundedLocal < Number(order.totalAmount || 0) - 0.01) {
          // Paymob's inquiry API only exposes a yes/no "is_refunded" flag (no
          // partial-refund breakdown), so a detected refund is treated as
          // covering the full order.
          const diff = Math.round((Number(order.totalAmount || 0) - alreadyRefundedLocal) * 100) / 100;
          order.refunds = order.refunds || [];
          order.refunds.push({
            amount: diff,
            reason: 'Refund detected directly from Paymob (issued outside this app — reconciled automatically before attempting a new one)',
            at: new Date(),
            by: null,
            gatewayResponse: status.raw,
          });
          order.refundedAmount = Number(order.totalAmount || 0);
          alreadyRefunded = order.refundedAmount;
        }
      }
    } catch (reconcileErr) {
      // Don't let a failed check (network hiccup etc.) block a legitimate
      // refund attempt — just proceed with what we know locally.
      console.error('Refund reconciliation check failed (continuing with local data):', reconcileErr);
    }

    const remaining = Math.round((Number(order.totalAmount || 0) - alreadyRefunded) * 100) / 100;
    if (remaining <= 0) {
      order.paymentStatus = 'refunded';
      if (!order.stockRestored) {
        await restoreOrderItems(order.items);
        await logMovementsBulk(order.items, 'stock_released', {
          orderId: order._id,
          userId: req.user ? req.user._id : null,
          note: 'استرجاع فلوس كامل (متسجل من البوابة مباشرة) — تم إرجاع المخزون',
        });
        order.stockRestored = true;
        order.stockRestoredAt = new Date();
        invalidateProductCaches();
      }
      await order.save();
      require('../utils/cache').del('orders:all');
      return res.json(order);
    }

    // لو مبعتش amount، بنعتبرها استرجاع كامل للباقي (remaining)
    let amount = req.body.amount != null && req.body.amount !== ''
      ? Number(req.body.amount)
      : remaining;

    if (!Number.isFinite(amount) || amount <= 0) {
      return res.status(400).json({ message: 'المبلغ المطلوب استرجاعه غير صحيح' });
    }
    if (amount > remaining + 0.01) {
      return res.status(400).json({ message: `أقصى مبلغ ينفع تسترجعه دلوقتي هو ${remaining}` });
    }
    amount = Math.min(amount, remaining);

    const reason = String(req.body.reason || '').trim() || 'Refund requested from admin dashboard';

    let gatewayResponse;
    try {
      if (order.paymentMethod === 'kashier') {
        const kashierOrderId = order.paymentGateway?.kashierOrderId;
        const kashierTransactionId = order.paymentGateway?.transactionId;
        if (!kashierOrderId || !kashierTransactionId) {
          return res.status(400).json({
            message: 'مفيش رقم أوردر/عملية Kashier محفوظ بالكامل على الطلب ده (غالبًا لأنه اتدفع قبل تفعيل الاسترجاع من هنا، أو الـ webhook مكنش مضبوط وقتها) — استرجع الفلوس يدويًا من لوحة تحكم Kashier.',
          });
        }
        gatewayResponse = await refundKashierPayment({ kashierOrderId, transactionId: kashierTransactionId, amount, reason });
      } else {
        const transactionId = order.paymentGateway?.transactionId;
        if (!transactionId) {
          return res.status(400).json({
            message: 'مفيش رقم عملية Paymob محفوظ على الطلب ده (غالبًا لأنه اتدفع قبل تفعيل الاسترجاع من هنا، أو الـ webhook مكنش مضبوط وقتها) — استرجع الفلوس يدويًا من لوحة تحكم Paymob.',
          });
        }
        gatewayResponse = await refundPaymobPayment({ transactionId, amountCents: Math.round(amount * 100) });
      }
    } catch (gatewayErr) {
      console.error('Refund gateway error:', gatewayErr);
      return res.status(502).json({
        message: `فشل الاسترجاع من بوابة الدفع: ${gatewayErr.message}`,
      });
    }

    order.refunds = order.refunds || [];
    order.refunds.push({
      amount,
      reason,
      at: new Date(),
      by: req.user ? req.user._id : null,
      gatewayResponse,
    });
    order.refundedAmount = Math.round((alreadyRefunded + amount) * 100) / 100;

    const isFullyRefunded = order.refundedAmount >= Number(order.totalAmount || 0) - 0.01;
    if (isFullyRefunded) {
      order.paymentStatus = 'refunded';

      if (!order.stockRestored) {
        await restoreOrderItems(order.items);
        await logMovementsBulk(order.items, 'stock_released', {
          orderId: order._id,
          userId: req.user ? req.user._id : null,
          note: 'استرجاع فلوس كامل من لوحة التحكم — تم إرجاع المخزون',
        });
        order.stockRestored = true;
        order.stockRestoredAt = new Date();
        invalidateProductCaches();
      }
    }

    await order.save();
    require('../utils/cache').del('orders:all');
    res.json(order);
  } catch (err) {
    console.error('Error refunding order payment:', err);
    res.status(500).json({ message: 'حصل خطأ في استرجاع الفلوس', error: err.message });
  }
};

// POST /api/orders/:id/return-request  (عميل مسجل - يطلب استرجاع منتج/منتجات من طلبه)
const requestReturn = async (req, res) => {
  try {
    const order = await Order.findById(req.params.id);
    if (!order) return res.status(404).json({ message: 'الطلب مش موجود' });

    if (!req.user || String(order.customerId || '') !== String(req.user._id)) {
      return res.status(403).json({ message: 'الطلب ده مش تابع لحسابك' });
    }

    const isDelivered = order.status === 'تم التسليم' || order.status === 'Delivered' || order.shippingStatus === 'delivered';
    if (!isDelivered) {
      return res.status(400).json({ message: 'الاسترجاع متاح بس للطلبات اللي اتسلمت فعلاً' });
    }

    if (order.returnRequestStatus === 'pending' || order.returnRequestStatus === 'approved') {
      return res.status(400).json({ message: 'فيه طلب استرجاع لنفس الطلب ده اتسجل بالفعل' });
    }

    const requestedItems = Array.isArray(req.body.items) ? req.body.items : [];
    if (requestedItems.length === 0) {
      return res.status(400).json({ message: 'اختار على الأقل منتج واحد عايز تسترجعه' });
    }

    const validatedItems = [];
    for (const reqItem of requestedItems) {
      const quantity = Number(reqItem.quantity);
      if (!isValidQuantity(quantity)) {
        return res.status(400).json({ message: 'كمية غير صحيحة في أحد المنتجات المطلوب استرجاعها' });
      }
      const matchingItem = order.items.find(oi =>
        String(oi.productId) === String(reqItem.productId) &&
        String(oi.variantId || '') === String(reqItem.variantId || '') &&
        String(oi.size || '') === String(reqItem.size || '')
      );
      if (!matchingItem) {
        return res.status(400).json({ message: 'أحد المنتجات المطلوب استرجاعها مش موجود في هذا الطلب' });
      }
      if (quantity > matchingItem.quantity) {
        return res.status(400).json({ message: `الكمية المطلوب استرجاعها من "${matchingItem.name?.ar || matchingItem.name?.en || ''}" أكبر من الكمية المشتراة` });
      }
      validatedItems.push({
        productId: matchingItem.productId,
        variantId: matchingItem.variantId || null,
        size: matchingItem.size || null,
        quantity,
        reason: typeof reqItem.reason === 'string' ? reqItem.reason.trim().slice(0, 300) : null,
      });
    }

    // ===== سبب الاسترجاع (كود موحّد من قايمة ثابتة) =====
    // reasonCode بيحدد هل رسوم الاسترجاع تتطبق على العميل ولا لأ وقت ما الأدمن
    // يوافق على الطلب. لو مش مبعوت أو قيمة غير معروفة، بنعتبره 'other' (fail-safe:
    // بيستوجب رسوم) بدل ما نسيب الحقل فاضي ونفوّت رسوم كان المفروض تتحصل.
    const reasonCode = isValidReasonCode(req.body.reasonCode) ? req.body.reasonCode : 'other';

    order.returnItems = validatedItems;
    order.returnRequestedBy = 'customer';
    order.returnRequestStatus = 'pending';
    order.returnRequestReason = typeof req.body.reason === 'string' ? req.body.reason.trim().slice(0, 500) : null;
    order.returnRequestReasonCode = reasonCode;
    order.returnRequestedAt = new Date();
    order.returnReviewedBy = null;
    order.returnReviewedAt = null;
    order.returnAdminNote = null;

    await order.save();
    require('../utils/cache').del('orders:all');
    res.json(order);
  } catch (err) {
    console.error('Error requesting return:', err);
    res.status(500).json({ message: 'حصل خطأ في تسجيل طلب الاسترجاع', error: err.message });
  }
};

// PUT /api/orders/:id/return-request  (أدمن - يوافق/يرفض طلب استرجاع، أو يبدأ استرجاع بنفسه)
const reviewReturnRequest = async (req, res) => {
  try {
    const order = await Order.findById(req.params.id);
    if (!order) return res.status(404).json({ message: 'الطلب مش موجود' });

    const action = req.body.action; // 'approve' | 'reject' | 'create'

    if (action === 'reject') {
      if (order.returnRequestStatus !== 'pending') {
        return res.status(400).json({ message: 'مفيش طلب استرجاع قيد المراجعة لهذا الطلب' });
      }
      order.returnRequestStatus = 'rejected';
      order.returnReviewedBy = req.user ? req.user._id : null;
      order.returnReviewedAt = new Date();
      if (typeof req.body.adminNote === 'string' && req.body.adminNote.trim()) {
        order.returnAdminNote = req.body.adminNote.trim().slice(0, 500);
      }
      await order.save();
      require('../utils/cache').del('orders:all');
      return res.json(order);
    }

    if (action === 'approve' || action === 'create') {
      if (action === 'approve' && order.returnRequestStatus !== 'pending') {
        return res.status(400).json({ message: 'مفيش طلب استرجاع قيد المراجعة لهذا الطلب' });
      }
      if (action === 'create' && (order.returnRequestStatus === 'pending' || order.returnRequestStatus === 'approved')) {
        return res.status(400).json({ message: 'فيه طلب استرجاع مسجل بالفعل لهذا الطلب' });
      }

      // الأدمن يقدر يعدّل/يحدد المنتجات بنفسه (action='create') أو يستخدم
      // نفس المنتجات اللي طلبها العميل (action='approve' بدون items في الـbody).
      const rawItems = Array.isArray(req.body.items) ? req.body.items : order.returnItems;
      if (!Array.isArray(rawItems) || rawItems.length === 0) {
        return res.status(400).json({ message: 'اختار على الأقل منتج واحد للاسترجاع' });
      }

      const validatedItems = [];
      let refundAmount = 0;
      for (const reqItem of rawItems) {
        const quantity = Number(reqItem.quantity);
        if (!isValidQuantity(quantity)) {
          return res.status(400).json({ message: 'كمية غير صحيحة في أحد المنتجات' });
        }
        const matchingItem = order.items.find(oi =>
          String(oi.productId) === String(reqItem.productId) &&
          String(oi.variantId || '') === String(reqItem.variantId || '') &&
          String(oi.size || '') === String(reqItem.size || '')
        );
        if (!matchingItem) {
          return res.status(400).json({ message: 'أحد المنتجات مش موجود في هذا الطلب' });
        }
        if (quantity > matchingItem.quantity) {
          return res.status(400).json({ message: `الكمية أكبر من الكمية المشتراة لمنتج "${matchingItem.name?.ar || matchingItem.name?.en || ''}"` });
        }
        validatedItems.push({
          productId: matchingItem.productId,
          variantId: matchingItem.variantId || null,
          size: matchingItem.size || null,
          quantity,
          reason: typeof reqItem.reason === 'string' ? reqItem.reason.trim().slice(0, 300) : null,
        });
        refundAmount += Number(matchingItem.price || 0) * quantity;
      }
      refundAmount = Math.round(refundAmount * 100) / 100;

      // ===== رسوم شحن الاسترجاع (لو السبب اختيار العميل مش عيب/غلط منا) =====
      // الأدمن يقدر يعدّل/يصحح السبب وقت المراجعة (مثلاً لو العميل اختار "غيرت
      // رأيي" بس فعليًا اتضح إن فيه عيب في المنتج) عن طريق بعت reasonCode في الـ
      // body؛ لو مش مبعوت بنستخدم السبب اللي اختاره العميل نفسه وقت الطلب.
      let returnFeeCharged = 0;
      const effectiveReasonCode = isValidReasonCode(req.body.reasonCode)
        ? req.body.reasonCode
        : order.returnRequestReasonCode;
      if (effectiveReasonCode) {
        order.returnRequestReasonCode = effectiveReasonCode;
      }
      if (doesReasonApplyFee(effectiveReasonCode)) {
        const settingsDoc = await Settings.findOne().select('returnFeeAmount').lean();
        const configuredFee = Number(settingsDoc?.returnFeeAmount);
        const feeAmount = Number.isFinite(configuredFee) && configuredFee >= 0 ? configuredFee : 80;
        // الرسوم متخصمش أكتر من مبلغ الاسترجاع نفسه (تفضل صفر كحد أدنى).
        returnFeeCharged = Math.min(feeAmount, refundAmount);
        refundAmount = Math.round((refundAmount - returnFeeCharged) * 100) / 100;
      }

      // ===== إرجاع المخزون بالظبط للكميات المسترجعة (مش الطلب كله) =====
      await restoreOrderItems(validatedItems);
      await logMovementsBulk(validatedItems, 'stock_returned', {
        orderId: order._id,
        userId: req.user ? req.user._id : null,
        note: `إرجاع مخزون بسبب موافقة الأدمن على استرجاع منتجات محددة (${action === 'create' ? 'بدأه الأدمن' : 'طلب العميل'})`,
      });
      invalidateProductCaches();

      // ===== تسجيل مبلغ الاسترجاع =====
      const currentRefunded = Number(order.refundedAmount || 0);
      const newRefundedAmount = Math.min(Number(order.totalAmount || 0), Math.round((currentRefunded + refundAmount) * 100) / 100);
      order.refunds = order.refunds || [];
      const baseRefundNote = (typeof req.body.adminNote === 'string' && req.body.adminNote.trim()) || 'استرجاع منتجات محددة من الطلب';
      order.refunds.push({
        amount: refundAmount,
        reason: returnFeeCharged > 0
          ? `${baseRefundNote} (بعد خصم ${returnFeeCharged} ج.م رسوم شحن استرجاع)`
          : baseRefundNote,
        at: new Date(),
        by: req.user ? req.user._id : null,
      });
      order.refundedAmount = newRefundedAmount;
      order.returnFeeCharged = returnFeeCharged;

      order.returnItems = validatedItems;
      order.returnRequestedBy = order.returnRequestedBy || (action === 'create' ? 'admin' : 'customer');
      order.returnRequestStatus = 'approved';
      order.returnReviewedBy = req.user ? req.user._id : null;
      order.returnReviewedAt = new Date();
      if (typeof req.body.adminNote === 'string' && req.body.adminNote.trim()) {
        order.returnAdminNote = req.body.adminNote.trim().slice(0, 500);
      }
      if (req.body.returnShippingCost !== undefined && req.body.returnShippingCost !== null && req.body.returnShippingCost !== '') {
        const cost = Number(req.body.returnShippingCost);
        if (Number.isFinite(cost) && cost >= 0) order.returnShippingCost = cost;
      }
      if (!order.returnRequestedAt) order.returnRequestedAt = new Date();

      // لو كل الكميات اللي في الطلب اترجعت بالكامل، نعتبر الطلب "مرتجع" كليًا
      // (يخرج من حسابات "الطلبات المتسلمة" في لوحة البيانات تلقائيًا).
      const totalOrderedQty = order.items.reduce((s, i) => s + (i.quantity || 1), 0);
      const totalReturnedQty = validatedItems.reduce((s, i) => s + (i.quantity || 1), 0);
      if (totalReturnedQty >= totalOrderedQty) {
        order.status = 'مرتجع';
      }
      // منع أي إرجاع مخزون إضافي تلقائي لو حالة الطلب اتغيرت لـ"مرتجع" بعد
      // كده من مكان تاني (updateOrderStatus) - المخزون رجع بالفعل هنا.
      order.stockRestored = true;
      order.stockRestoredAt = new Date();

      await order.save();
      require('../utils/cache').del('orders:all');
      return res.json(order);
    }

    return res.status(400).json({ message: 'action غير معروف - المتاح: approve, reject, create' });
  } catch (err) {
    console.error('Error reviewing return request:', err);
    res.status(500).json({ message: 'حصل خطأ في مراجعة طلب الاسترجاع', error: err.message });
  }
};

module.exports = {
  createOrder, getOrders, getMyOrders, updateOrderStatus, updatePackerStatus,
  getLoyaltyInfo, confirmWalletPayment,
  // ===== جديد =====
  getPaymentsDashboard, getShippingDashboard, updateOrderShipping, updatePaymentStatus,
  refundOrderPayment, requestReturn, reviewReturnRequest,
};