const express=require('express');
const router=express.Router();
const {protect,access}=require('../middleware/auth');
const c=require('../controllers/shippingController');
router.get('/providers', c.getProviders);
router.get('/capabilities', c.getCapabilitiesList);
router.get('/providers/:key/governorates', c.getProviderGovernorates);
router.post('/rates', c.getRates);
router.post('/providers/:key/connect', protect, access('settings','edit'), c.connectProvider);
router.post('/orders/:orderId/create', protect, access('orders','edit',['call_center','packer']), c.createShipment);
router.post('/orders/:orderId/cancel', protect, access('orders','edit',['call_center','packer']), c.cancelShipment);
router.post('/orders/:orderId/return', protect, access('orders','edit',['call_center','packer']), c.createReturn);
router.post('/orders/:orderId/exchange', protect, access('orders','edit',['call_center','packer']), c.createExchange);
router.get('/orders/:orderId/track', protect, access('orders','view',['call_center','packer']), c.trackShipment);
router.get('/orders/:orderId/label', protect, access('orders','view',['call_center','packer']), c.getLabel);
router.get('/orders/:orderId/label/file', protect, access('orders','view',['call_center','packer']), c.downloadLabel);
// Webhook بوسطة - مفيش protect middleware عمدًا (بوسطة هي اللي بتنادي عليه
// مباشرة مش أي مستخدم مسجل دخول)، الحماية بتحصل بالـsecret في نفس الرابط.
router.post('/webhooks/bosta/:secret', c.handleBostaWebhook);
// نفس الفكرة لـShipBlu - شوف تعليق handleShipBluWebhook في الكونترولر.
router.post('/webhooks/shipblu/:secret', c.handleShipBluWebhook);
module.exports=router;