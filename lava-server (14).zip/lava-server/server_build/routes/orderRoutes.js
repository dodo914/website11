const express = require('express');
const router = express.Router();
const {
  createOrder, getOrders, getMyOrders, updateOrderStatus, updatePackerStatus,
  getLoyaltyInfo, confirmWalletPayment,
  getPaymentsDashboard, getShippingDashboard, updateOrderShipping, updatePaymentStatus,
  refundOrderPayment, requestReturn, reviewReturnRequest,
} = require('../controllers/orderController');
const { protect, authorize, optionalProtect, access } = require('../middleware/auth');
const upload = require('../middleware/upload');
const { validateUploadedImages } = require('../middleware/upload');

router.post('/', optionalProtect, upload.single('screenshot'), validateUploadedImages, createOrder);
router.get('/', protect, access('orders', 'view', ['call_center', 'packer']), getOrders);
router.get('/mine', protect, getMyOrders);
router.get('/loyalty-info', protect, getLoyaltyInfo);

// ===== لوحات البيانات الجديدة =====
router.get('/payments-dashboard', protect, access('payments_dashboard', 'view'), getPaymentsDashboard);
router.get('/shipping-dashboard', protect, access('shipping_dashboard', 'view'), getShippingDashboard);

router.put('/:id/status', protect, access('orders', 'edit', ['call_center']), updateOrderStatus);
router.put('/:id/packer-status', protect, access('orders', 'edit', ['packer']), updatePackerStatus);
router.put('/:id/confirm-payment', protect, access('orders', 'edit', ['call_center']), confirmWalletPayment);
router.put('/:id/payment-status', protect, access('payments_dashboard', 'edit'), updatePaymentStatus);
router.put('/:id/refund', protect, access('payments_dashboard', 'edit'), refundOrderPayment);
router.put('/:id/shipping', protect, access('orders', 'edit', ['call_center']), updateOrderShipping);

// ===== استرجاع منتجات محددة من الطلب =====
// العميل بيطلب (route المفتوحة لأي مستخدم مسجل - بيتحقق داخل الكنترولر إن
// الطلب تابع له فعلاً)، والأدمن بيوافق/يرفض أو يبدأ استرجاع بنفسه.
router.post('/:id/return-request', protect, requestReturn);
router.put('/:id/return-request', protect, access('orders', 'edit', ['call_center']), reviewReturnRequest);

module.exports = router;