const express = require('express');
const router = express.Router();
const { confirmOrderByEmail, cancelOrderByEmail } = require('../controllers/marketingController');
router.get('/order-confirm/:token', confirmOrderByEmail);
router.get('/order-cancel/:token', cancelOrderByEmail);
module.exports = router;