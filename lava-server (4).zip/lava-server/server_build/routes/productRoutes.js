const express = require('express');
const router = express.Router();
const {
  getProducts, getAllProductsAdmin, getProductById,
  createProduct, updateProduct, deleteProduct,
  uploadVariantImages, getInventoryMovements,
} = require('../controllers/productController');
const { protect, authorize } = require('../middleware/auth');
const upload = require('../middleware/upload');
const { validateUploadedImages } = require('../middleware/upload');

router.get('/', getProducts);
router.get('/admin', protect, authorize('admin'), getAllProductsAdmin);
router.get('/inventory/movements', protect, authorize('admin'), getInventoryMovements);
router.get('/:id', getProductById);
router.post('/', protect, authorize('admin'), upload.array('images', 10), validateUploadedImages, createProduct);
router.put('/:id', protect, authorize('admin'), upload.array('images', 10), validateUploadedImages, updateProduct);
router.delete('/:id', protect, authorize('admin'), deleteProduct);
router.post('/:id/variants/:variantIndex/images', protect, authorize('admin'), upload.array('images', 10), validateUploadedImages, uploadVariantImages);

module.exports = router;