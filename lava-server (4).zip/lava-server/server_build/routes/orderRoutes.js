const express = require('express');
const router = express.Router();
const {
  createOrder, getOrders, getMyOrders, updateOrderStatus, updatePackerStatus,
  getLoyaltyInfo, confirmWalletPayment,
  getPaymentsDashboard, getShippingDashboard, updateOrderShipping, updatePaymentStatus,
} = require('../controllers/orderController');
const { protect, authorize, optionalProtect } = require('../middleware/auth');
const upload = require('../middleware/upload');
const { validateUploadedImages } = require('../middleware/upload');

router.post('/', optionalProtect, upload.single('screenshot'), validateUploadedImages, createOrder);
router.get('/', protect, authorize('admin', 'call_center', 'packer'), getOrders);
router.get('/mine', protect, getMyOrders);
router.get('/loyalty-info', protect, getLoyaltyInfo);

// ===== لوحات البيانات الجديدة =====
router.get('/payments-dashboard', protect, authorize('admin'), getPaymentsDashboard);
router.get('/shipping-dashboard', protect, authorize('admin'), getShippingDashboard);

router.put('/:id/status', protect, authorize('admin', 'call_center'), updateOrderStatus);
router.put('/:id/packer-status', protect, authorize('admin', 'packer'), updatePackerStatus);
router.put('/:id/confirm-payment', protect, authorize('admin', 'call_center'), confirmWalletPayment);
router.put('/:id/payment-status', protect, authorize('admin'), updatePaymentStatus);
router.put('/:id/shipping', protect, authorize('admin', 'call_center'), updateOrderShipping);

module.exports = router;
