const express = require('express');
const rateLimit = require('express-rate-limit');
const router = express.Router();
const {
  getPublicSettings, getAdminSettings, updateSettings, uploadSettingsImage, getPublicPixels,
  addProductReview, getProductReviews, getMyReviews, getAdminReviews,
  moderateReview, updateMyReview, deleteReview,
  addContactMessage, getContactMessages, updateContactMessageStatus, deleteContactMessage,
  getStoreHealth,
} = require('../controllers/settingsController');
const { protect, authorize, optionalProtect } = require('../middleware/auth');
const upload = require('../middleware/upload');

const contactLimiter = rateLimit({
  windowMs: 10 * 60 * 1000,
  max: process.env.NODE_ENV === 'production' ? 8 : 50,
  standardHeaders: true,
  legacyHeaders: false,
  message: { message: 'تم إرسال رسائل كثيرة. حاول مرة أخرى لاحقاً.' },
});

router.get('/public', getPublicSettings);
router.get('/pixels', getPublicPixels);
router.get('/admin', protect, authorize('admin'), getAdminSettings);
router.get('/store-health', protect, authorize('admin'), getStoreHealth);
router.put('/', protect, authorize('admin'), updateSettings);
router.post('/image', protect, authorize('admin'), upload.single('image'), require('../middleware/upload').validateUploadedImages, uploadSettingsImage);

// Contact Messages
router.post('/contact', contactLimiter, addContactMessage);
router.get('/contact', protect, authorize('admin'), getContactMessages);
router.patch('/contact/:id/status', protect, authorize('admin'), updateContactMessageStatus);
router.delete('/contact/:id', protect, authorize('admin'), deleteContactMessage);

// Reviews
// Public reads only approved reviews. The write endpoint derives customerId
// from the authenticated user when present and never trusts a frontend ID.
router.post('/reviews', optionalProtect, addProductReview);
router.get('/reviews/mine', protect, authorize('customer'), getMyReviews);
router.get('/reviews', protect, authorize('admin'), getAdminReviews);
router.get('/reviews/:productId', getProductReviews);
router.patch('/reviews/:id/status', protect, authorize('admin'), moderateReview);
router.patch('/reviews/:id', protect, authorize('customer'), updateMyReview);
router.delete('/reviews/:id', protect, authorize('admin', 'customer'), deleteReview);

module.exports = router;
