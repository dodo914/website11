const Product = require('../models/Product');
const InventoryMovement = require('../models/InventoryMovement');
const { uploadImageToCloudinary, deleteImageFromCloudinary, parseCloudinaryPublicId } = require('../utils/uploadToCloudinary');
const { get, set, invalidateProductCaches, CACHE_TTL, CACHE_KEYS } = require('../utils/cache');
const { logActivity } = require('../utils/activityLogger');
const { parsePagination, buildListResponse } = require('../utils/pagination');

const getProductLabel = (p) => (p && p.name && (p.name.ar || p.name.en)) || '';

const normalizeIncomingImage = (item) => {
  if (!item) return null;
  if (typeof item === 'string') {
    if (/^data:image\//i.test(item)) return null;
    const publicId = parseCloudinaryPublicId(item);
    return { url: item, publicId: publicId || undefined };
  }
  if (typeof item === 'object') {
    const url = typeof item.url === 'string' ? item.url : '';
    if (!url || /^data:image\//i.test(url)) return null;
    const publicId = item.publicId || parseCloudinaryPublicId(url);
    return {
      url,
      publicId: publicId || undefined,
      assetId: item.assetId || undefined,
      width: Number(item.width) || undefined,
      height: Number(item.height) || undefined,
      format: item.format || undefined,
    };
  }
  return null;
};

const normalizeImageArray = (images) => (Array.isArray(images) ? images.map(normalizeIncomingImage).filter(Boolean) : []);

const normalizeVariantImageArray = (images) => (Array.isArray(images) ? images.map((img) => {
  if (!img) return null;
  if (typeof img === 'string') {
    if (/^data:image\//i.test(img)) return null;
    return { url: img, publicId: parseCloudinaryPublicId(img) || undefined };
  }
  if (typeof img === 'object' && /^data:image\//i.test(String(img.url || ''))) return null;
  return img;
}).filter(Boolean) : []);

const parseJsonLikeValue = (value) => {
  if (value === undefined || value === null) return null;
  if (typeof value === 'string') {
    const trimmed = value.trim();
    if (!trimmed) return null;

    try {
      return JSON.parse(trimmed);
    } catch (err) {
      if (trimmed.startsWith('{') || trimmed.startsWith('[')) {
        try {
          const cleaned = trimmed
            .replace(/\s*\+\s*['"]?/g, '')
            .replace(/\r?\n/g, ' ')
            .replace(/([{,]\s*)([A-Za-z0-9_$]+)(\s*:)/g, '$1"$2"$3')
            .replace(/'([^'\\]*(?:\\.[^'\\]*)*)'/g, '"$1"')
            .replace(/\s{2,}/g, ' ')
            .trim();

          if (cleaned && cleaned !== trimmed) {
            return JSON.parse(cleaned);
          }

          return Function(`"use strict"; return (${trimmed});`)();
        } catch (innerErr) {
          return value;
        }
      }

      return value;
    }
  }
  return value;
};

const normalizeOfferArray = (offers) => {
  if (!offers) return [];

  const rawList = Array.isArray(offers) ? offers : [offers];
  const normalized = rawList
    .filter(Boolean)
    .map((offer) => {
      if (typeof offer === 'string') {
        const parsed = parseJsonLikeValue(offer);
        if (!parsed || typeof parsed !== 'object') return null;
        return normalizeOfferArray([parsed])[0];
      }

      if (!offer || typeof offer !== 'object') return null;

      return {
        id: offer.id ?? null,
        name: offer.name ?? '',
        type: offer.type ?? 'percentage',
        minQty: Number(offer.minQty ?? 1) || 1,
        discountPercent: Number(offer.discountPercent ?? offer.percentage ?? 0) || 0,
        percentage: Number(offer.percentage ?? offer.discountPercent ?? 0) || 0,
        fixedAmount: Number(offer.fixedAmount ?? 0) || 0,
        buyQty: Number(offer.buyQty ?? 0) || 0,
        freeQty: Number(offer.freeQty ?? 0) || 0,
        active: offer.active !== false,
      };
    })
    .filter(Boolean);

  return normalized;
};

const normalizeBodyPayload = (reqBody) => {
  if (!reqBody) return {};

  if (typeof reqBody === 'string') {
    const parsed = parseJsonLikeValue(reqBody);
    return parsed && typeof parsed === 'object' ? parsed : {};
  }

  if (typeof reqBody === 'object') {
    const hasWrappedData = Object.prototype.hasOwnProperty.call(reqBody, 'data');
    if (hasWrappedData) {
      const parsed = parseJsonLikeValue(reqBody.data);
      if (parsed && typeof parsed === 'object') {
        const merged = { ...parsed, ...reqBody };
        delete merged.data;
        return merged;
      }
    }

    const normalized = { ...reqBody };
    ['images', 'variants', 'offers', 'bundle', 'recommendedIds', 'colors', 'sizes'].forEach((key) => {
      if (Object.prototype.hasOwnProperty.call(normalized, key) && typeof normalized[key] === 'string') {
        const candidate = normalized[key].trim();
        if (candidate.startsWith('{') || candidate.startsWith('[')) {
          const parsed = parseJsonLikeValue(normalized[key]);
          if (parsed !== normalized[key]) {
            normalized[key] = parsed;
          }
        }
      }
    });

    return normalized;
  }

  return reqBody;
};

// ============================================================
// Canonical sizeStock format: Array of { size, sku, stock }
//   [{ size: "S", sku: "...", stock: 10 }, ...]
//
// Legacy data may be stored as Object: { "S": { sku, stock } }
// We safely convert Object → Array. Valid Arrays are preserved.
// Never convert valid data to [].
// ============================================================
const normalizeSizeStock = (sizeStock) => {
  if (Array.isArray(sizeStock)) {
    return sizeStock
      .map((s) => ({
        size: s && s.size != null ? String(s.size) : null,
        sku: s && s.sku != null ? String(s.sku) : '',
        stock: Math.max(0, Number(s && s.stock) || 0),
      }))
      .filter((s) => s.size);
  }
  if (sizeStock && typeof sizeStock === 'object') {
    // Legacy Object format: { "S": { sku, stock } }
    return Object.entries(sizeStock)
      .map(([size, entry]) => ({
        size: String(size),
        sku: entry && entry.sku != null ? String(entry.sku) : '',
        stock: Math.max(0, Number(entry && entry.stock) || 0),
      }))
      .filter((s) => s.size);
  }
  return [];
};

const normalizeVariantsArray = (variants) => (Array.isArray(variants) ? variants.map((v) => ({
  ...v,
  images: normalizeVariantImageArray(v.images),
  sizeStock: normalizeSizeStock(v.sizeStock),
})) : []);

const normalizeObjectIdValue = (value) => {
  if (value === undefined || value === null) return value;
  if (typeof value === 'string') return value;
  if (typeof value.toString === 'function') return value.toString();
  return value;
};

const normalizeProductResponse = (product) => {
  if (!product) return product;
  const normalized = { ...product, id: product.id || normalizeObjectIdValue(product._id) };
  if (Array.isArray(normalized.images)) {
    normalized.images = normalized.images.map((img) => {
      if (!img) return null;
      if (typeof img === 'string') return img;
      return img.url || null;
    }).filter(Boolean);
  }
  if (Array.isArray(normalized.variants)) {
    normalized.variants = normalized.variants.map((variant) => ({
      ...variant,
      // Canonical variant id: prefer custom `id`, fall back to Mongo `_id`
      id: variant.id || normalizeObjectIdValue(variant._id),
      images: Array.isArray(variant.images)
        ? variant.images.map((img) => (typeof img === 'string' ? img : img?.url)).filter(Boolean)
        : [],
      sizeStock: normalizeSizeStock(variant.sizeStock),
    }));
  }
  if (Array.isArray(normalized.recommendedIds)) {
    normalized.recommendedIds = normalized.recommendedIds.map(normalizeObjectIdValue);
  }
  if (normalized.bundle && Array.isArray(normalized.bundle.productIds)) {
    normalized.bundle.productIds = normalized.bundle.productIds.map(normalizeObjectIdValue);
  }
  return normalized;
};

const normalizeProductArrayResponse = (products) => Array.isArray(products) ? products.map(normalizeProductResponse) : [];

const findRemovedImages = (existing = [], incoming = []) => {
  const incomingUrls = new Set((incoming || []).map(img => img.url));
  return (existing || []).filter(img => img.url && !incomingUrls.has(img.url));
};

const getVariantKey = (variant) => variant.id || variant._id?.toString();

const findRemovedVariantImages = (existingVariants = [], incomingVariants = []) => {
  const incomingByKey = new Map((incomingVariants || []).map(v => [getVariantKey(v), v]));
  return (existingVariants || []).flatMap((existingVariant, index) => {
    const key = getVariantKey(existingVariant) || String(index);
    const incomingVariant = incomingByKey.get(key) || incomingVariants[index] || { images: [] };
    const incomingUrls = new Set((incomingVariant.images || []).map(img => img.url));
    return (existingVariant.images || []).filter(img => img.url && !incomingUrls.has(img.url));
  });
};

// يبني فلتر Mongo من query params الاختيارية (بحث/تصنيف/حالة العرض...)
// كل الفلترة server-side — الفرونت مش محتاج يحمّل كل المنتجات ويبحث في المتصفح.
const buildProductFilter = (query = {}, baseFilter = {}) => {
  const filter = { ...baseFilter };

  if (query.category) {
    filter.$or = [{ 'category.ar': query.category }, { 'category.en': query.category }];
  }

  if (query.onSale === 'true') filter.onSale = true;
  if (query.isFeatured === 'true') filter.isFeatured = true;

  if (query.search) {
    const term = String(query.search).trim();
    if (term) {
      const regex = new RegExp(term.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i');
      const searchOr = [{ 'name.ar': regex }, { 'name.en': regex }, { slug: regex }];
      // لو كان فيه فلتر category قبل كده (بيستخدم $or)، لازم ندمجهم بـ $and
      if (filter.$or) {
        filter.$and = [{ $or: filter.$or }, { $or: searchOr }];
        delete filter.$or;
      } else {
        filter.$or = searchOr;
      }
    }
  }

  return filter;
};

const buildProductSort = (query = {}) => {
  const allowedSortFields = ['createdAt', 'price', 'name.ar'];
  const sortField = allowedSortFields.includes(query.sortBy) ? query.sortBy : 'createdAt';
  const sortDir = query.sortDir === 'asc' ? 1 : -1;
  return { [sortField]: sortDir };
};

// GET /api/products  (عام - لكل الزوار) - مع caching + pagination/filtering اختيارية
const getProducts = async (req, res) => {
  try {
    const { isPaginated, page, limit, skip } = parsePagination(req.query, { maxLimit: 100, defaultLimit: 24 });
    const hasFilters = !!(req.query.category || req.query.search || req.query.onSale || req.query.isFeatured || req.query.sortBy);

    // المسار السريع (بدون فلاتر/pagination صريحة): نستخدم كاش القائمة الكاملة زي ما كان
    if (!isPaginated && !hasFilters) {
      const cached = get(CACHE_KEYS.PRODUCTS);
      if (cached) {
        return res.json(cached);
      }

      const products = await Product.find({ visibility: 'published' })
        .sort({ createdAt: -1 })
        .limit(500) // سقف أمان حتى في المسار القديم
        .lean();

      const normalizedProducts = normalizeProductArrayResponse(products);
      set(CACHE_KEYS.PRODUCTS, normalizedProducts, CACHE_TTL.PRODUCTS);
      return res.json(normalizedProducts);
    }

    // مسار الفلترة/الـ pagination الحقيقية (server-side بالكامل)
    const filter = buildProductFilter(req.query, { visibility: 'published' });
    const sort = buildProductSort(req.query);

    const [products, total] = await Promise.all([
      Product.find(filter).sort(sort).skip(skip).limit(limit).lean(),
      Product.countDocuments(filter),
    ]);

    const normalizedProducts = normalizeProductArrayResponse(products);
    res.json(buildListResponse({ isPaginated: true, page, limit, items: normalizedProducts, total }));
  } catch (err) {
    console.error('Error fetching products:', err);
    res.status(500).json({ message: 'حصل خطأ في جلب المنتجات', error: err.message });
  }
};

// GET /api/products/admin  (كل المنتجات حتى المخفية - أدمن بس) - مع caching + pagination/filtering اختيارية
const getAllProductsAdmin = async (req, res) => {
  try {
    const { isPaginated, page, limit, skip } = parsePagination(req.query, { maxLimit: 100, defaultLimit: 24 });
    const hasFilters = !!(req.query.category || req.query.search || req.query.visibility || req.query.sortBy);

    if (!isPaginated && !hasFilters) {
      const cached = get(CACHE_KEYS.PRODUCT_ADMIN);
      if (cached) {
        return res.json(cached);
      }

      const products = await Product.find()
        .sort({ createdAt: -1 })
        .limit(1000) // سقف أمان حتى في المسار القديم
        .lean();

      const normalizedProducts = normalizeProductArrayResponse(products);
      set(CACHE_KEYS.PRODUCT_ADMIN, normalizedProducts, CACHE_TTL.PRODUCTS);
      return res.json(normalizedProducts);
    }

    const baseFilter = req.query.visibility ? { visibility: req.query.visibility } : {};
    const filter = buildProductFilter(req.query, baseFilter);
    const sort = buildProductSort(req.query);

    const [products, total] = await Promise.all([
      Product.find(filter).sort(sort).skip(skip).limit(limit).lean(),
      Product.countDocuments(filter),
    ]);

    const normalizedProducts = normalizeProductArrayResponse(products);
    res.json(buildListResponse({ isPaginated: true, page, limit, items: normalizedProducts, total }));
  } catch (err) {
    console.error('Error fetching admin products:', err);
    res.status(500).json({ message: 'حصل خطأ في جلب المنتجات', error: err.message });
  }
};

// GET /api/products/:id
const getProductById = async (req, res) => {
  try {
    const { id } = req.params;
    
    // Try cache first
    const cacheKey = CACHE_KEYS.PRODUCT_DETAIL(id);
    const cached = get(cacheKey);
    if (cached) {
      return res.json(cached);
    }

    // Fetch from database
    const product = await Product.findById(id).lean();
    if (!product) {
      return res.status(404).json({ message: 'المنتج مش موجود' });
    }

    const normalizedProduct = normalizeProductResponse(product);
    // Cache the result
    set(cacheKey, normalizedProduct, CACHE_TTL.PRODUCT_DETAIL);
    
    res.json(normalizedProduct);
  } catch (err) {
    console.error('Error fetching product:', err);
    res.status(500).json({ message: 'حصل خطأ في جلب المنتج', error: err.message });
  }
};


const containsDataImage = (value) => {
  if (typeof value === 'string') return /^data:image\//i.test(value);
  if (Array.isArray(value)) return value.some(containsDataImage);
  if (value && typeof value === 'object') return Object.values(value).some(containsDataImage);
  return false;
};

const uploadProductFiles = async (files, folder = 'products') => {
  const uploaded = [];
  try {
    for (const file of files || []) {
      uploaded.push(await uploadImageToCloudinary(
        file.buffer,
        file.safeOriginalName || file.originalname,
        file.detectedMime || file.mimetype,
        { folder },
      ));
    }
    return uploaded;
  } catch (err) {
    // Best-effort rollback of assets uploaded earlier in this request.
    await Promise.allSettled(uploaded.map((image) => deleteImageFromCloudinary(image)));
    throw err;
  }
};

const safeUploadErrorResponse = (res, err, fallbackMessage) => {
  if (err?.code === 'CLOUDINARY_UPLOAD_FAILED') {
    return res.status(err.statusCode || 502).json({
      message: 'تعذر رفع الصورة إلى التخزين. لم يتم حفظ التغييرات.',
    });
  }
  return res.status(err?.statusCode || 500).json({
    message: fallbackMessage,
  });
};

// POST /api/products  (أدمن بس) - بيانات المنتج + صور (multipart/form-data)
const createProduct = async (req, res) => {
  try {
    const body = normalizeBodyPayload(req.body);
    if (containsDataImage(body)) {
      return res.status(400).json({ message: 'الصورة يجب رفعها عبر مسار الرفع المخصص، وليس داخل بيانات المنتج.' });
    }
    const files = req.files || [];

    const uploadedImages = await uploadProductFiles(files, 'products');

    const options = {
      ...body,
      images: [...normalizeImageArray(body.images), ...uploadedImages],
      variants: normalizeVariantsArray(body.variants),
      offers: normalizeOfferArray(body.offers),
    };

    if (!Array.isArray(options.offers) && Array.isArray(body.offers)) {
      options.offers = body.offers.map((offer) => normalizeOfferArray([offer])[0]).filter(Boolean);
    }

    const product = await Product.create(options);

    // Invalidate caches
    invalidateProductCaches();

    const normalizedProduct = normalizeProductResponse(product.toObject ? product.toObject() : product);

    logActivity(req, {
      action: 'create',
      entityType: 'product',
      entityId: product._id,
      entityLabel: getProductLabel(normalizedProduct),
    });

    res.status(201).json({ success: true, data: normalizedProduct });
  } catch (err) {
    console.error('Error creating product:', err);
    return safeUploadErrorResponse(res, err, 'حصل خطأ في إضافة المنتج');
  }
};

// PUT /api/products/:id  (أدمن بس)
const updateProduct = async (req, res) => {
  try {
    const product = await Product.findById(req.params.id);
    if (!product) {
      return res.status(404).json({ message: 'المنتج مش موجود' });
    }

    const body = normalizeBodyPayload(req.body);
    if (containsDataImage(body)) {
      return res.status(400).json({ message: 'الصورة يجب رفعها عبر مسار الرفع المخصص، وليس داخل بيانات المنتج.' });
    }
    const files = req.files || [];

    const uploadedImages = await uploadProductFiles(files, 'products');

    const incomingImages = [...normalizeImageArray(body.images), ...uploadedImages];
    const incomingVariants = normalizeVariantsArray(body.variants);
    const incomingOffers = normalizeOfferArray(body.offers);

    if (!Array.isArray(incomingOffers) || incomingOffers.length === 0) {
      const parsedOffers = Array.isArray(body.offers) ? body.offers : [];
      const rebuiltOffers = parsedOffers
        .map((offer) => normalizeOfferArray([offer])[0])
        .filter(Boolean);
      if (rebuiltOffers.length > 0) {
        incomingOffers.push(...rebuiltOffers);
      }
    }

    const removedProductImages = findRemovedImages(product.images, incomingImages);
    const removedVariantImages = findRemovedVariantImages(product.variants, incomingVariants);

    const safeBody = { ...body };
    delete safeBody.data;
    delete safeBody.images;
    delete safeBody.variants;
    delete safeBody.offers;
    delete safeBody.recommendedIds;
    delete safeBody.bundle;
    // ===== إزالة الحقول المحمية التي تسبب VersionError في Mongoose =====
    // الفرونت بيبعت أحياناً كائن المنتج الكامل (بما فيه _id و __v و createdAt و updatedAt)
    // لو اتحطت __v بقيمة قديمة، Mongoose بيعمل optimistic concurrency check ويفشل الحفظ.
    delete safeBody._id;
    delete safeBody.id;
    delete safeBody.__v;
    delete safeBody.createdAt;
    delete safeBody.updatedAt;

    const finalOffers = body.offers !== undefined
      ? normalizeOfferArray(body.offers)
      : Array.isArray(product.offers)
        ? product.offers
        : [];

    const normalizedOfferPayload = Array.isArray(finalOffers) && finalOffers.length > 0
      ? finalOffers
      : (Array.isArray(incomingOffers) ? incomingOffers : []);


    // ===== معالجة recommendedIds و bundle صراحةً =====
    const incomingRecommendedIds = body.recommendedIds !== undefined
      ? (Array.isArray(body.recommendedIds) ? body.recommendedIds : [])
      : (Array.isArray(product.recommendedIds) ? product.recommendedIds.map(normalizeObjectIdValue) : []);

    const incomingBundle = body.bundle !== undefined
      ? {
          productIds: Array.isArray(body.bundle && body.bundle.productIds) ? body.bundle.productIds : [],
          discountPercent: Number((body.bundle && body.bundle.discountPercent) || 0),
        }
      : {
          productIds: Array.isArray(product.bundle && product.bundle.productIds) ? product.bundle.productIds.map(normalizeObjectIdValue) : [],
          discountPercent: Number((product.bundle && product.bundle.discountPercent) || 0),
        };

    product.images = incomingImages;
    product.variants = incomingVariants;
    product.offers = normalizedOfferPayload;
    product.recommendedIds = incomingRecommendedIds;
    product.bundle = incomingBundle;
    product.markModified('images');
    product.markModified('variants');
    product.markModified('offers');
    product.markModified('recommendedIds');
    product.markModified('bundle');

    Object.keys(safeBody).forEach((key) => {
      if (key === 'offers') return;
      product.set(key, safeBody[key]);
    });
    product.set({
      images: product.images,
      variants: product.variants,
      offers: product.offers,
      recommendedIds: product.recommendedIds,
      bundle: product.bundle,
    });

    try {
      await product.save();
    } catch (saveError) {
      await Promise.allSettled(uploadedImages.map((image) => deleteImageFromCloudinary(image)));
      throw saveError;
    }

    // Only remove old assets after MongoDB has successfully committed the new references.
    await Promise.allSettled([
      ...removedProductImages.map((img) => deleteProductImageIfOrphaned(img, req.params.id)),
      ...removedVariantImages.map((img) => deleteProductImageIfOrphaned(img, req.params.id)),
    ]);

    const reloadedProduct = await Product.findById(req.params.id).lean();

    // Data loss check removed - was causing false positives when offers normalize to empty

    invalidateProductCaches();

    const normalized = normalizeProductResponse(reloadedProduct || (product.toObject ? product.toObject() : product));

    const priceChanged = safeBody.price !== undefined && Number(safeBody.price) !== Number(reloadedProduct?.price);
    logActivity(req, {
      action: 'update',
      entityType: 'product',
      entityId: req.params.id,
      entityLabel: getProductLabel(normalized),
      description: priceChanged
        ? `${req.user?.name || 'أدمن'} غيّر سعر المنتج "${getProductLabel(normalized)}"`
        : undefined,
    });

    res.json(normalized);
  } catch (err) {
    console.error('Error updating product:', err);
    return safeUploadErrorResponse(res, err, 'حصل خطأ في تعديل المنتج');
  }
};


const deleteProductImageIfOrphaned = async (imageRef, currentProductId) => {
  const publicId = imageRef?.publicId || parseCloudinaryPublicId(
    typeof imageRef === 'string' ? imageRef : imageRef?.url,
  );
  if (!publicId) return;

  const referenced = await Product.exists({
    _id: { $ne: currentProductId },
    $or: [
      { 'images.publicId': publicId },
      { 'variants.images.publicId': publicId },
    ],
  });

  if (!referenced) {
    await deleteImageFromCloudinary({ publicId });
  }
};

// DELETE /api/products/:id  (أدمن بس)
const deleteProduct = async (req, res) => {
  try {
    const product = await Product.findById(req.params.id);
    if (!product) {
      return res.status(404).json({ message: 'المنتج مش موجود' });
    }

    const imagesToCleanup = [
      ...(product.images || []),
      ...(product.variants || []).flatMap((v) => v.images || []),
    ];

    const deletedLabel = getProductLabel(product);
    await product.deleteOne();

    // DB deletion succeeded; now remove assets only if no other product references them.
    await Promise.allSettled(
      imagesToCleanup.map((img) => deleteProductImageIfOrphaned(img, req.params.id))
    );

    // Invalidate caches
    invalidateProductCaches();

    logActivity(req, {
      action: 'delete',
      entityType: 'product',
      entityId: req.params.id,
      entityLabel: deletedLabel,
    });

    res.json({ success: true, data: { id: req.params.id, deleted: true } });
  } catch (err) {
    console.error('Error deleting product:', err);
    res.status(500).json({ message: 'حصل خطأ في حذف المنتج', error: err.message });
  }
};

// POST /api/products/:id/variants/:variantIndex/images  (أدمن بس)
// بيرفع صور إضافية لفاريانت (لون) معين ويضيفها لصوره الموجودة
const uploadVariantImages = async (req, res) => {
  try {
    const product = await Product.findById(req.params.id);
    if (!product) {
      return res.status(404).json({ message: 'المنتج مش موجود' });
    }

    const idx = Number(req.params.variantIndex);
    if (!product.variants[idx]) {
      return res.status(404).json({ message: 'الفاريانت مش موجود' });
    }

    const files = req.files || [];
    const uploadedImages = await uploadProductFiles(files, 'products');
    product.variants[idx].images = [...(product.variants[idx].images || []), ...uploadedImages];

    try {
      await product.save();
    } catch (saveError) {
      await Promise.allSettled(uploadedImages.map((image) => deleteImageFromCloudinary(image)));
      throw saveError;
    }

    // Invalidate caches
    invalidateProductCaches();

    res.json(normalizeProductResponse(product.toObject ? product.toObject() : product));
  } catch (err) {
    console.error('Error uploading variant images:', err);
    return safeUploadErrorResponse(res, err, 'حصل خطأ في رفع صور الفاريانت');
  }
};

// GET /api/products/inventory/movements  (أدمن بس) — سجل حركة المخزون، paginated دائمًا
// فلاتر اختيارية: ?productId=...&reason=stock_sold&page=1&limit=50
const getInventoryMovements = async (req, res) => {
  try {
    const { page, limit, skip } = parsePagination(req.query, { maxLimit: 200, defaultLimit: 50 });

    const filter = {};
    if (req.query.productId) filter.product = req.query.productId;
    if (req.query.reason) filter.reason = req.query.reason;
    if (req.query.orderId) filter.order = req.query.orderId;

    const [movements, total] = await Promise.all([
      InventoryMovement.find(filter)
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(limit)
        .populate('product', 'name slug')
        .lean(),
      InventoryMovement.countDocuments(filter),
    ]);

    res.json(buildListResponse({ isPaginated: true, page, limit, items: movements, total }));
  } catch (err) {
    console.error('Error fetching inventory movements:', err);
    res.status(500).json({ message: 'حصل خطأ في جلب سجل حركة المخزون', error: err.message });
  }
};

module.exports = {
  getProducts, getAllProductsAdmin, getProductById,
  createProduct, updateProduct, deleteProduct,
  uploadVariantImages, getInventoryMovements,
};