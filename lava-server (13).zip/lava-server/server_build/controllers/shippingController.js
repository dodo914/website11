const { publicConfig, getProvider, getConfig, rates } = require('../services/shipping');
const { normalizeStatus } = require('../services/shipping/statusMap');
const { getCoverageWithRates } = require('../services/shipping/config');
const Settings = require('../models/Settings');
const Order = require('../models/Order');

// شركات الشحن اللي بالفعل خلّصت شحنتها بنجاح - ممنوع نعمل لها Shipment تاني
// (Duplicate Shipment Protection). لو الحالة "failed"/"pending" مسموح بالـRetry.
const ALREADY_SHIPPED_STATUSES = new Set([
  'shipped', 'created', 'picked_up', 'in_transit', 'out_for_delivery', 'delivered',
]);

// بنجمع إعدادات الـ.env مع الإعدادات المحفوظة من الأدمن (تفعيل/تعطيل، الدول)
// لأن قبل كده كان في تعارض: الأدمن يفعّل الشركة من الإعدادات، بس أي مكان
// بيستخدم getConfig() لوحدها كان بيتجاهل الحفظ ده وبيفضل شغال بقيمة الـ.env بس.
async function getMergedConfig(key) {
  const base = getConfig(key);
  if (!base) return base;
  const settings = await Settings.findOne().lean();
  const saved = settings?.shippingIntegrations?.[key] || {};
  return { ...base, ...saved };
}

const connectProvider = async (req, res) => {
  try {
    const key = String(req.params.key).toLowerCase();
    const p = getProvider(key);
    const config = await getMergedConfig(key);
    const result = await p.test(config);
    res.json({ ok: true, provider: key, result });
  } catch (e) { res.status(e.status || 400).json({ ok: false, message: e.message }); }
};

const getProviders = async (req, res) => {
  const settings = await Settings.findOne().lean();
  const base = publicConfig();
  const saved = settings?.shippingIntegrations || {};
  for (const key of Object.keys(base)) {
    if (saved[key]) base[key] = { ...base[key], ...saved[key], configured: base[key].configured };
  }
  res.json({ providers: base });
};

const getRates = async (req, res) => {
  try {
    const settings = await Settings.findOne().lean();
    const saved = settings?.shippingIntegrations || {};
    const order = {
      _id: 'quote', country: req.body.country, governorate: req.body.governorate, address: req.body.address,
      zipCode: req.body.zipCode, customerName: req.body.customerName, customerPhone: req.body.customerPhone,
      totalAmount: req.body.totalAmount, paymentMethod: req.body.paymentMethod, items: req.body.items || [],
    };
    const all = await rates(order, saved);
    const allowed = all.filter(r => {
      const cfg = saved[r.provider];
      if (cfg && cfg.enabled === false) return false;
      if (cfg?.countries?.length && req.body.countryCode && !cfg.countries.includes(req.body.countryCode)) return false;
      return true;
    });
    res.json({ rates: allowed });
  } catch (e) { res.status(500).json({ message: e.message }); }
};

// تحقق من البيانات الأساسية المطلوبة لأي شركة شحن قبل إرسال الطلب لها
// (Validation - قاعدة 43). منمنعش الطلب لو ناقص، وبنرجع رسالة واضحة للأدمن.
function validateOrderForShipping(order) {
  const missing = [];
  if (!order.customerName) missing.push('اسم العميل (customerName)');
  if (!order.customerPhone) missing.push('رقم هاتف العميل (customerPhone)');
  if (!order.address) missing.push('عنوان الشحن (address)');
  if (!order.governorate) missing.push('المحافظة (governorate)');
  return missing;
}

const createShipment = async (req, res) => {
  try {
    const order = await Order.findById(req.params.orderId);
    if (!order) return res.status(404).json({ message: 'الطلب غير موجود' });

    // Duplicate Shipment Protection: لو فيه شحنة موجودة بالفعل وناجحة/في تقدم،
    // امنع إنشاء شحنة ثانية سواء ضغط الأدمن على الزر مرتين أو حصل retry غلط.
    if (order.trackingNumber && ALREADY_SHIPPED_STATUSES.has(order.shippingStatus)) {
      return res.status(409).json({
        ok: false,
        message: `تم إنشاء شحنة لهذا الطلب بالفعل (${order.shippingCompany || ''} - ${order.trackingNumber})`,
        order,
      });
    }

    const key = String(req.body.provider || order.shippingCompany || '').toLowerCase();
    if (!key) return res.status(400).json({ message: 'يجب تحديد شركة الشحن' });

    const config = await getMergedConfig(key);
    if (!config) return res.status(400).json({ message: `شركة الشحن غير مدعومة: ${key}` });
    if (config.enabled === false) {
      return res.status(400).json({ message: `شركة الشحن (${config.name || key}) غير مفعّلة حاليًا في الإعدادات` });
    }

    const missing = validateOrderForShipping(order);
    if (missing.length) {
      return res.status(422).json({ message: `بيانات ناقصة في الطلب لإنشاء الشحنة: ${missing.join('، ')}` });
    }

    const p = getProvider(key);
    let result;
    try {
      result = await p.createShipment(order, config);
    } catch (providerErr) {
      // فشل الاتصال بشركة الشحن: الطلب (Order) لازم يفضل موجود، وبس بنسجل
      // الخطأ على الشحنة (Shipment = failed) عشان الأدمن يقدر يعمل Retry.
      order.shippingCompany = key;
      order.shippingStatus = 'failed';
      order.shippingError = providerErr.message || 'فشل إنشاء الشحنة';
      order.shippingUpdatedAt = new Date();
      await order.save();
      return res.status(providerErr.status || 400).json({ ok: false, message: providerErr.message, order });
    }

    order.shippingCompany = key;
    order.trackingNumber = result.trackingNumber || result.shipmentId || null;
    order.shippingProviderId = result.shipmentId || result.trackingNumber || null;
    order.shippingLabelUrl = result.labelUrl || null;
    order.shippingStatus = 'shipped';
    order.shippingError = null;
    order.shippedAt = new Date();
    order.shippingCreatedAt = order.shippingCreatedAt || new Date();
    order.shippingUpdatedAt = new Date();
    await order.save();
    res.json({ ok: true, shipment: result, order });
  } catch (e) { res.status(e.status || 400).json({ ok: false, message: e.message }); }
};

const trackShipment = async (req, res) => {
  try {
    const order = await Order.findById(req.params.orderId);
    if (!order) return res.status(404).json({ message: 'الطلب غير موجود' });
    const key = String(req.query.provider || order.shippingCompany || '').toLowerCase();
    if (!key) return res.status(400).json({ message: 'يجب تحديد شركة الشحن' });
    if (!order.trackingNumber) return res.status(400).json({ message: 'لا يوجد Tracking Number للطلب' });

    const config = await getMergedConfig(key);
    if (!config) return res.status(400).json({ message: `شركة الشحن غير مدعومة: ${key}` });

    const result = await getProvider(key).track(order.trackingNumber, config);
    const internalStatus = normalizeStatus(key, result.status);

    // بنحدّث حالة الطلب فعليًا بالحالة الداخلية الموحدة عشان الـAdmin يشوف
    // آخر حالة معروفة بدل ما الـTracking يفضل بس عرض مؤقت من غير حفظ.
    if (internalStatus && internalStatus !== order.shippingStatus) {
      order.shippingStatus = internalStatus;
      order.shippingUpdatedAt = new Date();
      if (internalStatus === 'delivered' && !order.deliveredAt) order.deliveredAt = new Date();
      await order.save();
    }

    res.json({ ok: true, ...result, internalStatus, order });
  } catch (e) { res.status(e.status || 400).json({ ok: false, message: e.message }); }
};

// GET /api/shipping/providers/:key/governorates
// بترجع كل المحافظات اللي شركة الشحن دي بتوصلها + السعر المحدد لكل واحدة
// (لو الأدمن حدده من قبل)، عشان تتعرض في لوحة التحكم (لملء الأسعار) وفي
// صفحة التشيك أوت (يشوف العميل كل المحافظات وأسعارها قبل ما يختار بتاعته).
const getProviderGovernorates = async (req, res) => {
  try {
    const key = String(req.params.key).toLowerCase();
    const settings = await Settings.findOne().lean();
    const saved = settings?.shippingIntegrations?.[key] || {};
    const governorateRates = saved.governorateRates || {};
    const governorates = getCoverageWithRates(key, governorateRates);
    res.json({ provider: key, governorates });
  } catch (e) { res.status(500).json({ message: e.message }); }
};

module.exports = { connectProvider, getProviders, getRates, getProviderGovernorates, createShipment, trackShipment };