const { requestJson } = require('./http');
const { getEnvConfig, resolveBaseUrl } = require('./config');
function clientInfo(c) { return { UserName:c.username, Password:c.password, Version:'1.0', AccountNumber:c.accountNumber, AccountPin:c.accountPin, AccountEntity:c.accountEntity, AccountCountryCode:c.countryCode, Source:24 }; }
function address(c, order, origin=false) { return origin ? {Line1:c.pickupAddress, City:c.pickupCity, PostCode:c.pickupPostCode, CountryCode:c.countryCode, Phone:c.pickupPhone, ContactPerson:c.pickupName} : {Line1:order.address||'', City:order.governorate||'', PostCode:order.zipCode||'', CountryCode:countryToCode(order.country)||'EG', Phone:order.customerPhone||'', ContactPerson:order.customerName||''}; }
function countryToCode(name) { const m={'مصر':'EG','Egypt':'EG','السعودية':'SA','Saudi Arabia':'SA','الإمارات':'AE','UAE':'AE','الكويت':'KW','Kuwait':'KW'}; return m[name] || (String(name||'').length===2?String(name).toUpperCase():''); }
// بعد الدمج مع إعدادات الأدمن (تجريبي/حقيقي)، لازم نعيد حساب baseUrl بناءً
// على البيئة النهائية المختارة، مش اللي كانت متحسوبة وقت قراءة الـ.env بس.
function cfg(custom={}) {
  const merged = {...getEnvConfig().aramex,...custom};
  merged.baseUrl = resolveBaseUrl('aramex', merged.environment, process.env.ARAMEX_BASE_URL);
  // في وضع التجريبي، لو متسجل حساب Aramex اختباري منفصل بنستخدمه؛ لو مش
  // موجود بيفضل يستخدم بيانات حساب الإنتاج (Aramex عادة بتقبلها على السيرفر التجريبي).
  if (String(merged.environment).toLowerCase() !== 'production' && merged.sandboxUsername) {
    merged.username = merged.sandboxUsername; merged.password = merged.sandboxPassword;
    merged.accountNumber = merged.sandboxAccountNumber; merged.accountPin = merged.sandboxAccountPin;
    merged.accountEntity = merged.sandboxAccountEntity;
  }
  return merged;
}
// أسماء الـ services في Aramex REST API لازم تبقى بالحروف دي بالظبط (case-sensitive)،
// والمسار الصحيح فيه "ShippingAPI.V2" مش "shippingapi" — ده كان سبب فشل الاتصال بالكامل.
const ARAMEX_SERVICE_PATHS = { tracking: 'Tracking', ratecalculator: 'RateCalculator', shipping: 'Shipping' };
async function call(c, service, operation, body) {
  const servicePath = ARAMEX_SERVICE_PATHS[String(service).toLowerCase()] || service;
  return requestJson(`${c.baseUrl}/ShippingAPI.V2/${servicePath}/Service_1_0.svc/json/${operation}`, {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
}
async function test(custom={}) { const c=cfg(custom); if(!c.username||!c.password||!c.accountNumber||!c.accountPin||!c.accountEntity) throw new Error('بيانات Aramex غير مكتملة'); return call(c,'tracking','TrackShipments',{ClientInfo:clientInfo(c), Shipments:['0000000000'], GetLastTrackingUpdateOnly:true}); }
async function rate(order, custom={}) { const c=cfg(custom); if(!c.username) throw new Error('بيانات Aramex غير مكتملة'); const body={ClientInfo:clientInfo(c), Transaction:{Reference1:String(order._id||'quote')}, OriginAddress:address(c,order,true), DestinationAddress:address(c,order,false), ShipmentDetails:{NumberOfPieces:1, ProductGroup:'EXP', ProductType:'OND', PaymentType:'P', PaymentOptions:'ACCT', ActualWeight:{Value:1,Unit:'KG'}, ChargeableWeight:{Value:1,Unit:'KG'}}}; const data=await call(c,'ratecalculator','CalculateRate',body); const total=data?.TotalAmount?.Value ?? data?.RateResult?.TotalAmount?.Value ?? data?.data?.TotalAmount?.Value; if(total==null) throw new Error('Aramex لم يرجع سعرًا'); return {amount:Number(total),currency:data?.TotalAmount?.Currency||'EGP',raw:data}; }
async function createShipment(order, custom={}) { const c=cfg(custom); if(!c.username||!c.password||!c.accountNumber||!c.accountPin||!c.accountEntity) throw new Error('بيانات Aramex غير مكتملة (ARAMEX_USERNAME/PASSWORD/ACCOUNT_NUMBER/ACCOUNT_PIN/ACCOUNT_ENTITY)'); const body={ClientInfo:clientInfo(c),LabelInfo:{ReportID:9201,ReportType:'URL'},Shipments:[{Reference1:String(order._id),Shipper:{Reference1:String(order._id),AccountNumber:c.accountNumber,PartyAddress:address(c,order,true)},Consignee:{Reference1:String(order._id),PartyAddress:address(c,order,false)},ShippingDateTime:new Date().toISOString(),DueDate:new Date(Date.now()+5*86400000).toISOString(),Comments:'LAVA order',Details:{Dimensions:{Length:10,Width:10,Height:10,Unit:'CM'},ActualWeight:{Value:1,Unit:'KG'},ProductGroup:'EXP',ProductType:'OND',PaymentType:order.paymentMethod==='cod'?'C':'P',PaymentOptions:'ACCT',NumberOfPieces:1,DescriptionOfGoods:'LAVA order',GoodsOriginCountry:'EG',Items:[]}}]}; const data=await call(c,'shipping','CreateShipments',body); const s=data?.Shipments?.[0]||data?.data?.Shipments?.[0]||data?.data||data; return {raw:data,shipmentId:s?.ID||s?.ShipmentNumber,trackingNumber:s?.ID||s?.ShipmentNumber,labelUrl:s?.ShipmentLabel?.LabelURL||s?.LabelURL}; }
async function track(trackingNumber, custom={}) { const c=cfg(custom); if(!c.username||!c.password||!c.accountNumber||!c.accountPin||!c.accountEntity) throw new Error('بيانات Aramex غير مكتملة'); const data=await call(c,'tracking','TrackShipments',{ClientInfo:clientInfo(c),Shipments:[trackingNumber]}); const s=data?.TrackingResults?.[0]||data?.data?.[0]||{}; return {raw:data,status:s?.UpdateCode||s?.UpdateDescription||s?.Status}; }
module.exports={test,rate,createShipment,track};