async function requestJson(url, options = {}) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), options.timeout || 15000);
  try {
    const response = await fetch(url, { ...options, signal: controller.signal });
    const text = await response.text();
    let data = null;
    try { data = text ? JSON.parse(text) : {}; } catch { data = { raw: text }; }
    if (!response.ok) {
      const message = data?.message || data?.error || data?.raw || `HTTP ${response.status}`;
      const err = new Error(message); err.status = response.status; err.data = data; throw err;
    }
    return data;
  } finally { clearTimeout(timeout); }
}
module.exports = { requestJson };
