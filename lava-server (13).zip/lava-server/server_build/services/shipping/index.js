const { getEnvConfig, publicConfig } = require('./config');
const providers = { bosta: require('./bostaService'), aramex: require('./aramexService'), dhl: require('./dhlService') };
function getProvider(key){ const p=providers[String(key||'').toLowerCase()]; if(!p) throw new Error(`شركة الشحن غير مدعومة: ${key}`); return p; }
function getConfig(key){ return getEnvConfig()[key]; }
async function rates(order, saved = {}){
  const configs=getEnvConfig(); const out=[];
  for(const key of Object.keys(providers)){
    const c={...configs[key], ...(saved[key]||{})};
    if(c.enabled===false || (key!=='bosta' && !c.username)) continue;
    try { const result=key==='bosta'?providers[key].rate(order,c):await providers[key].rate(order,c); if(result) out.push({provider:key,name:c.name,...result}); }
    catch(error){ out.push({provider:key,name:c.name,error:error.message}); }
  }
  return out;
}
module.exports={providers,getProvider,getConfig,publicConfig,rates};
