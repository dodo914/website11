const { requestJson } = require('./http');
const { getEnvConfig, resolveBaseUrl, lookupGovernorateRate } = require('./config');

// بعد الدمج مع إعدادات الأدمن (تجريبي/حقيقي)، لازم نعيد حساب baseUrl بناءً
// على البيئة النهائية المختارة، مش اللي كانت متحسوبة وقت قراءة الـ.env بس.
function cfg(custom = {}) {
  const merged = { ...getEnvConfig().bosta, ...custom };
  merged.baseUrl = resolveBaseUrl('bosta', merged.environment, process.env.BOSTA_BASE_URL);
  // في وضع التجريبي (Sandbox) بنستخدم مفتاح الحساب التجريبي لو متسجل، لأن
  // مفتاح الإنتاج الحقيقي مش هيتعرف عليه سيرفر الـ Staging بتاع بوسطة.
  if (String(merged.environment).toLowerCase() !== 'production' && merged.sandboxApiKey) {
    merged.apiKey = merged.sandboxApiKey;
  }
  return merged;
}
async function test(custom = {}) {
  const c = cfg(custom); if (!c.apiKey) throw new Error('BOSTA_API_KEY غير موجود');
  // baseUrl بقى شامل نسخة الـ API (/api/v2) فمفيش داعي نضيف مسار نسخة تاني هنا.
  return requestJson(`${c.baseUrl}/pickup-locations`, { headers: { Authorization: c.apiKey, 'Content-Type':'application/json' } });
}
function rate({ subtotal = 0, countryCode = 'EG', governorate = '' } = {}, custom = {}) {
  const c = cfg(custom);
  if (countryCode !== 'EG') return null;
  // أولوية سعر المحافظة المحدد (governorateRates)، ولو مفيش نرجع لسعر
  // موحّد لكل البلد (defaultRate). لو مفيش أي منهم، معنى كده لسه محددش
  // سعر أصلاً، فبنرجع null (مش صفر) عشان الواجهة تعرف إن السعر لسه مش متاح.
  const govRate = lookupGovernorateRate(c.governorateRates, governorate);
  const amount = govRate != null ? govRate : (Number(c.defaultRate) > 0 ? Number(c.defaultRate) : null);
  if (amount == null) return null;
  return { amount, currency: 'EGP', provider: 'bosta', source: govRate != null ? 'governorate' : 'default' };
}
async function createShipment(order, custom = {}) {
  const c = cfg(custom); if (!c.apiKey) throw new Error('BOSTA_API_KEY غير موجود');
  const payload = {
    type: 10,
    specs: { packageType: 'Small', packageDetails: { description: `LAVA Order ${order._id}`, itemsCount: order.items?.length || 1 } },
    receiver: { firstName: order.customerName || 'Customer', lastName: '', phone: order.customerPhone, secondPhone: order.customerPhone2 || '', email: order.customerEmail || '' },
    dropOffAddress: { firstLine: order.address || '', secondLine: '', city: order.governorate || '', zone: '', buildingNumber: '', floor: '', apartment: '' },
    cod: order.paymentMethod === 'cod' ? Number(order.totalAmount || 0) : 0,
    businessReference: String(order._id),
  };
  if (c.pickupId) payload.pickupAddress = { pickupId: c.pickupId };
  const data = await requestJson(`${c.baseUrl}/deliveries`, { method:'POST', headers:{Authorization:c.apiKey,'Content-Type':'application/json'}, body:JSON.stringify(payload) });
  return { raw:data, shipmentId:data?._id || data?.data?._id || data?.trackingNumber || data?.data?.trackingNumber, trackingNumber:data?.trackingNumber || data?.data?.trackingNumber || data?._id || data?.data?._id };
}
async function track(trackingNumber, custom = {}) {
  const c = cfg(custom); if (!c.apiKey) throw new Error('BOSTA_API_KEY غير موجود');
  // لازم "/tracking" في الآخر عشان يرجع حالة الشحنة - من غيرها بترجع بيانات
  // الشحنة العادية بس من غير حالة تتبع حقيقية.
  const data = await requestJson(`${c.baseUrl}/deliveries/${encodeURIComponent(trackingNumber)}/tracking`, { headers:{Authorization:c.apiKey} });
  return { raw:data, status:data?.state || data?.status || data?.data?.state || data?.data?.status };
}
module.exports = { test, rate, createShipment, track };