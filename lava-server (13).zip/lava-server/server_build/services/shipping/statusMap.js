// Internal (موحّدة) shipping statuses تُستخدم في الـAdmin وفي Order.shippingStatus.
// كل Provider بيرجع أسماء حالات مختلفة تمامًا، فبنعمل mapping لأقرب حالة داخلية
// معروفة. لو حالة الشركة مش معروفة، بنرجعها زي ما هي (fallback) بدل ما نضيّع
// المعلومة أو نخترع حالة غير موجودة فعليًا عند الشركة.
const INTERNAL_STATUSES = [
  'pending', 'created', 'picked_up', 'in_transit', 'out_for_delivery',
  'delivered', 'cancelled', 'failed', 'returned',
];

// Bosta states (حسب التوثيق العام لحالات "state"/"code" الشائعة).
const BOSTA_MAP = {
  '10': 'created', 'created': 'created',
  '20': 'picked_up', 'pickedup': 'picked_up', 'picked_up': 'picked_up',
  '30': 'in_transit', 'intransit': 'in_transit',
  '40': 'out_for_delivery', 'headingtocustomer': 'out_for_delivery',
  '45': 'delivered', 'delivered': 'delivered',
  '46': 'failed_delivery', 'notdelivered': 'failed',
  '50': 'returned', 'returntobusiness': 'returned',
  'canceled': 'cancelled', 'cancelled': 'cancelled',
};

// Aramex UpdateCode القياسية.
const ARAMEX_MAP = {
  'sh001': 'in_transit', 'sh005': 'delivered', 'sh007': 'failed',
  'sh012': 'out_for_delivery', 'sh013': 'picked_up', 'sh026': 'returned',
  'cancelled': 'cancelled',
};

// DHL Express tracking event typeCode القياسية.
const DHL_MAP = {
  'pu': 'picked_up', 'pl': 'in_transit', 'ar': 'in_transit', 'dp': 'in_transit',
  'wc': 'out_for_delivery', 'od': 'out_for_delivery',
  'dd': 'delivered', 'de': 'delivered',
  'cc': 'cancelled', 'rt': 'returned', 'ex': 'failed',
};

const PROVIDER_MAPS = { bosta: BOSTA_MAP, aramex: ARAMEX_MAP, dhl: DHL_MAP };

function normalizeStatus(provider, rawStatus) {
  if (!rawStatus) return 'pending';
  const map = PROVIDER_MAPS[String(provider || '').toLowerCase()] || {};
  const key = String(rawStatus).trim().toLowerCase();
  return map[key] || (INTERNAL_STATUSES.includes(key) ? key : 'pending');
}

module.exports = { INTERNAL_STATUSES, normalizeStatus };