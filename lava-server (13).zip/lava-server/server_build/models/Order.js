const mongoose = require('mongoose');

const orderItemSchema = new mongoose.Schema({
  productId: { type: mongoose.Schema.Types.ObjectId, ref: 'Product' },
  name: { type: mongoose.Schema.Types.Mixed, default: null },
  variantId: String,
  size: String,
  color: { type: mongoose.Schema.Types.Mixed, default: null },
  colorHex: { type: String, default: null },
  productImage: { type: String, default: null },
  price: Number,          // السعر الفعلي اللي دفعه العميل (بعد أي خصم باندل)
  originalPrice: Number,  // السعر الأصلي للمنتج قبل خصم الباندل
  costPrice: Number,
  quantity: { type: Number, default: 1 },
  // ===== حقول الباندل =====
  isBundleItem: { type: Boolean, default: false },
  bundleDiscount: { type: Number, default: 0 },
}, { _id: false });

const orderSchema = new mongoose.Schema({
  customerId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },
  customerName: { type: String, required: true },
  customerPhone: { type: String, required: true },
  customerPhone2: String,
  customerEmail: String,
  emailConfirmation: {
    enabled: { type: Boolean, default: false },
    confirmed: { type: Boolean, default: false },
    confirmedAt: { type: Date, default: null },
    messageId: { type: String, default: null },
    // ===== حالة إرسال رسالة/واتساب تأكيد الطلب في الخلفية =====
    // not_sent: مفيش رسالة اتجدولت أصلاً. pending: اتجدولت ولسه مبعتتش.
    // sent: اتبعتت بنجاح. failed: فشلت بعد استنفاد كل محاولات الـ retry.
    status: { type: String, enum: ['not_sent', 'pending', 'sent', 'failed'], default: 'not_sent' },
  },
  items: [orderItemSchema],
  subtotal: Number,
  discount: Number,
  discountType: String,
  discountCode: String,
  promoLabel: String,
  shippingCost: Number,
  totalAmount: Number,
  governorate: String,
  country: String,
  address: String,
  zipCode: String,
  notes: String,
  status: { type: String, default: 'جديد' },
  packerStatus: { type: String, default: 'لم يتم التجهيز' },

  // ===== الدفع =====
  paymentMethod: { type: String, default: 'cod', enum: ['cod', 'wallet', 'kashier', 'paymob'] }, // 'cod' | 'wallet' | 'kashier' | 'paymob'
  paymentStatus: { type: String, default: 'pending', enum: ['pending', 'paid', 'failed', 'refunded'] },
  walletPayment: {
    methodId: { type: String, default: null },
    methodName: { type: String, default: null },
    walletPhoneNumber: { type: String, default: null },
    senderPhone: { type: String, default: null },
    transferDate: { type: String, default: null },
    screenshotUrl: { type: String, default: null },
    screenshotPublicId: { type: String, default: null },
    confirmed: { type: Boolean, default: false },
    confirmedAt: { type: Date, default: null },
  },

  // ===== الشحن =====
  shippingStatus: {
    type: String,
    default: 'pending',
    // القيم القديمة اتسابت زي ما هي بالظبط عشان منكسرش أي Order/Filter قديم.
    // اتضاف عليها الحالات الداخلية الموحدة (Internal Statuses) اللي بيرجعها
    // نظام الشحن الجديد بعد ما يعمل Normalize لاستجابة Bosta/Aramex/DHL.
    enum: [
      'pending', 'preparing', 'shipped', 'delivered', 'failed_delivery', 'returned',
      'created', 'picked_up', 'in_transit', 'out_for_delivery', 'cancelled', 'failed',
    ]
  },
  shippingCompany: { type: String, default: null },
  shippingProviderId: { type: String, default: null },
  shippingLabelUrl: { type: String, default: null },   // اسم شركة الشحن (Aramex, Bosta, J&T...)
  trackingNumber: { type: String, default: null },    // رقم التتبع
  shippingNotes: { type: String, default: null },     // ملاحظات الشحن / مشاكل
  // رسالة الخطأ لو فشل إنشاء/تحديث الشحنة مع شركة الشحن (بدون أي Secrets).
  // الطلب (Order) نفسه بيفضل موجود دايمًا حتى لو فشلت الشحنة.
  shippingError: { type: String, default: null },
  shippingCreatedAt: { type: Date, default: null },   // وقت أول محاولة ناجحة لإنشاء الشحنة
  shippingUpdatedAt: { type: Date, default: null },   // آخر تحديث لحالة الشحنة (إنشاء/تتبع/فشل)
  shippedAt: { type: Date, default: null },           // تاريخ الشحن الفعلي
  deliveredAt: { type: Date, default: null },         // تاريخ الاستلام الفعلي

  // ===== حماية المخزون من الاسترجاع المكرر =====
  // stockRestored: بيبقى true أول ما يتم إرجاع المخزون بسبب إلغاء/رفض/ارتجاع،
  // عشان لو حد نادى على endpoint الإلغاء أكتر من مرة، المخزون ميترجعش مرتين.
  stockRestored: { type: Boolean, default: false },
  stockRestoredAt: { type: Date, default: null },

  // ===== مراجع بوابة الدفع (Kashier / Paymob) — بتتسجل لما الطلب يتدفع =====
  // لازمة عشان نقدر نعمل refund (استرجاع فلوس) من خلال الـ API بتاع البوابة،
  // لأن الاسترجاع محتاج رقم عملية البوابة نفسها، مش رقم الأوردر عندنا.
  paymentGateway: {
    kashierOrderId: { type: String, default: null }, // رقم أوردر Kashier الداخلي (مختلف عن merchantOrderId)
    transactionId: { type: String, default: null },  // رقم العملية (Kashier transactionId أو Paymob transaction id)
  },

  // ===== سجل عمليات الاسترجاع (استرجاع كامل أو جزئي) =====
  refunds: [{
    amount: { type: Number, required: true },
    reason: { type: String, default: null },
    at: { type: Date, default: Date.now },
    by: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },
    gatewayResponse: { type: mongoose.Schema.Types.Mixed, default: null },
  }],
  // إجمالي المبلغ اللي اترجع لحد دلوقتي (بيسمح بعمل استرجاع جزئي أكتر من مرة)
  refundedAmount: { type: Number, default: 0 },
}, {
  timestamps: true,
  toJSON: { virtuals: false },
  toObject: { virtuals: false },
});

orderSchema.index({ createdAt: -1 });
orderSchema.index({ customerId: 1, createdAt: -1 });
orderSchema.index({ status: 1, createdAt: -1 });
orderSchema.index({ paymentMethod: 1, createdAt: -1 });
orderSchema.index({ paymentStatus: 1, createdAt: -1 });
orderSchema.index({ shippingStatus: 1, createdAt: -1 });
orderSchema.index({ shippingCompany: 1 });
orderSchema.index({ trackingNumber: 1 });
orderSchema.index({ customerEmail: 1 });
orderSchema.index({ customerPhone: 1 });
orderSchema.index({ 'items.productId': 1 });

module.exports = mongoose.model('Order', orderSchema);