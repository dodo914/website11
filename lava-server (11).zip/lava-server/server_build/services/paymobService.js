const crypto = require('crypto');

// Paymob Unified Intention API (the current recommended integration — replaces
// the old 3-step auth/order/key flow). Docs: https://developers.paymob.com/egypt/unified-checkout
const PAYMOB_API_BASE = 'https://accept.paymob.com';
const PAYMOB_INTENTION_URL = `${PAYMOB_API_BASE}/v1/intention/`;
const PAYMOB_CHECKOUT_URL = `${PAYMOB_API_BASE}/unifiedcheckout/`;

const isConfigured = () => Boolean(
  String(process.env.PAYMOB_SECRET_KEY || '').trim() &&
  String(process.env.PAYMOB_PUBLIC_KEY || '').trim() &&
  String(process.env.PAYMOB_INTEGRATION_ID || '').trim()
);

const getCurrency = () => String(process.env.PAYMOB_CURRENCY || 'EGP').trim() || 'EGP';

const getIntegrationIds = () => String(process.env.PAYMOB_INTEGRATION_ID || '')
  .split(',')
  .map((s) => Number(String(s).trim()))
  .filter((n) => Number.isFinite(n) && n > 0);

// اختياري بالكامل: لو عايز تقفل الـ intention على وسيلة واحدة بس (مثلاً
// العميل دوس "ادفع بفودافون كاش" في موقعك)، ضيف في .env متغير منفصل لكل
// وسيلة، مثلاً:
//   PAYMOB_INTEGRATION_ID_CARD=5885103
//   PAYMOB_INTEGRATION_ID_WALLET=5885230
// لو المتغير مش موجود لأي وسيلة، أو preferredMethod مش متبعت أصلاً، الكود
// بيرجع لسلوكه القديم زي ما هو بالظبط (كل الـ IDs من PAYMOB_INTEGRATION_ID).
const PAYMOB_METHOD_ENV_KEYS = {
  card: 'PAYMOB_INTEGRATION_ID_CARD',
  wallet: 'PAYMOB_INTEGRATION_ID_WALLET',
};

const getIntegrationIdsForMethod = (method) => {
  const envKey = PAYMOB_METHOD_ENV_KEYS[String(method || '').trim().toLowerCase()];
  if (!envKey) return null; // وسيلة غير معروفة -> استخدم القائمة الكاملة
  const ids = String(process.env[envKey] || '')
    .split(',')
    .map((s) => Number(String(s).trim()))
    .filter((n) => Number.isFinite(n) && n > 0);
  return ids.length > 0 ? ids : null; // المتغير مش مضبوط -> استخدم القائمة الكاملة
};

const getFrontendUrl = () => {
  const configured = String(process.env.FRONTEND_URL || process.env.CLIENT_URL || '').trim();
  if (configured) return configured.replace(/\/$/, '');
  if (String(process.env.NODE_ENV || '').toLowerCase() !== 'production') return 'http://localhost:5173';
  return '';
};

const getBackendUrl = () => {
  const configured = String(process.env.BACKEND_URL || '').trim();
  if (configured) return configured.replace(/\/$/, '');
  if (String(process.env.NODE_ENV || '').toLowerCase() !== 'production') {
    const port = Number(process.env.PORT || 5000);
    return `http://localhost:${Number.isFinite(port) && port > 0 ? port : 5000}`;
  }
  return '';
};

const getCallbackUrl = () => {
  const explicit = String(process.env.PAYMOB_CALLBACK_URL || '').trim();
  if (explicit) return explicit;

  // Browser return URL: Paymob redirects the customer here after checkout,
  // then we redirect on to the frontend. Same pattern as Kashier's callback.
  const base = getBackendUrl();
  return base ? `${base}/api/payments/paymob/callback` : '';
};

const getWebhookUrl = () => {
  // IMPORTANT: do not send a localhost/private URL to Paymob — the server-to-server
  // "Transaction Processed Callback" needs a publicly reachable HTTPS URL.
  const explicit = String(process.env.PAYMOB_WEBHOOK_URL || '').trim();
  if (explicit) return explicit;
  return '';
};

const splitName = (fullName) => {
  const name = String(fullName || '').trim();
  if (!name) return { first: 'NA', last: 'NA' };
  const parts = name.split(/\s+/);
  if (parts.length === 1) return { first: parts[0], last: 'NA' };
  return { first: parts[0], last: parts.slice(1).join(' ') };
};

// Paymob's billing_data requires every one of these keys to be present and
// non-empty, even though our checkout only collects a subset (name/phone/email
// /address/governorate). Missing address parts are filled with "NA" — Paymob
// accepts this and it does not affect the actual payment/order.
const buildBillingData = ({ customerName, customerEmail, customerPhone, address, governorate, country }) => {
  const { first, last } = splitName(customerName);
  return {
    first_name: first,
    last_name: last,
    email: String(customerEmail || 'no-email@lava-store.com').trim() || 'no-email@lava-store.com',
    phone_number: String(customerPhone || 'NA').trim() || 'NA',
    apartment: 'NA',
    floor: 'NA',
    street: String(address || 'NA').trim() || 'NA',
    building: 'NA',
    city: String(governorate || 'NA').trim() || 'NA',
    state: String(governorate || 'NA').trim() || 'NA',
    country: String(country || 'EG').trim() || 'EG',
    postal_code: 'NA',
  };
};

// Creates a Paymob "intention" (a hosted-checkout session) and returns the
// Unified Checkout URL to redirect the customer to. Mirrors kashierService's
// buildPaymentUrl(), but Paymob's flow needs a server-side API call first
// (Kashier's hosted checkout is just a signed URL, no pre-call needed).
const createPaymentIntention = async ({ orderId, amount, customerName, customerEmail, customerPhone, address, governorate, country, preferredMethod }) => {
  if (!isConfigured()) {
    const err = new Error('Paymob is not configured');
    err.code = 'PAYMOB_NOT_CONFIGURED';
    throw err;
  }

  // لو الفرونت إند بعت preferredMethod ('card' أو 'wallet') وفيه متغير env
  // مضبوط ليها، نبعت لـ Paymob integration ID واحد بس فتفتح صفحة الدفع
  // مباشرة عليه من غير قائمة اختيار. غير كده، نرجع للسلوك القديم (كل الـ IDs).
  const integrationIds = getIntegrationIdsForMethod(preferredMethod) || getIntegrationIds();
  if (integrationIds.length === 0) {
    const err = new Error('PAYMOB_INTEGRATION_ID is missing or invalid');
    err.code = 'PAYMOB_NOT_CONFIGURED';
    throw err;
  }

  const currency = getCurrency();
  const amountCents = Math.round(Number(amount) * 100);
  const callbackUrl = getCallbackUrl();
  const webhookUrl = getWebhookUrl();

  if (!webhookUrl) {
    // بدون notification_url (webhook)، Paymob مش هيبعت أي إشعار سيرفر-لسيرفر بعد
    // الدفع أو في حالة الاسترجاع (refund) من لوحة Paymob — فالطلب هيفضل شكله زي
    // ما هو عندنا في الداتابيز حتى لو اتعمله دفع أو استرجاع فعلي على Paymob.
    console.warn('⚠️  PAYMOB_WEBHOOK_URL غير مضبوط في .env — إشعارات Paymob (خصوصًا الاسترجاع/refund) لن تصل للسيرفر ولن تنعكس على الأدمن أو العميل. اضبط PAYMOB_WEBHOOK_URL على دومين عام (https) يشير لـ /api/payments/paymob/webhook.');
  }

  if (!callbackUrl) {
    const err = new Error('PAYMOB_CALLBACK_URL or BACKEND_URL is required');
    err.code = 'PAYMOB_CALLBACK_MISSING';
    throw err;
  }

  const body = {
    amount: amountCents,
    currency,
    payment_methods: integrationIds,
    items: [],
    billing_data: buildBillingData({ customerName, customerEmail, customerPhone, address, governorate, country }),
    // special_reference must be unique per merchant — our order id fits perfectly,
    // and Paymob echoes it back as order.merchant_order_id on both the webhook
    // and the browser redirect, which is how we look the order back up.
    special_reference: String(orderId),
    extras: { merchantOrderId: String(orderId) },
    redirection_url: callbackUrl,
  };
  if (webhookUrl) body.notification_url = webhookUrl;

  let response;
  let data;
  try {
    response = await fetch(PAYMOB_INTENTION_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Token ${String(process.env.PAYMOB_SECRET_KEY).trim()}`,
      },
      body: JSON.stringify(body),
    });
    data = await response.json().catch(() => ({}));
  } catch (networkErr) {
    const err = new Error(`Paymob intention request failed: ${networkErr.message}`);
    err.code = 'PAYMOB_REQUEST_FAILED';
    throw err;
  }

  if (!response.ok || !data?.client_secret) {
    const err = new Error(`Paymob intention creation failed: ${response.status} ${JSON.stringify(data)}`);
    err.code = 'PAYMOB_INTENTION_FAILED';
    throw err;
  }

  const publicKey = String(process.env.PAYMOB_PUBLIC_KEY).trim();
  const paymentUrl = `${PAYMOB_CHECKOUT_URL}?publicKey=${encodeURIComponent(publicKey)}&clientSecret=${encodeURIComponent(data.client_secret)}`;

  // DEBUG (تشخيص مؤقت): بنسأل Paymob مباشرة "إيه وسايل الدفع اللي فعليًا
  // live على الـ intention ده؟" — ده هو نفس المصدر اللي صفحة Unified Checkout
  // بتعتمد عليه في إظهار/إخفاء التابات. لو "Wallets" مش موجودة أو live=false
  // هنا، فالمشكلة من حساب/تفعيل Paymob مش من الكود اللي بيبعت الـ payment_methods.
  // احذف الاستدعاء ده بعد ما تخلص تشخيص لو مش عايزه في اللوج بشكل دائم.
  debugLogIntentionPaymentMethods(publicKey, data.client_secret);

  return { paymentUrl, intentionId: data.id || null, clientSecret: data.client_secret };
};

const debugLogIntentionPaymentMethods = async (publicKey, clientSecret) => {
  try {
    const url = `${PAYMOB_API_BASE}/v1/intention/element/${encodeURIComponent(publicKey)}/${encodeURIComponent(clientSecret)}/`;
    const res = await fetch(url);
    const json = await res.json().catch(() => null);
    const methods = json?.payment_methods || [];
    console.log('🔍 Paymob intention payment_methods:', JSON.stringify(methods));
    const wallet = methods.find((m) => String(m?.name || '').toLowerCase().includes('wallet'));
    if (!wallet) {
      console.warn('⚠️  "Wallets" مش راجعة خالص في قائمة وسائل الدفع — على الأغلب integration 5885230 لسه مش مفعّلة (Pending) عند Paymob، أو مش من نوع صحيح لحساب المحافظ. راجع Payment Integrations في الداشبورد.');
    } else if (wallet.live !== true) {
      console.warn('⚠️  "Wallets" موجودة بس live=false — يعني Paymob شايفة الـ integration ID بس مش مفعّلة فعليًا (Pending activation من حساب مانجر Paymob).');
    } else {
      console.log('✅ Wallets integration شغالة (live=true) — لو لسه مش ظاهرة في الصفحة، جرب تفتح اللينك من متصفح تاني/incognito (كاش الصفحة).');
    }
  } catch (err) {
    console.error('Paymob debug intention element fetch failed:', err.message);
  }
};

// Reads a value from either shape Paymob sends us:
//  - webhook JSON body: nested objects, e.g. obj.order.id, obj.source_data.pan
//  - browser callback query string: flat keys that are LITERALLY the dotted
//    name, e.g. req.query['source_data.pan'] (Express does not nest dotted
//    query keys by default), plus a flat "order" key (the Paymob order id).
const getField = (source, dottedKey) => {
  if (!source) return undefined;
  if (Object.prototype.hasOwnProperty.call(source, dottedKey)) return source[dottedKey];
  const parts = dottedKey.split('.');
  let val = source;
  for (const part of parts) {
    if (val == null) return undefined;
    val = val[part];
  }
  return val;
};

// Official field order used to build the HMAC signature string for both the
// "Transaction Processed Callback" (webhook) and the browser response
// callback. Docs: https://developers.paymob.com/egypt/manage-transactions/transaction-webhooks
const HMAC_FIELDS = [
  'amount_cents', 'created_at', 'currency', 'error_occured', 'has_parent_transaction',
  'id', 'integration_id', 'is_3d_secure', 'is_auth', 'is_capture', 'is_refunded',
  'is_standalone_payment', 'is_voided', 'order.id', 'owner', 'pending',
  'source_data.pan', 'source_data.sub_type', 'source_data.type', 'success',
];

const verifyHmac = (source, hmacParam) => {
  if (!source || !hmacParam) return false;
  const hmacSecret = String(process.env.PAYMOB_HMAC_SECRET || '');
  if (!hmacSecret) return false;

  const concatenated = HMAC_FIELDS.map((key) => {
    let value;
    if (key === 'order.id') {
      // Nested (webhook): obj.order.id — Flat (browser callback): query.order
      value = getField(source, 'order.id');
      if (value === undefined) value = getField(source, 'order');
    } else {
      value = getField(source, key);
    }
    if (value === undefined || value === null) return '';
    if (typeof value === 'boolean') return value ? 'true' : 'false';
    return String(value);
  }).join('');

  const expected = crypto.createHmac('sha512', hmacSecret).update(concatenated).digest('hex');
  try {
    return crypto.timingSafeEqual(Buffer.from(expected, 'hex'), Buffer.from(String(hmacParam), 'hex'));
  } catch {
    return false; // length/format mismatch -> treat as invalid
  }
};

const asBool = (val) => val === true || val === 'true';

// Normalizes the two very different payload shapes (webhook JSON body vs.
// browser redirect query string) into one flat, consistent result — same
// idea as kashierService.normalizePaymentResult().
const normalizePaymentResult = (payload = {}) => {
  // Webhook body is { type: 'TRANSACTION', obj: {...} }. The browser callback
  // query string is already flat, so `obj` falls back to the payload itself.
  const obj = payload.obj || payload;

  let orderId = getField(obj, 'merchant_order_id');
  if (orderId == null) orderId = getField(obj, 'order.merchant_order_id');
  if (orderId == null) {
    // Fall back to what we stashed in `extras` when creating the intention.
    orderId = getField(obj, 'extras.merchantOrderId') || getField(obj, 'merchantOrderId');
  }

  const success = asBool(getField(obj, 'success'));
  const pending = asBool(getField(obj, 'pending'));
  const isRefunded = asBool(getField(obj, 'is_refunded'));
  const isVoided = asBool(getField(obj, 'is_voided'));
  const errorOccured = asBool(getField(obj, 'error_occured'));
  const amountCents = getField(obj, 'amount_cents');
  const currency = getField(obj, 'currency');
  const hmac = getField(payload, 'hmac') || getField(obj, 'hmac');

  const refunded = isRefunded;
  const failed = !refunded && !isVoided && !pending && (errorOccured || success === false);
  const isSuccess = !refunded && !isVoided && success === true;

  return {
    orderId: orderId != null ? String(orderId) : null,
    amount: amountCents != null ? Number(amountCents) / 100 : null,
    currency: currency ? String(currency) : null,
    hmac: hmac ? String(hmac) : null,
    pending,
    success: isSuccess,
    failed,
    refunded,
    raw: payload,
    hmacSource: obj,
  };
};

module.exports = {
  PAYMOB_CHECKOUT_URL,
  isConfigured,
  getCurrency,
  getFrontendUrl,
  getBackendUrl,
  getCallbackUrl,
  getWebhookUrl,
  createPaymentIntention,
  verifyHmac,
  normalizePaymentResult,
};