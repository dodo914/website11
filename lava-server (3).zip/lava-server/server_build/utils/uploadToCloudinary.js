const cloudinary = require('cloudinary').v2;
const crypto = require('crypto');

cloudinary.config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET,
  secure: true,
});

const parseCloudinaryPublicId = (imageUrl) => {
  if (!imageUrl || !imageUrl.includes('cloudinary.com')) return null;
  const token = '/image/upload/';
  const idx = imageUrl.indexOf(token);
  if (idx === -1) return null;

  let publicId = imageUrl.substring(idx + token.length);
  publicId = publicId.replace(/^v\d+\//, '');
  publicId = publicId.replace(/\.[a-zA-Z0-9]+(\?.*)?$/, '');
  return publicId;
};

const getCloudinaryPublicId = (imageRef) => {
  if (!imageRef) return null;
  if (typeof imageRef === 'string') {
    return parseCloudinaryPublicId(imageRef);
  }
  if (typeof imageRef === 'object') {
    if (imageRef.publicId) return imageRef.publicId;
    if (imageRef.url) return parseCloudinaryPublicId(imageRef.url);
  }
  return null;
};

// Upload image buffer to Cloudinary and return structured metadata
const uploadImageToCloudinary = async (fileBuffer, originalName, mimetype) => {
  const publicId = `${Date.now()}-${crypto.randomBytes(6).toString('hex')}`;
  const dataUri = `data:${mimetype};base64,${fileBuffer.toString('base64')}`;

    try {
    const result = await cloudinary.uploader.upload(dataUri, {
      folder: 'products',
      public_id: publicId,
      overwrite: true,
      resource_type: 'image',
    });
    return { url: result.secure_url, publicId: result.public_id };
  } catch (err) {
    console.error('Cloudinary upload error:', err.message);
    // fallback: return data URI so product can still be created (development fallback)
    return { url: dataUri, publicId: undefined, _fallback: true };
  }
};

const deleteImageFromCloudinary = async (imageRef) => {
  const publicId = getCloudinaryPublicId(imageRef);
  if (!publicId) return;

  try {
    await cloudinary.uploader.destroy(publicId, { invalidate: true, resource_type: 'image' });
  } catch (err) {
    console.error('تعذّر مسح الصورة من Cloudinary:', err.message);
  }
};

module.exports = { uploadImageToCloudinary, deleteImageFromCloudinary, parseCloudinaryPublicId };
