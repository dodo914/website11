const jwt = require('jsonwebtoken');
const User = require('../models/User');
const { AUTH_COOKIE_NAME } = require('../utils/cookieAuth');

// بيقرأ التوكن من الـ HttpOnly Cookie بدل ما ياخده من Authorization header
// (اللي كان معتمد على إن الفرونت يخزنه في localStorage)
const getTokenFromRequest = (req) => {
  return req.cookies?.[AUTH_COOKIE_NAME] || null;
};

// بيتأكد إن فيه توكن صحيح جوه الـ Cookie
const protect = async (req, res, next) => {
  const token = getTokenFromRequest(req);

  if (!token) {
    return res.status(401).json({ message: 'لازم تسجل دخول الأول' });
  }

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = await User.findById(decoded.id).select('-password');
    if (!req.user) {
      return res.status(401).json({ message: 'المستخدم غير موجود' });
    }
    return next();
  } catch (err) {
    return res.status(401).json({ message: 'التوكن غير صالح أو منتهي' });
  }
};

// بيتأكد إن دور المستخدم مسموح له بالعملية دي
// استخدام: authorize('admin') أو authorize('admin', 'call_center')
// ملحوظة أمان: الدور بيتقرا دايماً من req.user اللي جاي من الـ DB بعد التحقق من
// التوكن في middleware "protect" — مفيش أي اعتماد على role قادم من الـ frontend.
const authorize = (...roles) => {
  return (req, res, next) => {
    if (!req.user || !roles.includes(req.user.role)) {
      return res.status(403).json({ message: 'مالكش صلاحية تعمل العملية دي' });
    }
    next();
  };
};

// بيحط req.user لو في توكن صحيح جوه الكوكي، وبيكمل عادي لو مفيش (للـ guests)
const optionalProtect = async (req, res, next) => {
  const token = getTokenFromRequest(req);
  if (!token) return next();
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = await User.findById(decoded.id).select('-password');
  } catch (err) {
    // توكن غلط أو منتهي - نكمل كـ guest بدون خطأ
  }
  next();
};

module.exports = { protect, authorize, optionalProtect };