const mongoose = require('mongoose');

const addressSchema = new mongoose.Schema({
  governorate: String,
  country: String,
  address: String,
  zipCode: String,
  phone2: String,
}, { _id: false });

const userSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true, maxlength: 120 },
  email: { type: String, required: true, unique: true, lowercase: true, trim: true },
  // Password is optional because Email + Code customers do not need one.
  password: { type: String, default: null, select: true },
  phone: { type: String, default: '', trim: true },
  role: {
    type: String,
    enum: ['customer', 'admin', 'call_center', 'packer'],
    default: 'customer',
  },
  savedShipping: addressSchema,
  firstOrderDiscountUsed: { type: Boolean, default: false },

  // ===== نظام الولاء =====
  loyaltyOrderCount: { type: Number, default: 0 },
  loyaltyCodes: [{ type: String }],
  loyaltyCodesUsed: [{ type: String }],
}, { timestamps: true });

userSchema.index({ email: 1 }, { unique: true });
userSchema.index({ role: 1 });
userSchema.index({ role: 1, createdAt: -1 });
userSchema.index({ phone: 1 });

module.exports = mongoose.model('User', userSchema);