const Settings = require('../models/Settings');
const Order = require('../models/Order');
const MarketingMessage = require('../models/MarketingMessage');
const AbandonedCart = require('../models/AbandonedCart');
const { sendEmail, sendWhatsApp, configured, orderStatusHtml, abandonedCartHtml, campaignHtml } = require('./brevoService');

const esc = s => String(s ?? '').replace(/[&<>\"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const render = (s, ctx) => String(s || '').replace(/\{\{\s*([\w.-]+)\s*\}\}/g, (_, k) => { let v=ctx; for(const p of k.split('.')) v=v?.[p]; return v==null?'':String(v); });

// يبني شكل HTML حلو للرسالة حسب نوعها (بنفس تصميم صندوق تأكيد الطلب)، ولو حصل أي خطأ بيرجع نص بسيط بدل ما يفشل الإرسال كله.
async function buildEmailHtml(job) {
  try {
    if (job.kind === 'order_status') {
      const sep = String(job.entityId || '').indexOf(':');
      const orderId = sep >= 0 ? job.entityId.slice(0, sep) : job.entityId;
      const statusValue = sep >= 0 ? job.entityId.slice(sep + 1) : (job.subject || '');
      const order = await Order.findById(orderId).lean();
      if (order) return orderStatusHtml(order, statusValue, job.content);
    } else if (job.kind === 'abandoned_cart') {
      const cart = await AbandonedCart.findById(job.entityId).lean();
      if (cart) return abandonedCartHtml(cart, job.content, job.couponCode || '');
    } else if (job.kind === 'campaign') {
      return campaignHtml(job.subject, job.content);
    }
  } catch (e) {
    console.error('buildEmailHtml:', e.message);
  }
  return `<div style="font-family:Arial;direction:rtl;white-space:pre-wrap">${esc(job.content)}</div>`;
}

async function processQueue() {
  if (!configured()) return;
  const now = new Date();
  const jobs = await MarketingMessage.findOneAndUpdate({ status:'pending', scheduledAt:{ $lte:now } }, { $set:{ status:'sending' } }, { sort:{ scheduledAt:1 }, new:true });
  if (!jobs) return;
  try {
    let result;
    if (jobs.channel === 'email') {
      const html = await buildEmailHtml(jobs);
      result = await sendEmail({ to: jobs.recipientEmail, subject: jobs.subject || 'LAVA', html, text: jobs.content, tags:[jobs.kind] });
    } else {
      result = await sendWhatsApp({ phone: jobs.recipientPhone, templateId: jobs.whatsappTemplateId, senderNumber: process.env.BREVO_WHATSAPP_SENDER, bodyText: jobs.content });
    }
    jobs.status='sent'; jobs.sentAt=new Date(); jobs.providerMessageId=result?.messageId || result?.messageIds?.[0]; await jobs.save();
  } catch (err) {
    jobs.status='failed'; jobs.error=String(err.message || 'send failed').slice(0,1000); await jobs.save();
  }
}

async function scheduleAbandonedCarts() {
  const settings = await Settings.findOne().select('marketing').lean();
  const cfg = settings?.marketing?.abandonedCart;
  if (!cfg?.enabled || !Array.isArray(cfg.steps) || !cfg.steps.length) return;
  const carts = await AbandonedCart.find({ recoveredAt:null, customerEmail:{ $exists:true, $ne:null } }).sort({ lastSeen:1 }).limit(500).lean();
  const now = Date.now();
  for (const cart of carts) {
    for (let i=0;i<cfg.steps.length;i++) {
      const step = cfg.steps[i];
      const scheduled = new Date(new Date(cart.lastSeen || cart.createdAt).getTime() + Number(step.delayMinutes || 120)*60000);
      if (scheduled.getTime() > now) continue;
      const exists = await MarketingMessage.findOne({ kind:'abandoned_cart', entityId:String(cart._id), step:i, channel:step.channel });
      if (exists) continue;
      const itemText = (cart.items || []).map(x => `${x.name?.ar || x.name?.en || x.name} x${x.quantity||1}`).join('، ');
      await MarketingMessage.create({ kind:'abandoned_cart', channel:step.channel, recipientEmail:cart.customerEmail, recipientPhone:cart.customerPhone, subject:step.subject || 'لسه حاجاتك في السلة', content:render(step.content || 'وحشتنا! لسه المنتجات دي محفوظة في عربيتك.', { items:itemText, subtotal:cart.subtotal, couponCode:step.couponCode || '' }), couponCode: step.couponCode || '', entityId:String(cart._id), step:i, scheduledAt:scheduled });
    }
  }
}

async function startMarketingWorker() {
  const tick = async () => { try { await scheduleAbandonedCarts(); await processQueue(); await processQueue(); } catch(e) { console.error('Marketing worker:', e.message); } };
  await tick();
  return setInterval(tick, 15000);
}
module.exports = { startMarketingWorker };