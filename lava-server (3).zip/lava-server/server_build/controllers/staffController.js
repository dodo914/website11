const bcrypt = require('bcryptjs');
const User = require('../models/User');
const { logActivity } = require('../utils/activityLogger');
const { validatePasswordStrength, isValidEmail, isValidPhone, validateName } = require('../utils/validators');

// GET /api/staff  (أدمن بس)
const getStaff = async (req, res) => {
  const staff = await User.find({ role: { $in: ['call_center', 'packer'] } }).select('-password');
  res.json(staff);
};

// POST /api/staff  (أدمن بس)
const addStaff = async (req, res) => {
  try {
    const { name, email, phone, password, role } = req.body;
    if (!name || !email || !password || !['call_center', 'packer'].includes(role)) {
      return res.status(400).json({ message: 'بيانات ناقصة أو الدور غلط' });
    }

    const nameError = validateName(name);
    if (nameError) return res.status(400).json({ message: nameError });

    if (!isValidEmail(email)) {
      return res.status(400).json({ message: 'البريد الإلكتروني غير صحيح' });
    }

    if (phone && !isValidPhone(phone)) {
      return res.status(400).json({ message: 'رقم الهاتف غير صحيح' });
    }

    const passwordError = validatePasswordStrength(password);
    if (passwordError) {
      return res.status(400).json({ message: passwordError });
    }

    const exists = await User.findOne({ email: email.toLowerCase() });
    if (exists) return res.status(400).json({ message: 'البريد مستخدم بالفعل' });

    const hashedPassword = await bcrypt.hash(password, 12);
    const staff = await User.create({ name, email, phone, password: hashedPassword, role });

    logActivity(req, {
      action: 'create',
      entityType: 'staff',
      entityId: staff._id,
      entityLabel: staff.name,
      description: `${req.user?.name || 'أدمن'} أضاف موظف جديد "${staff.name}" (${role === 'call_center' ? 'كول سنتر' : 'باكر'})`,
    });

    res.status(201).json({ id: staff._id, name: staff.name, email: staff.email, role: staff.role });
  } catch (err) {
    res.status(500).json({ message: 'حصل خطأ في إضافة الموظف', error: err.message });
  }
};

// DELETE /api/staff/:id  (أدمن بس)
const removeStaff = async (req, res) => {
  const staff = await User.findOne({ _id: req.params.id, role: { $in: ['call_center', 'packer'] } });
  if (!staff) return res.status(404).json({ message: 'الموظف مش موجود' });
  await staff.deleteOne();

  logActivity(req, {
    action: 'delete',
    entityType: 'staff',
    entityId: staff._id,
    entityLabel: staff.name,
    description: `${req.user?.name || 'أدمن'} حذف الموظف "${staff.name}"`,
  });

  res.json({ message: 'اتمسح بنجاح' });
};

module.exports = { getStaff, addStaff, removeStaff };