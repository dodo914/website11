const express = require('express');
const router = express.Router();
const { getCustomers, getCustomerOrders, getCustomerSegments } = require('../controllers/customerController');
const { protect, authorize } = require('../middleware/auth');

router.use(protect, authorize('admin'));
router.get('/', getCustomers);
router.get('/segments', getCustomerSegments);
router.get('/:id/orders', getCustomerOrders);

module.exports = router;