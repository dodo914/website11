const express = require('express');
const router = express.Router();
const {
  register,
  login,
  sendLoginCode,
  verifyLoginCode,
  checkEmailLoginMethod,
  getPublicAuthConfig,
  getAdminAuthConfig,
  updateAdminAuthConfig,
  getMe,
  logout,
  getCsrfToken,
} = require('../controllers/authController');
const { protect, authorize } = require('../middleware/auth');

router.get('/config', getPublicAuthConfig);
router.get('/csrf-token', getCsrfToken);
router.post('/register', register);
router.post('/login', login);
router.post('/send-code', sendLoginCode);
router.post('/verify-code', verifyLoginCode);
router.post('/check-email', checkEmailLoginMethod);
router.post('/logout', logout);
router.get('/admin-config', protect, authorize('admin'), getAdminAuthConfig);
router.put('/admin-config', protect, authorize('admin'), updateAdminAuthConfig);
router.get('/me', protect, getMe);

module.exports = router;