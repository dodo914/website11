const express = require('express');
const router = express.Router();
const { protect, authorize } = require('../middleware/auth');
const { getMarketing, updateMarketing, queueCampaign, getMessageStats } = require('../controllers/marketingController');
router.get('/settings', protect, authorize('admin'), getMarketing);
router.put('/settings', protect, authorize('admin'), updateMarketing);
router.post('/campaigns', protect, authorize('admin'), queueCampaign);
router.get('/stats', protect, authorize('admin'), getMessageStats);
module.exports = router;
