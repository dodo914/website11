const express = require('express');
const router = express.Router();
const { getStaff, addStaff, removeStaff } = require('../controllers/staffController');
const { protect, authorize } = require('../middleware/auth');

router.use(protect, authorize('admin'));
router.get('/', getStaff);
router.post('/', addStaff);
router.delete('/:id', removeStaff);

module.exports = router;
