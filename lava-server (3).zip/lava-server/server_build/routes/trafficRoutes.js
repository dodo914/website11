const express = require('express');
const router = express.Router();
const { protect, authorize } = require('../middleware/auth');
const { recordVisit, recordPageView, markConverted, recordFunnelStep, getStats } = require('../controllers/trafficController');

// Public
router.post('/visit',    recordVisit);
router.post('/pageview', recordPageView);
router.put('/convert',   markConverted);
router.post('/funnel',   recordFunnelStep);

// Admin only
router.get('/stats', protect, authorize('admin'), getStats);

module.exports = router;