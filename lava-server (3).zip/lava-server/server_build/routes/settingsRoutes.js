const express = require('express');
const router = express.Router();
const {
  getPublicSettings, getAdminSettings, updateSettings, getPublicPixels,
  addProductReview, getProductReviews, addContactMessage, getStoreHealth,
} = require('../controllers/settingsController');
const { protect, authorize } = require('../middleware/auth');

router.get('/public', getPublicSettings);
router.get('/pixels', getPublicPixels);
router.get('/admin', protect, authorize('admin'), getAdminSettings);
router.get('/store-health', protect, authorize('admin'), getStoreHealth);
router.put('/', protect, authorize('admin'), updateSettings);
router.post('/contact', addContactMessage);

// Reviews endpoints
router.post('/reviews', addProductReview);
router.get('/reviews/:productId', getProductReviews);

module.exports = router;