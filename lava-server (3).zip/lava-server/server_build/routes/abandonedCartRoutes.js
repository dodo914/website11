const express = require('express');
const router = express.Router();
const { upsertAbandonedCart, markRecovered, getAbandonedCarts } = require('../controllers/abandonedCartController');
const { protect, authorize, optionalProtect } = require('../middleware/auth');

router.post('/', optionalProtect, upsertAbandonedCart);
router.put('/recover', optionalProtect, markRecovered);
router.get('/', protect, authorize('admin'), getAbandonedCarts);

module.exports = router;
