const crypto = require('crypto');

const KASHIER_CHECKOUT_URL = 'https://checkout.kashier.io/';

const isConfigured = () => Boolean(
  String(process.env.KASHIER_MID || '').trim() &&
  String(process.env.KASHIER_API_KEY || '').trim() &&
  String(process.env.KASHIER_SECRET_KEY || '').trim()
);

const getMode = () => (String(process.env.KASHIER_MODE || 'test').toLowerCase() === 'live' ? 'live' : 'test');
const getCurrency = () => String(process.env.KASHIER_CURRENCY || 'EGP').trim() || 'EGP';

const getFrontendUrl = () => {
  const configured = String(process.env.FRONTEND_URL || process.env.CLIENT_URL || '').trim();
  if (configured) return configured.replace(/\/$/, '');
  // Vite's usual local dev port. In production, set FRONTEND_URL explicitly.
  if (String(process.env.NODE_ENV || '').toLowerCase() !== 'production') return 'http://localhost:5173';
  return '';
};

const getBackendUrl = () => {
  const configured = String(process.env.BACKEND_URL || '').trim();
  if (configured) return configured.replace(/\/$/, '');
  // Express' usual local port. In production, set BACKEND_URL explicitly.
  if (String(process.env.NODE_ENV || '').toLowerCase() !== 'production') {
    const port = Number(process.env.PORT || 5000);
    return `http://localhost:${Number.isFinite(port) && port > 0 ? port : 5000}`;
  }
  return '';
};

const getCallbackUrl = () => {
  const explicit = String(process.env.KASHIER_CALLBACK_URL || '').trim();
  if (explicit) return explicit;

  // Browser callback: Kashier returns the customer to our backend first,
  // then the backend redirects to the frontend. This keeps the callback
  // endpoint independent from the frontend router.
  const base = getBackendUrl();
  return base ? `${base}/api/payments/kashier/callback` : '';
};

const getWebhookUrl = () => {
  // IMPORTANT: do not automatically send localhost/private URLs to Kashier.
  // A server-to-server webhook needs a publicly reachable HTTPS URL.
  const explicit = String(process.env.KASHIER_WEBHOOK_URL || '').trim();
  if (explicit) return explicit;
  return '';
};

// Kashier Hosted Checkout uses an HMAC-SHA256 hash over the merchant/order/payment
// identity. Keep this server-side; the secret must never reach the browser.
//
// Per Kashier's official docs ("Payment Api Keys are used to generate hash order
// and to validate signature"), the HMAC key is the Payment API Key, NOT the
// Secret Key. The signed payload MUST be exactly:
//   /?payment=MID.orderId.amount.currency
const createPaymentHash = ({ merchantId, orderId, amount, currency }) => {
  const paymentApiKey = String(process.env.KASHIER_API_KEY || '');
  const path = `/?payment=${merchantId}.${orderId}.${amount}.${currency}`;
  return crypto.createHmac('sha256', paymentApiKey).update(path).digest('hex');
};

// القيم اللي Kashier بتفهمها فعليًا في باراميتر allowedMethods ثابتة وموثّقة
// من عندهم (مش أسرار خاصة بيك زي integration ID بتاع Paymob)، لكن سيبناها
// قابلة للتغيير من .env بدل ما تتكتب صريحة في الكود — لو Kashier غيّروا
// اسم قيمة يومًا ما، تعدّل .env بس من غير ما تلمس الكود.
// القيمة الافتراضية (لو المتغير مش موجود في .env) هي نفسها القيمة الموثّقة.
const KASHIER_METHOD_CODE = {
  card: String(process.env.KASHIER_METHOD_CODE_CARD || 'card').trim().toLowerCase(),
  wallet: String(process.env.KASHIER_METHOD_CODE_WALLET || 'wallet').trim().toLowerCase(),
  bank_installments: String(process.env.KASHIER_METHOD_CODE_BANK_INSTALLMENTS || 'bank_installments').trim().toLowerCase(),
  valu: String(process.env.KASHIER_METHOD_CODE_VALU || 'valu').trim().toLowerCase(),
};

// خريطة عكسية: أي اسم منطقي ('wallet' مثلاً) بيتحول لقيمة Kashier الفعلية
// المضبوطة في .env (أو الافتراضية لو .env فاضي).
const normalizeAllowedMethods = (methods) => {
  const list = Array.isArray(methods) ? methods : String(methods || '').split(',');
  const cleaned = list
    .map((m) => String(m || '').trim().toLowerCase())
    .map((m) => KASHIER_METHOD_CODE[m] || null) // لو الاسم مش معروف، اتجاهل
    .filter(Boolean);
  return [...new Set(cleaned)];
};

const buildPaymentUrl = ({ orderId, amount, customerEmail, customerPhone, allowedMethods }) => {
  if (!isConfigured()) {
    const err = new Error('Kashier is not configured');
    err.code = 'KASHIER_NOT_CONFIGURED';
    throw err;
  }

  const merchantId = String(process.env.KASHIER_MID).trim();
  const currency = getCurrency();
  const normalizedAmount = Number(amount).toFixed(2);
  const callbackUrl = getCallbackUrl();
  const webhookUrl = getWebhookUrl();

  if (!webhookUrl) {
    // بدون serverWebhook، Kashier مش هيبعت أي إشعار سيرفر-لسيرفر لأي حدث بعد الدفع
    // (وأهمها الاسترجاع/refund اللي بيتعمل من لوحة Kashier نفسها) — فالطلب هيفضل
    // شكله زي ما هو (paid) عندنا في الداتابيز حتى لو اتعمله refund فعلي على Kashier.
    // ده أكتر سبب شائع إن الـ admin/العميل ميشوفوش تحديث الـ refund بينما هو ظاهر في Kashier.
    console.warn('⚠️  KASHIER_WEBHOOK_URL غير مضبوط في .env — إشعارات Kashier (خصوصًا الاسترجاع/refund) لن تصل للسيرفر ولن تنعكس على الأدمن أو العميل. اضبط KASHIER_WEBHOOK_URL على دومين عام (https) يشير لـ /api/payments/kashier/webhook، وتأكد إن نفس اللينك مسجل في إعدادات الـ Webhook داخل لوحة تحكم Kashier.');
  }

  if (!callbackUrl) {
    const err = new Error('KASHIER_CALLBACK_URL or FRONTEND_URL is required');
    err.code = 'KASHIER_CALLBACK_MISSING';
    throw err;
  }

  const params = new URLSearchParams({
    merchantId,
    orderId: String(orderId),
    amount: normalizedAmount,
    currency,
    hash: createPaymentHash({ merchantId, orderId: String(orderId), amount: normalizedAmount, currency }),
    merchantRedirect: callbackUrl,
    mode: getMode(),
    display: 'en',
  });

  if (webhookUrl) params.set('serverWebhook', webhookUrl);
  if (customerEmail) params.set('customerEmail', String(customerEmail));
  if (customerPhone) params.set('customerPhone', String(customerPhone));

  // اختياري بالكامل: لو الفرونت إند بعت وسيلة/وسائل محددة (مثلاً العميل دوس
  // "ادفع بفودافون كاش")، بنقفل صفحة Kashier عليها بس فتفتح مباشرة من غير
  // قائمة اختيار. لو مفيش allowedMethods، السلوك زي ما هو بالظبط من قبل
  // (كل الوسائل المفعّلة على الحساب بتظهر).
  const normalizedMethods = normalizeAllowedMethods(allowedMethods);
  if (normalizedMethods.length > 0) params.set('allowedMethods', normalizedMethods.join(','));

  return `${KASHIER_CHECKOUT_URL}?${params.toString()}`;
};

const getPayloadValue = (payload, ...keys) => {
  for (const key of keys) {
    const parts = key.split('.');
    let value = payload;
    for (const part of parts) value = value?.[part];
    if (value !== undefined && value !== null && value !== '') return value;
  }
  return null;
};

// Kashier's async webhook body looks like:
//   { "event": "pay" | "refund" | "authorize" | "void" | "capture", "data": { ...transaction fields..., "signatureKeys": [...] } }
// This is a DIFFERENT shape/signature scheme than the Hosted Checkout hash above.
// Docs: https://developers.kashier.io/payment/webhook/
const verifyWebhookSignature = (data, signatureHeader) => {
  if (!data || !signatureHeader) return false;
  const keys = Array.isArray(data.signatureKeys) ? [...data.signatureKeys].sort() : [];
  if (keys.length === 0) return false;

  const querystring = require('querystring');
  const picked = {};
  for (const key of keys) {
    if (data[key] !== undefined && data[key] !== null) picked[key] = data[key];
  }
  const signaturePayload = querystring.stringify(picked);
  const paymentApiKey = String(process.env.KASHIER_API_KEY || '');
  const expected = crypto.createHmac('sha256', paymentApiKey).update(signaturePayload).digest('hex');
  try {
    return crypto.timingSafeEqual(Buffer.from(expected), Buffer.from(String(signatureHeader)));
  } catch {
    return false; // length mismatch etc. -> treat as invalid
  }
};

const normalizePaymentResult = (payload = {}) => {
  // Webhook bodies are { event, data }. Everything else (the browser callback
  // query string) is already flat, so falling back to top-level keys keeps
  // both call sites working with the same function.
  const event = getPayloadValue(payload, 'event');
  const statusRaw = getPayloadValue(
    payload,
    'status',
    'paymentStatus',
    'transactionStatus',
    'result',
    'data.status',
    'data.paymentStatus',
    'data.transactionStatus',
    'data.result'
  );
  const responseCode = getPayloadValue(payload, 'responseCode', 'responseStatus', 'data.responseCode');
  // IMPORTANT: Kashier's own "orderId"/"kashierOrderId" is its internal transaction id, not ours.
  // Our order id is always sent back as "merchantOrderId" (both in the webhook
  // body and in the browser merchantRedirect query string), so it must win.
  const orderId = getPayloadValue(payload, 'merchantOrderId', 'orderId', 'data.merchantOrderId', 'data.orderId');
  const amount = getPayloadValue(payload, 'amount', 'data.amount');
  const currency = getPayloadValue(payload, 'currency', 'data.currency');
  const hash = getPayloadValue(payload, 'hash', 'signature', 'data.hash', 'data.signature');
  const status = String(statusRaw ?? responseCode ?? '').trim().toLowerCase();

  // "refund" is an event TYPE, not a status value — a refund event's own
  // data.status is usually still "SUCCESS" (meaning the refund succeeded).
  const isRefundEvent = String(event || '').trim().toLowerCase() === 'refund';
  const isVoidEvent = String(event || '').trim().toLowerCase() === 'void';

  const successStatus = ['success', 'successful', 'paid', 'completed', 'approved', 'succeeded', '00', '2'].includes(status);
  const failedStatus = ['failed', 'failure', 'declined', 'cancelled', 'canceled', 'expired', 'error', 'rejected'].includes(status);

  const refunded = isRefundEvent && successStatus;
  const success = successStatus && !isRefundEvent && !isVoidEvent;
  const failed = failedStatus || isVoidEvent;

  return {
    event: event ? String(event) : null,
    orderId: orderId ? String(orderId) : null,
    amount: amount != null ? Number(amount) : null,
    currency: currency ? String(currency) : null,
    hash: hash ? String(hash) : null,
    status,
    success,
    failed,
    refunded,
    raw: payload,
  };
};

module.exports = {
  KASHIER_CHECKOUT_URL,
  isConfigured,
  getMode,
  getCurrency,
  getFrontendUrl,
  getBackendUrl,
  getCallbackUrl,
  getWebhookUrl,
  createPaymentHash,
  buildPaymentUrl,
  normalizePaymentResult,
  verifyWebhookSignature,
};