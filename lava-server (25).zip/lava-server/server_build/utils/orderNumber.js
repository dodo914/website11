const Counter = require('../models/Counter');

// ============================================================
// ===== توليد رقم أوردر متسلسل (Atomic) =====
// بيستخدم findByIdAndUpdate مع $inc عشان العملية تبقى atomic على مستوى
// الـ database نفسه - لو جالك طلبين في نفس اللحظة بالظبط، MongoDB
// بيضمن إن كل واحد ياخد رقم مختلف من غير تعارض (race condition).
//
// ===== إصلاح: كان الرقم بيطلع 1، 2، 3... بدل 1001، 1002، 1003 =====
// السبب: MongoDB مبيدمجش $inc مع الـ default بتاع الـ schema (seq: 1000)
// وقت الـ upsert على نفس الحقل - فكان بيتجاهل الـ 1000 تمامًا ويبدأ العداد
// نفسه من صفر (0 + 1 = 1، 1 + 1 = 2... وهكذا). setDefaultsOnInsert مش
// بيشتغل مع $inc على نفس الحقل، ده تعارض معروف في MongoDB/Mongoose.
// الحل: بنشيل الاعتماد على الـ default خالص، وبنضيف رقم البداية (1000)
// يدويًا في الكود بعد ما ناخد الرقم المتسلسل الحقيقي من العداد - كده
// النتيجة مضمونة ومش متأثرة بأي تعارض في الـ upsert.
// ============================================================
const ORDER_NUMBER_BASE = 1000;

async function getNextOrderNumber() {
  const counter = await Counter.findByIdAndUpdate(
    'orderNumber',
    { $inc: { seq: 1 } },
    { new: true, upsert: true }
  );
  return ORDER_NUMBER_BASE + counter.seq;
}

module.exports = { getNextOrderNumber };