const ShippingIdempotency = require('../../models/ShippingIdempotency');

// سجل "in_progress" أقدم من كده بيتعتبر عالق (السيرفر وقع/اتقفل وهو لسه
// بينفذ) ومسموح نحاول تاني بدل ما نقفل على الأوردر ده للأبد.
const IN_PROGRESS_TTL_MS = 2 * 60 * 1000; // دقيقتين

// كود خطأ الـduplicate key بتاع MongoDB.
const MONGO_DUPLICATE_KEY_CODE = 11000;

/**
 * withIdempotency({ orderId, provider, operation, providerIdempotencyKey }, fn)
 *
 * بينفذ fn() (اللي فعليًا بتنادي على شركة الشحن) مرة واحدة بس لكل
 * (orderId, provider, operation)، حتى مع concurrent requests أو retries.
 *
 * بيرجع: { executed: boolean, result }
 *   - executed=true  => احنا فعلاً نفذنا العملية دلوقتي (أول مرة).
 *   - executed=false => فيه نتيجة محفوظة بالفعل من محاولة سابقة، رجعناها
 *     من غير ما ننادي fn() تاني (يعني منعنا duplicate shipment فعليًا).
 *
 * لو fn() رمت error، بيتسجل الفشل في السجل (status: 'failed') وبترمي
 * الـerror تاني لفوق عادي عشان الـcontroller يتعامل معاها زي ما هو متوقع،
 * لكن مع تحديث عدد المحاولات attempts عشان لو حصل retry تاني بعدها.
 */
async function withIdempotency({ orderId, provider, operation, providerIdempotencyKey = null }, fn) {
  const idempotencyKey = `${orderId}:${provider}:${operation}`;

  // الخطوة الأساسية: نحاول "نحجز" السجل ده بشكل atomic. لو already موجود
  // بحالة completed/failed، منرجعش نحاول تاني - بنرجع النتيجة المحفوظة على
  // طول. لو already موجود بحالة in_progress وحديث (لسه جوه TTL)، معنى كده
  // فيه محاولة تانية شغالة فعليًا دلوقتي (concurrent request) - منعملش
  // حاجة ونرجع "مشغول حاليًا" واضح بدل ما نستنى أو نكرر النداء.
  let record;
  try {
    record = await ShippingIdempotency.create({
      orderId, provider, operation, idempotencyKey, providerIdempotencyKey,
      status: 'in_progress', attempts: 1, lastAttemptAt: new Date(),
    });
  } catch (err) {
    if (err.code !== MONGO_DUPLICATE_KEY_CODE) throw err;

    // فيه سجل موجود بالفعل - هنجيبه ونقرر بناءً على حالته.
    const existing = await ShippingIdempotency.findOne({ orderId, provider, operation });

    if (!existing) {
      // حالة نادرة جدًا (race بين الـduplicate error وقراءتنا للسجل نفسه) -
      // منحاولش نكرر إنشاء شحنة؛ نرجع خطأ واضح بدل تنفيذ غير آمن.
      const e = new Error('تعارض مؤقت أثناء معالجة العملية، حاول تاني بعد لحظات');
      e.status = 409;
      throw e;
    }

    if (existing.status === 'completed') {
      return { executed: false, result: existing.result };
    }
    // status === 'failed'
    // ملحوظة إصلاح (Phase 3): قبل كده كانت أي محاولة فاشلة (حتى بيانات ناقصة
    // أو subscription مش مفعّل) بتقفل على الـ(orderId, provider, operation)
    // ده للأبد - مفيش أي مسار في الكود بيمسح أو يعيد ضبط سجل idempotency،
    // يعني زرار "Retry" في الأدمن (بعد ما يصلّح العنوان أو يفعّل اشتراك
    // بوسطة) مكانش هيشتغل خالص حتى لو المشكلة اتصلحت فعليًا عند الطرف التاني.
    // بنسمح هنا بمحاولة جديدة فعلية (زي حالة in_progress العالقة تحت بالظبط)
    // بدل القفل النهائي - التكرار الحقيقي (نفس النتيجة الناجحة) لسه محمي
    // بالكامل عن طريق status==='completed' فوق واللي بيرجع نفس النتيجة من
    // غير أي نداء تاني لشركة الشحن.
    if (existing.status === 'failed') {
      existing.status = 'in_progress';
      existing.attempts = (existing.attempts || 1) + 1;
      existing.lastAttemptAt = new Date();
      existing.providerIdempotencyKey = providerIdempotencyKey || existing.providerIdempotencyKey;
      await existing.save();
      record = existing;
    } else {
    // status === 'in_progress'
    const age = Date.now() - new Date(existing.lastAttemptAt || existing.updatedAt).getTime();
    if (age < IN_PROGRESS_TTL_MS) {
      // فيه محاولة تانية شغالة فعليًا دلوقتي (concurrent request حقيقي) -
      // منسمحش بمحاولة تانية تتنفذ في نفس الوقت.
      const e = new Error('العملية دي قيد التنفيذ بالفعل (طلب آخر بيعالجها الآن)، من فضلك انتظر قليلاً');
      e.status = 409;
      throw e;
    }

    // السجل عالق (in_progress قديم جدًا - غالبًا السيرفر وقع أثناء التنفيذ).
    // بنسمح بمحاولة جديدة، بس بنحدّث نفس السجل (مش ننشئ سجل جديد) عشان
    // الـunique index يفضل زي ما هو ومنكسرش حماية الـrace condition.
    existing.status = 'in_progress';
    existing.attempts = (existing.attempts || 1) + 1;
    existing.lastAttemptAt = new Date();
    existing.providerIdempotencyKey = providerIdempotencyKey || existing.providerIdempotencyKey;
    await existing.save();
    record = existing;
    }
  }

  // من هنا واحنا فعلاً "الوحيدين" اللي بننفذ العملية دلوقتي - آمن نتصل بشركة الشحن.
  try {
    const result = await fn();
    record.status = 'completed';
    record.result = result;
    record.errorMessage = null;
    await record.save();
    return { executed: true, result };
  } catch (err) {
    record.status = 'failed';
    record.errorMessage = err.message || 'فشلت العملية';
    await record.save();
    throw err;
  }
}

module.exports = { withIdempotency, IN_PROGRESS_TTL_MS };