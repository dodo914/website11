// ============================================================================
// tests/shippingStatusRegression.test.js
// ------------------------------------------------------------------------
// اختبارات لإصلاح الـ Bug: "shipped" كانت غير موجودة في STATUS_RANK، فكانت
// بتاخد rank = -1 وتلغي حماية التراجع للخلف (regression) في كل مسارات
// تحديث حالة الشحن (sync يدوي/تلقائي + Webhook).
//
// يشتغل من غير أي مكتبة اختبار خارجية (الريبو مفيهوش jest/mocha مُثبتة) -
// بيستخدم node:test و node:assert المدمجين في Node.js (متاحين من Node 18+).
//
// طريقة التشغيل:
//   node --test tests/shippingStatusRegression.test.js
// أو لتشغيل كل ملفات الاختبار في المجلد:
//   node --test tests/
// ============================================================================
const test = require('node:test');
const assert = require('node:assert/strict');

const { STATUS_RANK, INTERNAL_STATUSES, normalizeStatus } = require('../services/shipping/statusMap');
const { syncOrderTracking, applyIncomingStatus } = require('../services/shipping/sync');

// ===== Fake Order (mongoose document محاكاة بسيطة - مفيش داعي لاتصال DB حقيقي) =====
function makeFakeOrder(overrides = {}) {
  const order = {
    shippingCompany: 'bosta',
    shippingStatus: 'pending',
    shippingRawStatus: null,
    status: 'جديد',
    deliveredAt: null,
    shippingUpdatedAt: null,
    trackingNumber: 'TRK123',
    saveCallCount: 0,
    ...overrides,
  };
  order.save = async function save() {
    order.saveCallCount += 1;
    return order;
  };
  return order;
}

// ===== Fake Provider - بيرجع status ثابتة زي ما نحددها في كل تست =====
function makeFakeProvider(rawStatus) {
  return { track: async () => ({ status: rawStatus }) };
}

test('STATUS_RANK: "shipped" لازم يكون له rank حقيقي (مش -1/undefined) - ده جوهر الـBug', () => {
  assert.ok(INTERNAL_STATUSES.includes('shipped'), '"shipped" لازم يكون في INTERNAL_STATUSES');
  assert.notStrictEqual(STATUS_RANK.shipped, undefined, '"shipped" لازم يكون له rank في STATUS_RANK');
  assert.strictEqual(STATUS_RANK.shipped, STATUS_RANK.created, '"shipped" لازم يكون بنفس درجة "created" (نفس لحظة السير - الشحنة اتسجلت لسه ما اتستلمتش)');
});

// ============================================================================
// A) shipped -> created متراجعش (created بنفس درجة shipped، فمفيش "تراجع"
//    حقيقي - لكن لازم الحماية تمنع أي رجوع لحالة أقدم فعليًا زي pending)
// ============================================================================
test('A) syncOrderTracking: shipped -> pending (رد قديم متأخر) مينفعش يرجّع الحالة للخلف', async () => {
  // نتأكد الأول إن "created" و"shipped" متساويين في الرانك (مش تراجع حقيقي بينهم):
  assert.strictEqual(STATUS_RANK.created, STATUS_RANK.shipped);

  // تراجع حقيقي: حالة الأوردر "shipped" ورد الشركة يرجّع raw status غير معروف
  // (بيتحوّل بواسطة normalizeStatus إلى 'pending' كـfallback) - rank أقل فعليًا.
  const order = makeFakeOrder({ shippingStatus: 'shipped', shippingRawStatus: 'X' });
  const oldProvider = { track: async () => ({ status: 'unknown_very_old_state_xyz' }) };
  const { changed, internalStatus } = await syncOrderTracking(order, oldProvider, {});
  assert.strictEqual(internalStatus, 'pending');
  assert.strictEqual(order.shippingStatus, 'shipped', 'الحالة لازم تفضل "shipped" - مينفعش ترجع لـ"pending"');
  assert.strictEqual(changed, false, 'مفروض ماتتسجلش أي تغييرة (save) لما يكون تراجع');
});

// ============================================================================
// B) shipped -> picked_up لازم يتحرك للأمام عادي (تقدّم طبيعي)
// ============================================================================
test('B) syncOrderTracking: shipped -> picked_up بيتحدث عادي (تقدّم للأمام)', async () => {
  const order = makeFakeOrder({ shippingStatus: 'shipped', shippingRawStatus: 'created' });
  const provider = makeFakeProvider('20'); // Bosta '20' => picked_up
  const { changed, internalStatus } = await syncOrderTracking(order, provider, {});
  assert.strictEqual(internalStatus, 'picked_up');
  assert.strictEqual(order.shippingStatus, 'picked_up');
  assert.strictEqual(changed, true);
  assert.strictEqual(order.saveCallCount, 1);
});

// ============================================================================
// C) in_transit -> created متراجعش (created rank=1 أقل من in_transit rank=3)
// ============================================================================
test('C) syncOrderTracking: in_transit -> created (رد قديم) مينفعش يرجّع الحالة للخلف', async () => {
  const order = makeFakeOrder({ shippingStatus: 'in_transit', shippingRawStatus: '30' });
  const provider = makeFakeProvider('10'); // Bosta '10' => created (rank 1 < in_transit rank 3)
  const { changed, internalStatus } = await syncOrderTracking(order, provider, {});
  assert.strictEqual(internalStatus, 'created');
  assert.strictEqual(order.shippingStatus, 'in_transit', 'الحالة لازم تفضل "in_transit"');
  assert.strictEqual(changed, false);
  assert.strictEqual(order.saveCallCount, 0, 'مفروض متتحفظش أي حاجة لما يكون تراجع');
});

// ============================================================================
// D) in_transit -> delivered لازم يتقدّم، وحالة الأوردر العامة تتحدث لـ"تم التسليم"
// ============================================================================
test('D) syncOrderTracking: in_transit -> delivered بيتقدّم و order.status يتحدث', async () => {
  const order = makeFakeOrder({ shippingStatus: 'in_transit', shippingRawStatus: '30' });
  const provider = makeFakeProvider('45'); // Bosta '45' => delivered
  const { changed, internalStatus } = await syncOrderTracking(order, provider, {});
  assert.strictEqual(internalStatus, 'delivered');
  assert.strictEqual(order.shippingStatus, 'delivered');
  assert.strictEqual(order.status, 'تم التسليم');
  assert.ok(order.deliveredAt instanceof Date);
  assert.strictEqual(changed, true);
});

// ============================================================================
// E) delivered لازم يفضل delivered لو رد الشركة رجع حالة أقدم (out-of-order)
// ============================================================================
test('E) syncOrderTracking: delivered يفضل delivered لو وصل رد أقدم من الشركة', async () => {
  const order = makeFakeOrder({ shippingStatus: 'delivered', shippingRawStatus: '45', deliveredAt: new Date('2025-01-01') });
  const provider = makeFakeProvider('30'); // in_transit - رد متأخر/قديم
  const { changed, internalStatus } = await syncOrderTracking(order, provider, {});
  assert.strictEqual(internalStatus, 'in_transit');
  assert.strictEqual(order.shippingStatus, 'delivered', 'لازم يفضل delivered');
  assert.strictEqual(changed, false);
});

test('E-webhook) applyIncomingStatus: نفس السلوك في مسار الـWebhook بالظبط', async () => {
  const order = makeFakeOrder({ shippingStatus: 'delivered', shippingRawStatus: '45' });
  const res = await applyIncomingStatus(order, '30', 'bosta');
  assert.strictEqual(res.ignored, true);
  assert.strictEqual(res.reason, 'out_of_order');
  assert.strictEqual(order.shippingStatus, 'delivered');
});

// ============================================================================
// F) حالات الاستثناء الشرعية (returned/failed/cancelled) لازم تفضل شغالة عادي
// ============================================================================
test('F1) syncOrderTracking: delivered -> returned لازم يتحدث (استثناء شرعي رغم نفس الـrank)', async () => {
  const order = makeFakeOrder({ shippingStatus: 'delivered', shippingRawStatus: '45' });
  const provider = makeFakeProvider('50'); // Bosta '50' => returned
  const { changed, internalStatus } = await syncOrderTracking(order, provider, {});
  assert.strictEqual(internalStatus, 'returned');
  assert.strictEqual(order.shippingStatus, 'returned');
  assert.strictEqual(order.status, 'مرتجع');
  assert.strictEqual(changed, true);
});

test('F2) syncOrderTracking: in_transit -> failed (فشل التوصيل) بيتحدث عادي', async () => {
  const order = makeFakeOrder({ shippingStatus: 'in_transit', shippingRawStatus: '30' });
  const provider = makeFakeProvider('sh007'); // مفيش Bosta code كده - نستخدم aramex بدل bosta
  order.shippingCompany = 'aramex';
  const { changed, internalStatus } = await syncOrderTracking(order, provider, {});
  assert.strictEqual(internalStatus, 'failed');
  assert.strictEqual(order.shippingStatus, 'failed');
  assert.strictEqual(changed, true);
});

test('F3) syncOrderTracking: shipped -> cancelled بيتحدث عادي', async () => {
  const order = makeFakeOrder({ shippingStatus: 'shipped', shippingRawStatus: 'created' });
  const provider = makeFakeProvider('cancelled');
  const { changed, internalStatus } = await syncOrderTracking(order, provider, {});
  assert.strictEqual(internalStatus, 'cancelled');
  assert.strictEqual(order.shippingStatus, 'cancelled');
  assert.strictEqual(changed, true);
});

// ============================================================================
// حماية الـworker التلقائي: "shipped" لازم تكون جزء من ACTIVE_STATUSES عشان
// الـworker يكمل يتابع الشحنة تلقائيًا بعد إنشائها مباشرة (Bug fix تاني).
// ============================================================================
test('shippingSyncWorker: "shipped" لازم تكون في ACTIVE_STATUSES (وإلا الشحنات الجديدة ما بتتابعش تلقائي)', () => {
  const workerSrc = require('node:fs').readFileSync(require('node:path').join(__dirname, '../services/shippingSyncWorker.js'), 'utf8');
  const match = workerSrc.match(/const ACTIVE_STATUSES = \[([^\]]+)\]/);
  assert.ok(match, 'ACTIVE_STATUSES تعريف مش موجود؟');
  assert.ok(match[1].includes("'shipped'"), '"shipped" لازم تكون في ACTIVE_STATUSES');
});