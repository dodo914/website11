const mongoose = require('mongoose');
const Order = require('../models/Order');
const { restoreOrderItems, logMovementsBulk } = require('../utils/inventory');
const { invalidateProductCaches } = require('../utils/cache');

// ============================================================
// ===== إيجاد الأوردر من orderId اللي راجع من بوابة الدفع (Kashier/Paymob) =====
// بعد التحديث، بيتبعت رقم الأوردر المتسلسل (orderNumber: 1001، 1002...)
// لبوابات الدفع بدل الـ Mongo _id الطويل، عشان يبقى نفس الرقم اللي بيوصل
// لشركة الشحن. الدالة دي بتدور بالـorderNumber الأول (الحالة الجديدة)،
// وبترجع تدور بالـ_id كـfallback عشان أي جلسة دفع (checkout session) كانت
// اتعملت قبل التحديث ده ولسه معلقة (orderId فيها لسه الـ_id القديم) - عشان
// متتكسرش فجأة.
// ============================================================
const gatewayOrderFilter = (orderId) => {
  const raw = String(orderId == null ? '' : orderId).trim();
  if (!raw) return null;
  const or = [];
  const numeric = Number(raw);
  if (Number.isFinite(numeric)) or.push({ orderNumber: numeric });
  if (mongoose.Types.ObjectId.isValid(raw)) or.push({ _id: raw });
  return or.length > 0 ? { $or: or } : null;
};
const findOrderByGatewayOrderId = async (orderId, projection) => {
  const filter = gatewayOrderFilter(orderId);
  if (!filter) return null;
  const query = Order.findOne(filter);
  return projection ? query.select(projection) : query;
};
const {
  isConfigured,
  getMode,
  getCurrency,
  getFrontendUrl,
  getBackendUrl,
  getCallbackUrl,
  getWebhookUrl,
  normalizePaymentResult,
  verifyWebhookSignature,
} = require('../services/kashierService');
const {
  isConfigured: isPaymobConfigured,
  getCurrency: getPaymobCurrency,
  getFrontendUrl: getPaymobFrontendUrl,
  getCallbackUrl: getPaymobCallbackUrl,
  getWebhookUrl: getPaymobWebhookUrl,
  normalizePaymentResult: normalizePaymobResult,
  verifyHmac: verifyPaymobHmac,
} = require('../services/paymobService');

const isKashierEnabled = async () => {
  const Settings = require('../models/Settings');
  const settings = await Settings.findOne();
  return settings?.paymentSettings?.kashierEnabled === true;
};

const isPaymobEnabled = async () => {
  const Settings = require('../models/Settings');
  const settings = await Settings.findOne();
  return settings?.paymentSettings?.paymobEnabled === true;
};

const markFailedAndReleaseStock = async (order) => {
  if (!order) return;
  order.paymentStatus = 'failed';

  if (!order.stockRestored) {
    await restoreOrderItems(order.items);
    await logMovementsBulk(order.items, 'stock_released', {
      orderId: order._id,
      note: 'Kashier payment failed/cancelled — stock released',
    });
    order.stockRestored = true;
    order.stockRestoredAt = new Date();
    invalidateProductCaches();
  }

  await order.save();
  require('../utils/cache').del('orders:all');
};

// ============================================================
// ===== تأكيد الطلب لبوابات الدفع (Kashier/Paymob) — بعد نجاح الدفع فعليًا =====
// نفس منطق queueOrderConfirmation في orderController.js، لكن هنا بيتنفذ
// بس لما الدفع ينجح فعلاً (مش وقت إنشاء الطلب زي COD/manual)، عشان محدش
// ياخد رسالة "تأكيد" على طلب لسه مدفعوش. مفصولة في try/catch مستقلة عشان
// فشل جدولة الرسالة (أو غياب إعدادات الماركتنج) ميأثرش على تسجيل الدفع نفسه.
// ============================================================
const queueGatewayOrderConfirmation = async (order) => {
  try {
    const Settings = require('../models/Settings');
    const settings = await Settings.findOne();
    const marketing = settings?.marketing;
    if (!marketing?.enabled || !marketing?.orderConfirmation) return;

    const channel = marketing.orderConfirmationChannel === 'whatsapp' ? 'whatsapp' : 'email';
    const hasTarget = channel === 'email' ? !!order.customerEmail : !!order.customerPhone;
    if (!hasTarget) return;

    const MarketingMessage = require('../models/MarketingMessage');
    try {
      await MarketingMessage.create({
        kind: 'order_confirmation',
        channel,
        recipientEmail: channel === 'email' ? String(order.customerEmail).trim().toLowerCase() : undefined,
        recipientPhone: channel === 'whatsapp' ? String(order.customerPhone || '').replace(/\D/g, '') : undefined,
        subject: `تأكيد طلبك #${order._id}`,
        entityId: order._id.toString(),
        step: 0,
        scheduledAt: new Date(),
        status: 'pending',
      });
      order.emailConfirmation = { enabled: true, confirmed: false, confirmedAt: null, messageId: null, status: 'pending' };
      await order.save();
    } catch (queueErr) {
      // E11000 = already queued لنفس الطلب/القناة (مثلاً لو الـwebhook والـcallback
      // اشتغلوا مع بعض بالصدفة) — تجاهل بأمان، ده مش خطأ حقيقي.
      if (queueErr?.code !== 11000) throw queueErr;
    }
  } catch (e) {
    // Never fail the payment confirmation flow because queueing the message failed.
    console.error('Gateway order confirmation queueing failed:', { message: e?.message, code: e?.code });
  }
};

const markPaid = async (order, payment = {}) => {
  if (!order) return;
  if (order.paymentStatus === 'paid') return;

  order.paymentStatus = 'paid';

  // نخزّن مراجع بوابة الدفع بمجرد ما الطلب يتدفع، عشان لو حصل استرجاع لاحقًا
  // من لوحة التحكم عندنا نقدر ننادي على refund API بتاع البوابة نفسها.
  order.paymentGateway = order.paymentGateway || {};
  if (order.paymentMethod === 'kashier') {
    if (payment.kashierOrderId) order.paymentGateway.kashierOrderId = String(payment.kashierOrderId);
    if (payment.transactionId) order.paymentGateway.transactionId = String(payment.transactionId);
  } else if (order.paymentMethod === 'paymob') {
    if (payment.transactionId) order.paymentGateway.transactionId = String(payment.transactionId);
  }

  await order.save();
  require('../utils/cache').del('orders:all');

  await queueGatewayOrderConfirmation(order);
};

const markRefunded = async (order, payment = {}) => {
  if (!order) return;
  if (order.paymentStatus === 'refunded') return; // already fully refunded, nothing to do

  // Kashier's webhook "refund" event carries the amount THAT refund covers
  // (not necessarily the full order total — a merchant can issue a partial
  // refund straight from the Kashier dashboard too). We mirror exactly what
  // the admin-triggered refund endpoint does (orderController.refundOrderPayment):
  // accumulate refundedAmount / push a refunds[] entry, and only flip
  // paymentStatus to 'refunded' once the accumulated total covers the order.
  // This is what makes a refund issued directly from Kashier's dashboard show
  // up correctly (full or partial) in our admin panel too — as long as
  // KASHIER_WEBHOOK_URL is configured and reachable; without a working
  // webhook, Kashier has no way to tell our server this happened at all.
  const alreadyRefunded = Math.round(Number(order.refundedAmount || 0) * 100) / 100;
  const eventAmount = Number(payment.amount);
  const remaining = Math.round((Number(order.totalAmount || 0) - alreadyRefunded) * 100) / 100;
  // If Kashier didn't send a usable amount for some reason, fall back to
  // treating it as a full refund of whatever's left — safer than recording 0.
  const refundAmount = Number.isFinite(eventAmount) && eventAmount > 0
    ? Math.min(eventAmount, Math.max(remaining, eventAmount))
    : remaining;

  order.refunds = order.refunds || [];
  order.refunds.push({
    amount: refundAmount,
    reason: 'Refund issued from Kashier dashboard (via webhook)',
    at: new Date(),
    by: null,
    gatewayResponse: payment.raw || null,
  });
  order.refundedAmount = Math.round((alreadyRefunded + refundAmount) * 100) / 100;

  const isFullyRefunded = order.refundedAmount >= Number(order.totalAmount || 0) - 0.01;
  if (isFullyRefunded) {
    order.paymentStatus = 'refunded';

    if (!order.stockRestored) {
      await restoreOrderItems(order.items);
      await logMovementsBulk(order.items, 'stock_released', {
        orderId: order._id,
        note: 'Kashier refund confirmed — stock released',
      });
      order.stockRestored = true;
      order.stockRestoredAt = new Date();
      invalidateProductCaches();
    }
  }

  await order.save();
  require('../utils/cache').del('orders:all');
};

const getKashierStatus = async (req, res) => {
  try {
    const enabled = await isKashierEnabled();
    const configured = isConfigured();
    res.json({
      enabled,
      configured,
      connected: configured,
      mode: getMode(),
      currency: getCurrency(),
      callbackConfigured: Boolean(getCallbackUrl()),
      webhookConfigured: Boolean(getWebhookUrl()),
    });
  } catch (err) {
    console.error('Kashier status error:', err);
    res.status(500).json({ message: 'تعذر فحص اتصال Kashier' });
  }
};

const getPaymentStatus = async (req, res) => {
  try {
    const order = await findOrderByGatewayOrderId(req.params.orderId, '_id orderNumber paymentMethod paymentStatus totalAmount customerEmail');
    if (!order || order.paymentMethod !== 'kashier') {
      return res.status(404).json({ message: 'الدفع غير موجود' });
    }
    res.json({ orderId: order.orderNumber || order._id, paymentMethod: order.paymentMethod, paymentStatus: order.paymentStatus, totalAmount: order.totalAmount });
  } catch (err) {
    console.error('Kashier payment status error:', err);
    res.status(500).json({ message: 'تعذر جلب حالة الدفع' });
  }
};

const handleKashierCallback = async (req, res) => {
  // Best-effort update from the browser redirect. The server-to-server webhook
  // is still the primary/most trustworthy source of truth (harder to spoof),
  // but during local development Kashier cannot reach a localhost webhook URL,
  // so without this the order stays stuck on "processing" forever. We only
  // mark an order here after checking it belongs to Kashier, is still pending,
  // and that the amount/currency match — the same integrity checks the webhook
  // handler performs.
  const orderId = req.query.merchantOrderId || req.query.orderId || '';

  try {
    if (orderId) {
      const result = normalizePaymentResult(req.query || {});
      const order = await findOrderByGatewayOrderId(orderId);
      if (order && order.paymentMethod === 'kashier' && order.paymentStatus !== 'paid') {
        const amountOk = result.amount == null || Math.abs(Number(result.amount) - Number(order.totalAmount)) <= 0.01;
        const currencyOk = !result.currency || result.currency === getCurrency();
        if (amountOk && currencyOk) {
          if (result.success) {
            await markPaid(order, result);
          } else if (result.failed) {
            await markFailedAndReleaseStock(order);
          }
        }
      }
    }
  } catch (err) {
    console.error('Kashier callback processing error:', err);
    // Do not block the redirect on a processing error; the webhook (if reachable)
    // or the status endpoint can still resolve the order later.
  }

  const base = getFrontendUrl();
  const target = base ? `${base}/payment-complete` : '/payment-complete';
  const query = new URLSearchParams();
  if (orderId) query.set('orderId', String(orderId));
  query.set('method', 'kashier');
  res.redirect(`${target}?${query.toString()}`);
};

const handleKashierWebhook = async (req, res) => {
  try {
    const body = req.body || {};
    const result = normalizePaymentResult(body);
    if (!result.orderId) return res.status(400).json({ message: 'merchantOrderId is required' });

    const order = await findOrderByGatewayOrderId(result.orderId);
    if (!order || order.paymentMethod !== 'kashier') {
      return res.status(404).json({ message: 'Kashier order not found' });
    }

    // Verify the request truly came from Kashier using the real webhook
    // signature scheme (header "x-kashier-signature", HMAC over the fields
    // listed in data.signatureKeys, keyed with the Payment API Key).
    // Docs: https://developers.kashier.io/payment/webhook/
    const signatureHeader = req.headers['x-kashier-signature'];
    const signatureValid = verifyWebhookSignature(body.data, signatureHeader);
    if (!signatureValid) {
      console.error('Kashier webhook: invalid or missing x-kashier-signature for order', result.orderId);
      return res.status(400).json({ message: 'Invalid webhook signature' });
    }

    if (result.currency && result.currency !== getCurrency()) {
      return res.status(400).json({ message: 'Payment currency mismatch' });
    }

    if (result.refunded) {
      // A refund event's "amount" is the refunded amount, which may be less
      // than the order total for a partial refund — we don't reject on that,
      // we only require the signature (checked above) to be valid.
      await markRefunded(order, { amount: result.amount, raw: result.raw });
      return res.json({ ok: true });
    }

    // Full-payment integrity check only applies to pay/capture-style events.
    if (result.amount != null && Math.abs(Number(result.amount) - Number(order.totalAmount)) > 0.01) {
      return res.status(400).json({ message: 'Payment amount mismatch' });
    }

    if (result.success) {
      await markPaid(order, result);
    } else if (result.failed) {
      await markFailedAndReleaseStock(order);
    }

    return res.json({ ok: true });
  } catch (err) {
    console.error('Kashier webhook error:', err);
    return res.status(500).json({ message: 'Webhook processing failed' });
  }
};

// ============================================================================
// Paymob — mirrors the Kashier handlers above, adapted to Paymob's Unified
// Intention flow (a create-intention API call up front, then a hosted
// checkout redirect, then a browser callback + a server-to-server webhook).
// ============================================================================

const getPaymobStatus = async (req, res) => {
  try {
    const enabled = await isPaymobEnabled();
    const configured = isPaymobConfigured();
    res.json({
      enabled,
      configured,
      connected: configured,
      currency: getPaymobCurrency(),
      callbackConfigured: Boolean(getPaymobCallbackUrl()),
      webhookConfigured: Boolean(getPaymobWebhookUrl()),
    });
  } catch (err) {
    console.error('Paymob status error:', err);
    res.status(500).json({ message: 'تعذر فحص اتصال Paymob' });
  }
};

const getPaymobPaymentStatus = async (req, res) => {
  try {
    const order = await findOrderByGatewayOrderId(req.params.orderId, '_id orderNumber paymentMethod paymentStatus totalAmount customerEmail');
    if (!order || order.paymentMethod !== 'paymob') {
      return res.status(404).json({ message: 'الدفع غير موجود' });
    }
    res.json({ orderId: order.orderNumber || order._id, paymentMethod: order.paymentMethod, paymentStatus: order.paymentStatus, totalAmount: order.totalAmount });
  } catch (err) {
    console.error('Paymob payment status error:', err);
    res.status(500).json({ message: 'تعذر جلب حالة الدفع' });
  }
};

const handlePaymobCallback = async (req, res) => {
  // Best-effort update from the browser redirect — same reasoning as Kashier's
  // callback handler. The webhook remains the trustworthy source of truth
  // since it carries a verifiable HMAC; this one is a convenience so local/dev
  // setups without a public webhook URL don't get stuck on "pending" forever.
  const query = req.query || {};
  const result = normalizePaymobResult(query);
  const orderId = result.orderId || '';

  try {
    if (orderId) {
      const order = await findOrderByGatewayOrderId(orderId);
      if (order && order.paymentMethod === 'paymob' && order.paymentStatus !== 'paid') {
        const amountOk = result.amount == null || Math.abs(Number(result.amount) - Number(order.totalAmount)) <= 0.01;
        const currencyOk = !result.currency || result.currency === getPaymobCurrency();
        if (amountOk && currencyOk && !result.pending) {
          if (result.success) {
            await markPaid(order, result);
          } else if (result.failed) {
            await markFailedAndReleaseStock(order);
          }
        }
      }
    }
  } catch (err) {
    console.error('Paymob callback processing error:', err);
    // Do not block the redirect on a processing error; the webhook (if reachable)
    // or the status endpoint can still resolve the order later.
  }

  const base = getPaymobFrontendUrl();
  const target = base ? `${base}/payment-complete` : '/payment-complete';
  const redirectQuery = new URLSearchParams();
  if (orderId) redirectQuery.set('orderId', String(orderId));
  redirectQuery.set('method', 'paymob');
  res.redirect(`${target}?${redirectQuery.toString()}`);
};

const handlePaymobWebhook = async (req, res) => {
  try {
    const body = req.body || {};
    // Paymob puts the HMAC in the query string even on the POST webhook.
    const hmacParam = req.query?.hmac;
    const result = normalizePaymobResult(body);
    if (!result.orderId) return res.status(400).json({ message: 'merchant_order_id is required' });

    const order = await findOrderByGatewayOrderId(result.orderId);
    if (!order || order.paymentMethod !== 'paymob') {
      return res.status(404).json({ message: 'Paymob order not found' });
    }

    // Verify the request truly came from Paymob using the documented HMAC
    // scheme (ordered field concatenation, HMAC-SHA512, keyed with the HMAC
    // secret from the Paymob dashboard). Docs:
    // https://developers.paymob.com/egypt/manage-transactions/transaction-webhooks
    const signatureValid = verifyPaymobHmac(result.hmacSource, hmacParam);
    if (!signatureValid) {
      console.error('Paymob webhook: invalid or missing hmac for order', result.orderId);
      return res.status(400).json({ message: 'Invalid webhook signature' });
    }

    if (result.pending) {
      // Still processing (e.g. 3D-Secure redirect in progress) — nothing to do yet.
      return res.json({ ok: true });
    }

    if (result.currency && result.currency !== getPaymobCurrency()) {
      return res.status(400).json({ message: 'Payment currency mismatch' });
    }

    if (result.refunded) {
      await markRefunded(order, { amount: result.amount, raw: result.raw });
      return res.json({ ok: true });
    }

    if (result.amount != null && Math.abs(Number(result.amount) - Number(order.totalAmount)) > 0.01) {
      return res.status(400).json({ message: 'Payment amount mismatch' });
    }

    if (result.success) {
      await markPaid(order, result);
    } else if (result.failed) {
      await markFailedAndReleaseStock(order);
    }

    return res.json({ ok: true });
  } catch (err) {
    console.error('Paymob webhook error:', err);
    return res.status(500).json({ message: 'Webhook processing failed' });
  }
};

module.exports = {
  getKashierStatus,
  getPaymentStatus,
  handleKashierCallback,
  handleKashierWebhook,
  getPaymobStatus,
  getPaymobPaymentStatus,
  handlePaymobCallback,
  handlePaymobWebhook,
};