const crypto = require('crypto');
const mongoose = require('mongoose');
const ExchangeRequest = require('../models/ExchangeRequest');
const Order = require('../models/Order');
const Product = require('../models/Product');
const Settings = require('../models/Settings');
const { parsePagination, buildListResponse } = require('../utils/pagination');
const { isValidExchangeReasonCode, requiresDetailNote, EXCHANGE_REASONS, getEffectiveExchangeReasons } = require('../utils/exchangeReasons');
const { decrementStockAtomic, restoreStockAtomic, logMovement } = require('../utils/inventory');
// ===== Returns & Exchanges - Phase 2A: حساب الرسوم/الأهلية/الصور المطلوبة Server-side =====
const { computeFee, checkEligibility, isEvidenceRequired } = require('../utils/returnExchangeFees');

const MAX_ITEM_QUANTITY = 1000;
const isValidQuantity = (q) => Number.isInteger(q) && q > 0 && q <= MAX_ITEM_QUANTITY;

// حالات بتعتبر "طلب استبدال شغّال" (لسه ما اتقفلش) - بتمنع فتح طلب استبدال
// جديد لنفس الأوردر لحد ما الطلب الحالي يتقفل (rejected/completed/cancelled).
const ACTIVE_STATUSES = ['pending', 'under_review', 'approved', 'pickup_scheduled', 'received', 'processing'];

const genRequestId = () => {
  const rand = crypto.randomBytes(3).toString('hex').toUpperCase();
  return `EX-${Date.now().toString(36).toUpperCase()}-${rand}`;
};

const pushHistory = (doc, status, userId, note) => {
  doc.statusHistory.push({ status, at: new Date(), by: userId || null, note: note || null });
};

// ============================================================
// خصم مخزون الفاريانت الجديد + إرجاع مخزون الفاريانت القديم - مستخدمة في
// حالتين: (1) موافقة الأدمن العادية على طلب عميل قائم (reviewExchangeRequest)
// و(2) لما الأدمن يسجّل استبدال بنفسه نيابة عن العميل (createExchangeRequest
// بـ requestedBy='admin') وبيتعمله approve فوري بنفس اللحظة - بند 5.
// بترجع { ok:true } أو { ok:false, message } من غير ما تعمل throw، عشان
// الـcaller يقدر يرجع 400 بالرسالة المناسبة زي ما كان بالظبط قبل الـrefactor.
// ============================================================
const applyExchangeStockAdjustment = async (exchangeRequest, userId) => {
  const decremented = [];
  for (const item of exchangeRequest.items) {
    const stockItem = {
      productId: item.productId,
      variantId: item.requestedNewVariant.variantId,
      size: item.requestedNewVariant.size,
      quantity: item.quantity,
    };
    const result = await decrementStockAtomic(stockItem);
    if (!result.ok) {
      for (const done of decremented) {
        await restoreStockAtomic(done);
      }
      return { ok: false, message: 'الفاريانت الجديد بقى مش متوفر بالكمية المطلوبة، من فضلك راجع الطلب' };
    }
    decremented.push(stockItem);
    await logMovement(stockItem, 'stock_sold', {
      orderId: exchangeRequest.orderId,
      userId,
      note: `حجز مخزون للفاريانت الجديد بسبب موافقة استبدال (${exchangeRequest.requestId})`,
    });
  }
  for (const item of exchangeRequest.items) {
    const oldStockItem = {
      productId: item.productId,
      variantId: item.oldVariant.variantId,
      size: item.oldVariant.size,
      quantity: item.quantity,
    };
    await restoreStockAtomic(oldStockItem);
    await logMovement(oldStockItem, 'stock_returned', {
      orderId: exchangeRequest.orderId,
      userId,
      note: `إرجاع مخزون الفاريانت القديم بسبب موافقة استبدال (${exchangeRequest.requestId})`,
    });
  }
  return { ok: true };
};

// يدوّر على فاريانت + مقاس داخل منتج، ويرجع { variant, sizeEntry } أو null
const findVariantAndSize = (product, variantId, size) => {
  if (!product || !Array.isArray(product.variants)) return null;
  const variant = product.variants.find(v => String(v._id) === String(variantId) || String(v.id) === String(variantId));
  if (!variant) return null;
  const sizeEntry = (variant.sizeStock || []).find(s => String(s.size) === String(size));
  if (!sizeEntry) return null;
  return { variant, sizeEntry };
};

// ============================================================
// POST /api/orders/:id/exchange-request  (عميل)
// ============================================================
const createExchangeRequest = async (req, res) => {
  try {
    const order = await Order.findById(req.params.id);
    if (!order) return res.status(404).json({ message: 'الطلب مش موجود' });

    // ===== الأدمن/الكول سنتر يقدر يسجّل استبدال بنفسه نيابة عن العميل =====
    // (زي reviewReturnRequest action='create' بالظبط - مثلاً العميل كلّمه
    // تليفونيًا وطلب يستبدل منتج). لسه بيتم التحقق إن الطلب فعلاً بتاع نفس
    // العميل لو الطالب مش أدمن/كول سنتر.
    const isPrivilegedRequester = req.user && ['admin', 'call_center'].includes(req.user.role);
    if (!req.user || (!isPrivilegedRequester && String(order.customerId || '') !== String(req.user._id))) {
      return res.status(403).json({ message: 'الطلب ده مش تابع لحسابك' });
    }

    const existingActive = await ExchangeRequest.findOne({ orderId: order._id, status: { $in: ACTIVE_STATUSES } });
    if (existingActive) {
      return res.status(400).json({ message: 'فيه طلب استبدال لنفس الطلب ده لسه قيد المعالجة' });
    }

    const requestedItems = Array.isArray(req.body.items) ? req.body.items : [];
    if (requestedItems.length === 0) {
      return res.status(400).json({ message: 'اختار على الأقل منتج واحد عايز تستبدله' });
    }

    const settingsDoc = await Settings.findOne().lean();
    const reasonCode = isValidExchangeReasonCode(req.body.reasonCode, settingsDoc) ? req.body.reasonCode : null;
    if (!reasonCode) {
      return res.status(400).json({ message: 'اختار سبب الاستبدال' });
    }
    const customerNote = typeof req.body.customerNote === 'string' ? req.body.customerNote.trim().slice(0, 500) : '';
    if (requiresDetailNote(reasonCode) && !customerNote) {
      return res.status(400).json({ message: 'من فضلك اكتب تفاصيل السبب' });
    }

    // ===== الأهلية (Settings.enableExchanges + الطلب اتسلم + نافذة زمنية) =====
    const eligibility = checkEligibility({ order, type: 'exchange', reasonCode, settings: settingsDoc });
    if (!eligibility.eligible) {
      return res.status(400).json({ message: eligibility.message });
    }

    // ===== صور الإثبات (لو مطلوبة للسبب ده حسب الإعدادات) =====
    const evidenceImages = Array.isArray(req.body.evidenceImages)
      ? req.body.evidenceImages.filter((u) => typeof u === 'string' && u.trim()).slice(0, 10)
      : [];
    if (isEvidenceRequired({ type: 'exchange', reasonCode, settings: settingsDoc }) && evidenceImages.length === 0) {
      return res.status(400).json({ message: 'من فضلك ارفع صورة إثبات واحدة على الأقل لهذا السبب' });
    }

    // ===== تحقق من كل عنصر مقابل الطلب الأصلي + المخزون الجديد =====
    const validatedItems = [];
    for (const reqItem of requestedItems) {
      const quantity = Number(reqItem.quantity);
      if (!isValidQuantity(quantity)) {
        return res.status(400).json({ message: 'كمية غير صحيحة في أحد المنتجات' });
      }

      // العنصر لازم يكون فعلاً جزء من الطلب (نفس منتج/فاريانت/مقاس قديم)
      const matchingItem = order.items.find(oi =>
        String(oi.productId) === String(reqItem.productId) &&
        String(oi.variantId || '') === String(reqItem.oldVariantId || reqItem.variantId || '') &&
        String(oi.size || '') === String(reqItem.oldSize || reqItem.size || '')
      );
      if (!matchingItem) {
        return res.status(400).json({ message: 'أحد المنتجات مش موجود في هذا الطلب' });
      }
      if (quantity > matchingItem.quantity) {
        return res.status(400).json({ message: `الكمية المطلوبة أكبر من الكمية المشتراة لمنتج "${matchingItem.name?.ar || matchingItem.name?.en || ''}"` });
      }

      // المنتج نفسه لازم يكون موجود فعلاً (بيستخدم الـProducts الموجودة بالفعل)
      const product = await Product.findById(reqItem.productId).lean();
      if (!product) {
        return res.status(400).json({ message: 'المنتج المطلوب استبداله غير موجود' });
      }

      const newVariantId = reqItem.requestedNewVariant?.variantId || reqItem.newVariantId;
      const newSize = reqItem.requestedNewVariant?.size || reqItem.newSize;
      if (!newVariantId || !newSize) {
        return res.status(400).json({ message: 'اختار الفاريانت الجديد (اللون/المقاس) اللي عايز تستبدل بيه' });
      }
      const found = findVariantAndSize(product, newVariantId, newSize);
      if (!found) {
        return res.status(400).json({ message: 'الفاريانت الجديد اللي اخترته مش موجود' });
      }
      if (Number(found.sizeEntry.stock) < quantity) {
        return res.status(400).json({ message: `الفاريانت الجديد المطلوب غير متوفر بالكمية المطلوبة (المتاح: ${Number(found.sizeEntry.stock) || 0})` });
      }

      validatedItems.push({
        productId: matchingItem.productId,
        quantity,
        oldVariant: {
          variantId: matchingItem.variantId || null,
          size: matchingItem.size || null,
          color: matchingItem.color || null,
        },
        requestedNewVariant: {
          variantId: String(newVariantId),
          size: String(newSize),
          color: found.variant.color || null,
        },
      });
    }

    // ===== Snapshot الرسوم وقت إنشاء الطلب (بند 5 + 6) - Backend بس =====
    const feeSnapshot = computeFee({ type: 'exchange', reasonCode, settings: settingsDoc });

    const requestId = genRequestId();
    const exchangeRequest = new ExchangeRequest({
      requestId,
      orderId: order._id,
      // لو الأدمن هو اللي سجّل الطلب، الـuserId بيفضل بتاع العميل الحقيقي
      // (مالك الطلب) - مش الأدمن - عشان "طلباتي" عند العميل تعرضه صح.
      userId: isPrivilegedRequester ? order.customerId : req.user._id,
      requestedBy: isPrivilegedRequester ? 'admin' : 'customer',
      type: 'exchange',
      items: validatedItems,
      reasonCode,
      reason: reasonCode,
      customerNote: customerNote || null,
      evidenceImages,
      fee: feeSnapshot.fee,
      currency: feeSnapshot.currency,
      feeType: feeSnapshot.feeType,
      status: 'pending',
    });
    pushHistory(exchangeRequest, 'pending', req.user._id, isPrivilegedRequester ? 'الأدمن سجّل طلب استبدال بالنيابة عن العميل' : 'العميل قدّم طلب استبدال');

    // ===== الأدمن (زي الاسترجاع بالظبط): خطوة واحدة - بيتعمله approve فوري =====
    // مش محتاج يستنى موافقة تانية بعد كده، لأن الأدمن نفسه اللي سجّله.
    if (isPrivilegedRequester) {
      const stockResult = await applyExchangeStockAdjustment(exchangeRequest, req.user._id);
      if (!stockResult.ok) {
        return res.status(400).json({ message: stockResult.message });
      }
      exchangeRequest.status = 'approved';
      exchangeRequest.reviewedBy = req.user._id;
      exchangeRequest.reviewedAt = new Date();
      exchangeRequest.stockAdjusted = true;
      exchangeRequest.stockAdjustedAt = new Date();
      pushHistory(exchangeRequest, 'approved', req.user._id, 'تم تسجيله والموافقة عليه بواسطة الأدمن مباشرة');

      // ===== Phase 2C (تصحيح 2): نفس فكرة reviewExchangeRequest بالظبط - حالة
      // الأوردر تتغيّر لـ"مستبدل" فورًا هنا كمان لما الأدمن يسجّل الاستبدال
      // بنفسه بخطوة واحدة (مش بس لما العميل يطلب والأدمن يوافق بعدين). =====
      try {
        await Order.findByIdAndUpdate(order._id, { status: 'مستبدل' });
        require('../utils/cache').del('orders:all');
      } catch (orderErr) {
        console.error('Error updating order status to مستبدل:', orderErr);
      }
    }

    await exchangeRequest.save();
    res.status(201).json(exchangeRequest);
  } catch (err) {
    console.error('Error creating exchange request:', err);
    res.status(500).json({ message: 'حصل خطأ في تسجيل طلب الاستبدال', error: err.message });
  }
};

// ============================================================
// GET /api/exchange-requests/mine  (عميل)
// ============================================================
const getMyExchangeRequests = async (req, res) => {
  try {
    const requests = await ExchangeRequest.find({ userId: req.user._id }).sort({ createdAt: -1 }).lean();
    res.json(requests);
  } catch (err) {
    console.error('Error fetching my exchange requests:', err);
    res.status(500).json({ message: 'حصل خطأ في جلب طلبات الاستبدال', error: err.message });
  }
};

// ============================================================
// GET /api/exchange-requests  (أدمن)
// ============================================================
const getExchangeRequests = async (req, res) => {
  try {
    const filter = {};
    if (req.query.status) filter.status = req.query.status;
    if (req.query.orderId) filter.orderId = req.query.orderId;

    const { isPaginated, page, limit, skip } = parsePagination(req.query);
    const [items, total] = await Promise.all([
      ExchangeRequest.find(filter).sort({ createdAt: -1 }).skip(skip).limit(limit).lean(),
      ExchangeRequest.countDocuments(filter),
    ]);

    // ===== إصلاح: رقم الأوردر (orderNumber القصير) مش متسجّل جوه
    // ExchangeRequest نفسه (بس فيه orderId اللي هو الـ Order._id الطويل)،
    // فبنجيب رقم الأوردر القصير لكل الأوردرات المطلوبة هنا بطلب واحد
    // بس ونربطهم ببعض، بدل ما يبان الكود الطويل في لوحة الأدمن.
    const orderIds = [...new Set(items.map((it) => String(it.orderId)).filter(Boolean))];
    const relatedOrders = orderIds.length
      ? await Order.find({ _id: { $in: orderIds } }, { orderNumber: 1 }).lean()
      : [];
    const orderNumberById = new Map(relatedOrders.map((o) => [String(o._id), o.orderNumber]));
    const itemsWithOrderNumber = items.map((it) => ({
      ...it,
      orderNumber: orderNumberById.get(String(it.orderId)),
    }));

    res.json(buildListResponse({ isPaginated, page, limit, items: itemsWithOrderNumber, total }));
  } catch (err) {
    console.error('Error fetching exchange requests:', err);
    res.status(500).json({ message: 'حصل خطأ في جلب طلبات الاستبدال', error: err.message });
  }
};

// ============================================================
// GET /api/exchange-requests/:id  (المالك أو الأدمن)
// ============================================================
const getExchangeRequestById = async (req, res) => {
  try {
    if (!mongoose.isValidObjectId(req.params.id)) {
      return res.status(404).json({ message: 'طلب الاستبدال مش موجود' });
    }
    const exchangeRequest = await ExchangeRequest.findById(req.params.id);
    if (!exchangeRequest) return res.status(404).json({ message: 'طلب الاستبدال مش موجود' });

    const isOwner = String(exchangeRequest.userId) === String(req.user._id);
    const isPrivileged = req.user.role === 'admin' || req.user.role === 'call_center';
    if (!isOwner && !isPrivileged) {
      return res.status(403).json({ message: 'مالكش صلاحية تشوف الطلب ده' });
    }
    res.json(exchangeRequest);
  } catch (err) {
    console.error('Error fetching exchange request:', err);
    res.status(500).json({ message: 'حصل خطأ في جلب طلب الاستبدال', error: err.message });
  }
};

// ============================================================
// PUT /api/exchange-requests/:id/review  (أدمن) - action: approve | reject
// ============================================================
const reviewExchangeRequest = async (req, res) => {
  try {
    const exchangeRequest = await ExchangeRequest.findById(req.params.id);
    if (!exchangeRequest) return res.status(404).json({ message: 'طلب الاستبدال مش موجود' });

    const action = req.body.action;
    if (!['approve', 'reject'].includes(action)) {
      return res.status(400).json({ message: 'action غير معروف - المتاح: approve, reject' });
    }
    if (!['pending', 'under_review'].includes(exchangeRequest.status)) {
      return res.status(400).json({ message: 'الطلب ده مش قيد المراجعة حاليًا' });
    }

    if (action === 'reject') {
      exchangeRequest.status = 'rejected';
      exchangeRequest.reviewedBy = req.user._id;
      exchangeRequest.reviewedAt = new Date();
      if (typeof req.body.adminNote === 'string' && req.body.adminNote.trim()) {
        exchangeRequest.adminNote = req.body.adminNote.trim().slice(0, 500);
      }
      pushHistory(exchangeRequest, 'rejected', req.user._id, exchangeRequest.adminNote);
      await exchangeRequest.save();
      return res.json(exchangeRequest);
    }

    // ===== إعادة حساب الـFee لو الأدمن صحّح السبب وقت المراجعة (اختياري) =====
    // زي نفس فكرة reviewReturnRequest بالظبط - لو مفيش reasonCode جديد مبعوت،
    // بيستخدم الـSnapshot المحفوظ بالفعل من وقت ما العميل قدّم الطلب.
    const reviewSettingsDoc = await Settings.findOne().lean();
    if (isValidExchangeReasonCode(req.body.reasonCode, reviewSettingsDoc) && req.body.reasonCode !== exchangeRequest.reasonCode) {
      const settingsDoc = reviewSettingsDoc;
      const feeSnapshot = computeFee({ type: 'exchange', reasonCode: req.body.reasonCode, settings: settingsDoc });
      exchangeRequest.reasonCode = req.body.reasonCode;
      exchangeRequest.reason = req.body.reasonCode;
      exchangeRequest.fee = feeSnapshot.fee;
      exchangeRequest.currency = feeSnapshot.currency;
      exchangeRequest.feeType = feeSnapshot.feeType;
    }

    // ===== approve: تحقق نهائي من المخزون + خصم الفاريانت الجديد وإرجاع القديم =====
    const stockResult = await applyExchangeStockAdjustment(exchangeRequest, req.user._id);
    if (!stockResult.ok) {
      return res.status(400).json({ message: stockResult.message });
    }

    exchangeRequest.status = 'approved';
    exchangeRequest.reviewedBy = req.user._id;
    exchangeRequest.reviewedAt = new Date();
    exchangeRequest.stockAdjusted = true;
    exchangeRequest.stockAdjustedAt = new Date();
    if (typeof req.body.adminNote === 'string' && req.body.adminNote.trim()) {
      exchangeRequest.adminNote = req.body.adminNote.trim().slice(0, 500);
    }
    pushHistory(exchangeRequest, 'approved', req.user._id, exchangeRequest.adminNote);
    await exchangeRequest.save();

    // ===== Phase 2C (تصحيح): حالة الأوردر الأصلي تتغيّر لـ"مستبدل" فورًا وقت
    // الموافقة - بالظبط زي "مرتجع" مع الاسترجاع (مش لازم تستنى لحد "مكتمل")،
    // عشان الأدمن يشوف التغيير فورًا في تبويب الطلبات. =====
    if (exchangeRequest.orderId) {
      try {
        await Order.findByIdAndUpdate(exchangeRequest.orderId, { status: 'مستبدل' });
        require('../utils/cache').del('orders:all');
      } catch (orderErr) {
        console.error('Error updating order status to مستبدل:', orderErr);
      }
    }

    res.json(exchangeRequest);
  } catch (err) {
    console.error('Error reviewing exchange request:', err);
    res.status(500).json({ message: 'حصل خطأ في مراجعة طلب الاستبدال', error: err.message });
  }
};

// ترتيب الحالات بعد الموافقة - أي تحديث لازم يكون "قدّام" في الترتيب ده (أو cancelled)
const WORKFLOW_ORDER = ['approved', 'carrier_picked_up', 'received_at_warehouse', 'inspecting', 'shipped_to_customer', 'completed'];

// ============================================================
// PUT /api/exchange-requests/:id/status  (أدمن) - تحديث حالة الـworkflow بعد الموافقة
// ============================================================
const updateExchangeStatus = async (req, res) => {
  try {
    const exchangeRequest = await ExchangeRequest.findById(req.params.id);
    if (!exchangeRequest) return res.status(404).json({ message: 'طلب الاستبدال مش موجود' });

    // ===== رقم تتبع شحنة الاستبدال - يدوي بواسطة الأدمن (زي Order.returnTrackingNumber بالظبط) =====
    // مستقل تمامًا عن تغيير الـstatus: ممكن الأدمن يحط رقم التتبع لوحده من
    // غير ما يغيّر حالة الطلب، أو يبعتهم مع بعض في نفس الطلب.
    if (Object.prototype.hasOwnProperty.call(req.body, 'trackingNumber')) {
      const trackingNumber = typeof req.body.trackingNumber === 'string' ? req.body.trackingNumber.trim().slice(0, 120) : '';
      exchangeRequest.trackingNumber = trackingNumber || null;
      if (!Object.prototype.hasOwnProperty.call(req.body, 'status')) {
        await exchangeRequest.save();
        return res.json(exchangeRequest);
      }
    }

    const nextStatus = req.body.status;
    const validNext = ['under_review', 'carrier_picked_up', 'received_at_warehouse', 'inspecting', 'shipped_to_customer', 'completed', 'cancelled'];
    if (!validNext.includes(nextStatus)) {
      return res.status(400).json({ message: 'حالة غير معروفة' });
    }

    if (nextStatus === 'under_review') {
      if (exchangeRequest.status !== 'pending') {
        return res.status(400).json({ message: 'الطلب لازم يكون pending عشان تحطه under review' });
      }
    } else if (nextStatus === 'cancelled') {
      if (['completed', 'cancelled', 'rejected'].includes(exchangeRequest.status)) {
        return res.status(400).json({ message: 'مينفعش تلغي الطلب ده في الحالة الحالية' });
      }
      // لو المخزون كان اتعدّل بالفعل (بعد الموافقة)، نرجّعه لأصله بالكامل
      if (exchangeRequest.stockAdjusted) {
        for (const item of exchangeRequest.items) {
          await restoreStockAtomic({
            productId: item.productId,
            variantId: item.requestedNewVariant.variantId,
            size: item.requestedNewVariant.size,
            quantity: item.quantity,
          });
          await logMovement({
            productId: item.productId,
            variantId: item.requestedNewVariant.variantId,
            size: item.requestedNewVariant.size,
            quantity: item.quantity,
          }, 'stock_returned', {
            orderId: exchangeRequest.orderId,
            userId: req.user._id,
            note: `إلغاء استبدال بعد الموافقة - إرجاع الفاريانت الجديد (${exchangeRequest.requestId})`,
          });
          const oldStockResult = await decrementStockAtomic({
            productId: item.productId,
            variantId: item.oldVariant.variantId,
            size: item.oldVariant.size,
            quantity: item.quantity,
          });
          if (oldStockResult.ok) {
            await logMovement({
              productId: item.productId,
              variantId: item.oldVariant.variantId,
              size: item.oldVariant.size,
              quantity: item.quantity,
            }, 'stock_sold', {
              orderId: exchangeRequest.orderId,
              userId: req.user._id,
              note: `إلغاء استبدال بعد الموافقة - خصم الفاريانت القديم تاني (${exchangeRequest.requestId})`,
            });
          }
        }
        exchangeRequest.stockAdjusted = false;
      }
      // ===== لو الطلب اتلغى بعد ما كان approved (حالة الأوردر بقت "مستبدل")،
      // نرجّع حالة الأوردر لـ"تم التسليم" تاني عشان متفضلش عالقة على "مستبدل"
      // لطلب اتلغى فعليًا. =====
      if (exchangeRequest.orderId) {
        try {
          const ord = await Order.findById(exchangeRequest.orderId);
          if (ord && ord.status === 'مستبدل') {
            ord.status = 'تم التسليم';
            await ord.save();
            require('../utils/cache').del('orders:all');
          }
        } catch (orderErr) {
          console.error('Error reverting order status after exchange cancel:', orderErr);
        }
      }
    } else {
      // carrier_picked_up / received_at_warehouse / inspecting / shipped_to_customer / completed - لازم الطلب يكون approved أو مرحلة سابقة في الـworkflow
      const currentIdx = WORKFLOW_ORDER.indexOf(exchangeRequest.status);
      const nextIdx = WORKFLOW_ORDER.indexOf(nextStatus);
      if (currentIdx === -1 || nextIdx === -1 || nextIdx < currentIdx) {
        return res.status(400).json({ message: 'مينفعش تنقل الطلب للحالة دي دلوقتي' });
      }
    }

    exchangeRequest.status = nextStatus;
    const note = typeof req.body.note === 'string' && req.body.note.trim() ? req.body.note.trim().slice(0, 500) : null;
    pushHistory(exchangeRequest, nextStatus, req.user._id, note);
    await exchangeRequest.save();

    res.json(exchangeRequest);
  } catch (err) {
    console.error('Error updating exchange status:', err);
    res.status(500).json({ message: 'حصل خطأ في تحديث حالة طلب الاستبدال', error: err.message });
  }
};

// ============================================================
// PUT /api/exchange-requests/:id/cancel  (عميل - قبل الموافقة بس)
// ============================================================
const cancelExchangeRequest = async (req, res) => {
  try {
    const exchangeRequest = await ExchangeRequest.findById(req.params.id);
    if (!exchangeRequest) return res.status(404).json({ message: 'طلب الاستبدال مش موجود' });

    if (String(exchangeRequest.userId) !== String(req.user._id)) {
      return res.status(403).json({ message: 'الطلب ده مش تابع لحسابك' });
    }
    if (!['pending', 'under_review'].includes(exchangeRequest.status)) {
      return res.status(400).json({ message: 'مينفعش تلغي الطلب ده دلوقتي، تواصل مع خدمة العملاء' });
    }

    exchangeRequest.status = 'cancelled';
    pushHistory(exchangeRequest, 'cancelled', req.user._id, 'العميل ألغى الطلب');
    await exchangeRequest.save();
    res.json(exchangeRequest);
  } catch (err) {
    console.error('Error cancelling exchange request:', err);
    res.status(500).json({ message: 'حصل خطأ في إلغاء طلب الاستبدال', error: err.message });
  }
};

// GET /api/orders/exchange-reasons  (عام - قايمة أسباب الاستبدال الموحّدة)
const getExchangeReasons = async (req, res) => {
  try {
    const settingsDoc = await Settings.findOne().lean();
    const effective = getEffectiveExchangeReasons(settingsDoc).filter((r) => r.enabled !== false);
    res.json(effective.map(({ code, ar, en }) => ({ code, ar, en })));
  } catch (err) {
    console.error('Error fetching exchange reasons:', err);
    res.status(500).json({ message: 'حصل خطأ في جلب أسباب الاستبدال', error: err.message });
  }
};

// GET /api/orders/:id/exchange-eligibility?reasonCode=...  (عميل مسجل)
const getExchangeEligibility = async (req, res) => {
  try {
    const order = await Order.findById(req.params.id);
    if (!order) return res.status(404).json({ message: 'الطلب مش موجود' });

    if (!req.user || String(order.customerId || '') !== String(req.user._id)) {
      return res.status(403).json({ message: 'الطلب ده مش تابع لحسابك' });
    }

    const settingsDoc = await Settings.findOne().lean();
    const reasonCode = isValidExchangeReasonCode(req.query.reasonCode, settingsDoc) ? req.query.reasonCode : 'other';

    const existingActive = await ExchangeRequest.findOne({ orderId: order._id, status: { $in: ACTIVE_STATUSES } });
    if (existingActive) {
      return res.json({ eligible: false, message: 'فيه طلب استبدال لنفس الطلب ده لسه قيد المعالجة' });
    }

    const eligibility = checkEligibility({ order, type: 'exchange', reasonCode, settings: settingsDoc });
    res.json({
      eligible: eligibility.eligible,
      message: eligibility.message,
      evidenceRequired: isEvidenceRequired({ type: 'exchange', reasonCode, settings: settingsDoc }),
      fee: eligibility.eligible ? computeFee({ type: 'exchange', reasonCode, settings: settingsDoc }) : null,
    });
  } catch (err) {
    console.error('Error checking exchange eligibility:', err);
    res.status(500).json({ message: 'حصل خطأ في التحقق من أهلية الاستبدال', error: err.message });
  }
};


// ============================================================
// PUT /api/exchange-requests/:id/money  (أدمن) - Phase 2C
// تسجيل اتجاه/مبلغ تحويل فلوس الاستبدال (رسوم بتتحصل من العميل أو فرق سعر
// بيتحول للعميل) وتأكيد إن التحويل تم فعليًا (انستا باي / محفظة).
// ============================================================
const updateExchangeMoney = async (req, res) => {
  try {
    const exchangeRequest = await ExchangeRequest.findById(req.params.id);
    if (!exchangeRequest) return res.status(404).json({ message: 'طلب الاستبدال مش موجود' });

    if (req.body.direction !== undefined) {
      const direction = req.body.direction;
      if (!['none', 'collect_from_customer', 'refund_to_customer'].includes(direction)) {
        return res.status(400).json({ message: 'اتجاه التحويل غير معروف' });
      }
      exchangeRequest.moneyDirection = direction;
    }
    if (req.body.amount !== undefined && req.body.amount !== null && req.body.amount !== '') {
      const amount = Number(req.body.amount);
      if (!Number.isFinite(amount) || amount < 0) {
        return res.status(400).json({ message: 'المبلغ غير صحيح' });
      }
      exchangeRequest.moneyAmount = Math.round(amount * 100) / 100;
    }
    if (req.body.method !== undefined) {
      const method = req.body.method;
      if (method !== null && method !== 'instapay' && method !== 'wallet') {
        return res.status(400).json({ message: 'طريقة التحويل غير معروفة' });
      }
      exchangeRequest.moneyMethod = method || null;
    }
    if (typeof req.body.reference === 'string') {
      exchangeRequest.moneyReference = req.body.reference.trim().slice(0, 200) || null;
    }

    if (req.body.transferred === true) {
      if (!exchangeRequest.moneyDirection || exchangeRequest.moneyDirection === 'none') {
        return res.status(400).json({ message: 'حدد اتجاه التحويل الأول' });
      }
      if (!exchangeRequest.moneyAmount) {
        return res.status(400).json({ message: 'حدد مبلغ التحويل الأول' });
      }
      if (!exchangeRequest.moneyMethod) {
        return res.status(400).json({ message: 'حدد طريقة التحويل (انستا باي / محفظة) الأول' });
      }
      exchangeRequest.moneyTransferredAt = new Date();
      exchangeRequest.moneyTransferredBy = req.user ? req.user._id : null;
      const dirLabel = exchangeRequest.moneyDirection === 'collect_from_customer' ? 'العميل حوّل لينا' : 'تم التحويل للعميل';
      pushHistory(
        exchangeRequest,
        exchangeRequest.status,
        req.user ? req.user._id : null,
        `${dirLabel} ${exchangeRequest.moneyAmount} ${exchangeRequest.moneyCurrency || 'EGP'} عبر ${exchangeRequest.moneyMethod === 'instapay' ? 'انستا باي' : 'المحفظة'}`,
      );
    } else if (req.body.transferred === false) {
      exchangeRequest.moneyTransferredAt = null;
      exchangeRequest.moneyTransferredBy = null;
    }

    await exchangeRequest.save();
    res.json(exchangeRequest);
  } catch (err) {
    console.error('Error updating exchange money transfer:', err);
    res.status(500).json({ message: 'حصل خطأ في تحديث تحويل فلوس الاستبدال', error: err.message });
  }
};

module.exports = {
  createExchangeRequest,
  getMyExchangeRequests,
  getExchangeRequests,
  getExchangeRequestById,
  reviewExchangeRequest,
  updateExchangeStatus,
  updateExchangeMoney,
  cancelExchangeRequest,
  // ===== Returns & Exchanges - Phase 2A =====
  getExchangeReasons,
  getExchangeEligibility,
};