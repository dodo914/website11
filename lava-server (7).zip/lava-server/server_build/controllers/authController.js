const crypto = require('crypto');
const bcrypt = require('bcryptjs');
const User = require('../models/User');
const Settings = require('../models/Settings');
const { invalidateSettingsCaches } = require('../utils/cache');
const EmailOtp = require('../models/EmailOtp');
const generateToken = require('../utils/generateToken');
const { setAuthCookie, clearAuthCookie, setCsrfCookie, clearCsrfCookie } = require('../utils/cookieAuth');
const { isValidEmail, isValidPhone, isValidOtp, validatePasswordStrength, validateName } = require('../utils/validators');

const normalizeEmail = (email) => String(email || '').trim().toLowerCase();

const hasResendApiKey = () => Boolean(String(process.env.RESEND_API_KEY || '').trim());

const getAuthSettings = async () => {
  const settings = await Settings.findOne().select('customerLoginMethod resendFromEmail').lean();
  return {
    customerLoginMethod: settings?.customerLoginMethod === 'email_code' ? 'email_code' : 'email_password',
    resendFromEmail: String(settings?.resendFromEmail || process.env.RESEND_FROM_EMAIL || 'onboarding@resend.dev').trim(),
  };
};

const safeUser = (user) => ({
  id: user._id,
  name: user.name,
  email: user.email,
  phone: user.phone || '',
  role: user.role,
  permissions: user.role === 'staff' ? (user.permissions || []) : undefined,
  savedShipping: user.savedShipping || null,
  firstOrderDiscountUsed: user.firstOrderDiscountUsed || false,
  wishlist: Array.isArray(user.wishlist) ? user.wishlist : [],
  cart: Array.isArray(user.cart) ? user.cart : [],
});

const isAdmin = (user) => user?.role === 'admin';

const sendEmailWithResend = async ({ to, subject, html, text }) => {
  const apiKey = String(process.env.RESEND_API_KEY || '').trim();
  if (!apiKey) {
    const error = new Error('Resend API key is not configured');
    error.code = 'RESEND_NOT_CONFIGURED';
    throw error;
  }

  const { resendFromEmail } = await getAuthSettings();
  const response = await fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${apiKey}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      from: resendFromEmail,
      to: [to],
      subject,
      html,
      text,
    }),
  });

  const body = await response.json().catch(() => ({}));
  if (!response.ok) {
    const error = new Error(body?.message || 'Resend rejected the email');
    error.status = response.status;
    error.details = body;
    throw error;
  }

  return body;
};

const createOtpCode = () => String(crypto.randomInt(100000, 1000000));
const hashOtp = (code) => crypto.createHash('sha256').update(String(code)).digest('hex');

const buildOtpEmail = (code) => ({
  subject: 'رمز تسجيل الدخول إلى متجرك',
  text: `رمز تسجيل الدخول الخاص بك هو: ${code}. الرمز صالح لمدة 10 دقائق ولا تشاركه مع أي شخص.`,
  html: `<!doctype html><html lang="ar" dir="rtl"><body style="font-family:Arial,sans-serif;background:#f5f5f5;padding:32px"><div style="max-width:520px;margin:auto;background:#fff;border-radius:16px;padding:32px;text-align:center"><h2>رمز تسجيل الدخول</h2><p style="color:#555">استخدم الرمز التالي لتسجيل الدخول إلى حسابك:</p><div style="font-size:36px;font-weight:800;letter-spacing:10px;padding:18px;background:#f3f4f6;border-radius:12px;margin:24px 0">${code}</div><p style="font-size:13px;color:#777">الرمز صالح لمدة 10 دقائق ويُستخدم مرة واحدة فقط.</p></div></body></html>`,
});

// POST /api/auth/register — النظام القديم: Email + Password
const register = async (req, res) => {
  try {
    const { name, email, phone, password } = req.body;
    const normalizedEmail = normalizeEmail(email);
    if (!name || !normalizedEmail || !phone || !password) {
      return res.status(400).json({ message: 'كل البيانات مطلوبة' });
    }
    const nameError = validateName(name);
    if (nameError) return res.status(400).json({ message: nameError });
    if (!isValidEmail(normalizedEmail)) {
      return res.status(400).json({ message: 'البريد الإلكتروني غير صحيح' });
    }
    if (!isValidPhone(phone)) {
      return res.status(400).json({ message: 'رقم الهاتف غير صحيح' });
    }
    const passwordError = validatePasswordStrength(password);
    if (passwordError) {
      return res.status(400).json({ message: passwordError });
    }

    const exists = await User.findOne({ email: normalizedEmail });
    if (exists) return res.status(400).json({ message: 'البريد الإلكتروني مستخدم بالفعل' });

    const authSettings = await getAuthSettings();
    if (authSettings.customerLoginMethod !== 'email_password') {
      return res.status(409).json({ message: 'التسجيل بالباسورد غير مفعّل حالياً. استخدم تسجيل الدخول بالكود.' });
    }

    const hashedPassword = await bcrypt.hash(password, 12);
    const user = await User.create({
      name: String(name).trim(),
      email: normalizedEmail,
      phone: String(phone).trim(),
      password: hashedPassword,
      role: 'customer',
    });

    const token = generateToken(user);
    setAuthCookie(res, token);
    const csrfToken = setCsrfCookie(res);
    return res.status(201).json({ user: safeUser(user), csrfToken });
  } catch (err) {
    console.error('Auth register error:', err);
    return res.status(500).json({ message: 'حصل خطأ في التسجيل' });
  }
};

// POST /api/auth/login — كلمة مرور للعملاء أو الموظفين/الأدمن دائماً
const login = async (req, res) => {
  try {
    const { email, password } = req.body;
    const normalizedEmail = normalizeEmail(email);
    if (!normalizedEmail || !password) {
      return res.status(400).json({ message: 'البريد وكلمة المرور مطلوبين' });
    }
    if (!isValidEmail(normalizedEmail)) {
      return res.status(400).json({ message: 'البريد الإلكتروني غير صحيح' });
    }

    const user = await User.findOne({ email: normalizedEmail });
    if (!user || !user.password) return res.status(401).json({ message: 'بيانات الدخول غلط' });

    // الأدمن/الموظفين دائماً Password. العملاء كذلك في النظام الأول فقط.
    if (!isAdmin(user)) {
      const authSettings = await getAuthSettings();
      if (authSettings.customerLoginMethod === 'email_code' && user.role === 'customer') {
        return res.status(409).json({ message: 'تسجيل دخول العملاء حالياً بالكود المرسل إلى البريد.' });
      }
    }

    const match = await bcrypt.compare(password, user.password);
    if (!match) return res.status(401).json({ message: 'بيانات الدخول غلط' });

    const token = generateToken(user);
    setAuthCookie(res, token);
    const csrfToken = setCsrfCookie(res);
    return res.json({ user: safeUser(user), csrfToken });
  } catch (err) {
    console.error('Auth login error:', err);
    return res.status(500).json({ message: 'حصل خطأ في تسجيل الدخول' });
  }
};

// POST /api/auth/send-code — للعملاء فقط عندما يكون النظام Email + Code
const sendLoginCode = async (req, res) => {
  try {
    const email = normalizeEmail(req.body?.email);
    if (!email) return res.status(400).json({ message: 'اكتب البريد الإلكتروني أولاً' });
    if (!isValidEmail(email)) return res.status(400).json({ message: 'البريد الإلكتروني غير صحيح' });

    const authSettings = await getAuthSettings();
    if (authSettings.customerLoginMethod !== 'email_code') {
      return res.status(409).json({ message: 'تسجيل الدخول بالكود غير مفعّل حالياً.' });
    }

    const existingUser = await User.findOne({ email }).select('role');
    if (existingUser?.role && existingUser.role !== 'customer') {
      return res.status(403).json({ message: 'حساب الإدارة والموظفين يستخدم كلمة المرور.' });
    }

    const now = Date.now();
    const existingOtp = await EmailOtp.findOne({ email }).sort({ createdAt: -1 });
    if (existingOtp && now - new Date(existingOtp.lastSentAt).getTime() < 60 * 1000) {
      return res.status(429).json({ message: 'استنى دقيقة قبل إرسال كود جديد.' });
    }

    const code = createOtpCode();
    const otp = await EmailOtp.findOneAndUpdate(
      { email },
      {
        email,
        codeHash: hashOtp(code),
        expiresAt: new Date(now + 10 * 60 * 1000),
        attempts: 0,
        lastSentAt: new Date(now),
      },
      { upsert: true, new: true, setDefaultsOnInsert: true }
    );

    try {
      const mail = buildOtpEmail(code);
      await sendEmailWithResend({ to: email, ...mail });
    } catch (mailError) {
      await EmailOtp.deleteOne({ _id: otp._id });
      if (mailError.code === 'RESEND_NOT_CONFIGURED') {
        return res.status(503).json({ message: 'خدمة إرسال البريد غير مهيأة. أضف RESEND_API_KEY في .env.' });
      }
      console.error('Resend send error:', mailError.details || mailError.message);
      return res.status(502).json({ message: 'تعذر إرسال الكود إلى البريد الإلكتروني.' });
    }

    return res.json({ success: true, expiresInSeconds: 600, retryAfterSeconds: 60 });
  } catch (err) {
    console.error('Auth send code error:', err);
    return res.status(500).json({ message: 'حصل خطأ أثناء إرسال الكود' });
  }
};

// POST /api/auth/verify-code — ينشئ حساب العميل تلقائياً لو الإيميل جديد
const verifyLoginCode = async (req, res) => {
  try {
    const email = normalizeEmail(req.body?.email);
    const code = String(req.body?.code || '').trim();
    if (!email || !isValidEmail(email) || !isValidOtp(code)) {
      return res.status(400).json({ message: 'الإيميل والكود المكون من 6 أرقام مطلوبين' });
    }

    const authSettings = await getAuthSettings();
    if (authSettings.customerLoginMethod !== 'email_code') {
      return res.status(409).json({ message: 'تسجيل الدخول بالكود غير مفعّل حالياً.' });
    }

    const user = await User.findOne({ email });
    if (user && user.role !== 'customer') {
      return res.status(403).json({ message: 'حساب الإدارة والموظفين يستخدم كلمة المرور.' });
    }

    const otp = await EmailOtp.findOne({ email });
    if (!otp || otp.expiresAt.getTime() < Date.now()) {
      if (otp) await EmailOtp.deleteOne({ _id: otp._id });
      return res.status(400).json({ message: 'الكود منتهي أو غير موجود. اطلب كوداً جديداً.' });
    }

    if (otp.attempts >= 5) {
      await EmailOtp.deleteOne({ _id: otp._id });
      return res.status(429).json({ message: 'تم تجاوز عدد المحاولات. اطلب كوداً جديداً.' });
    }

    const valid = crypto.timingSafeEqual(
      Buffer.from(hashOtp(code), 'hex'),
      Buffer.from(otp.codeHash, 'hex')
    );
    if (!valid) {
      otp.attempts += 1;
      await otp.save();
      return res.status(401).json({ message: 'الكود غير صحيح.' });
    }

    await EmailOtp.deleteOne({ _id: otp._id });

    let customer = user;
    if (!customer) {
      const generatedName = email.split('@')[0].replace(/[._-]+/g, ' ').trim() || 'Customer';
      customer = await User.create({
        name: generatedName.slice(0, 80),
        email,
        phone: '',
        password: null,
        role: 'customer',
      });
    }

    const token = generateToken(customer);
    setAuthCookie(res, token);
    const csrfToken = setCsrfCookie(res);
    return res.json({ user: safeUser(customer), created: !user, csrfToken });
  } catch (err) {
    console.error('Auth verify code error:', err);
    return res.status(500).json({ message: 'حصل خطأ أثناء التحقق من الكود' });
  }
};

// POST /api/auth/check-email — بيحدد هل الإيميل ده يدخل بباسورد ولا بكود (خطوة واحدة موحدة للعميل والإدارة)
const checkEmailLoginMethod = async (req, res) => {
  try {
    const email = normalizeEmail(req.body?.email);
    if (!email) return res.status(400).json({ message: 'اكتب البريد الإلكتروني أولاً' });

    const authSettings = await getAuthSettings();
    const existingUser = await User.findOne({ email }).select('role');

    // أي حساب مش "customer" (أدمن، كول سنتر، باكر... إلخ) بيدخل بالباسورد دايماً
    if (existingUser && existingUser.role !== 'customer') {
      return res.json({ method: 'password' });
    }

    // عميل موجود أو إيميل جديد: حسب إعداد تسجيل دخول العملاء
    return res.json({ method: authSettings.customerLoginMethod === 'email_code' ? 'code' : 'password' });
  } catch (err) {
    console.error('Check email login method error:', err);
    return res.status(500).json({ message: 'تعذر التحقق من البريد الإلكتروني' });
  }
};

// GET /api/auth/config — إعدادات تسجيل دخول العملاء العامة
const getPublicAuthConfig = async (req, res) => {
  try {
    const authSettings = await getAuthSettings();
    return res.json({ customerLoginMethod: authSettings.customerLoginMethod });
  } catch (err) {
    console.error('Auth config error:', err);
    return res.status(500).json({ message: 'تعذر تحميل إعدادات تسجيل الدخول' });
  }
};

// GET /api/auth/admin-config — للأدمن فقط
const getAdminAuthConfig = async (req, res) => {
  try {
    const authSettings = await getAuthSettings();
    const admin = await User.findOne({ role: 'admin' }).select('email phone name').sort({ createdAt: 1 }).lean();
    return res.json({
      customerLoginMethod: authSettings.customerLoginMethod,
      resendFromEmail: authSettings.resendFromEmail,
      admin: admin ? { email: admin.email, phone: admin.phone || '', name: admin.name } : null,
      resendConfigured: hasResendApiKey(),
    });
  } catch (err) {
    console.error('Admin auth config error:', err);
    return res.status(500).json({ message: 'تعذر تحميل إعدادات الأمان' });
  }
};

// PUT /api/auth/admin-config — للأدمن فقط
const updateAdminAuthConfig = async (req, res) => {
  try {
    const method = req.body?.customerLoginMethod === 'email_code' ? 'email_code' : 'email_password';
    const resendFromEmail = String(req.body?.resendFromEmail || '').trim().toLowerCase();
    const adminEmail = normalizeEmail(req.body?.adminEmail);
    const adminPassword = String(req.body?.adminPassword || '');
    const adminPhone = String(req.body?.adminPhone || '').trim();

    if (!resendFromEmail || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(resendFromEmail)) {
      return res.status(400).json({ message: 'إيميل الإرسال من Resend غير صحيح.' });
    }

    if (method === 'email_code' && !String(process.env.RESEND_API_KEY || '').trim()) {
      return res.status(400).json({ message: 'لا يمكن تفعيل الدخول بالكود قبل إضافة RESEND_API_KEY في .env.' });
    }

    const admin = await User.findOne({ role: 'admin' }).sort({ createdAt: 1 });
    if (!admin) return res.status(404).json({ message: 'حساب الأدمن غير موجود.' });

    if (adminEmail) {
      const emailOwner = await User.findOne({ email: adminEmail, _id: { $ne: admin._id } }).select('_id');
      if (emailOwner) return res.status(409).json({ message: 'إيميل الأدمن مستخدم في حساب آخر.' });
      admin.email = adminEmail;
    }
    if (adminPassword) {
      const passwordError = validatePasswordStrength(adminPassword);
      if (passwordError) return res.status(400).json({ message: passwordError });
      admin.password = await bcrypt.hash(adminPassword, 12);
    }
    if (req.body?.adminPhone !== undefined) admin.phone = adminPhone;
    await admin.save();

    const settings = await Settings.findOneAndUpdate(
      {},
      { $set: { customerLoginMethod: method, resendFromEmail } },
      { upsert: true, new: true, setDefaultsOnInsert: true }
    ).select('customerLoginMethod resendFromEmail').lean();

    invalidateSettingsCaches();

    return res.json({
      success: true,
      customerLoginMethod: settings.customerLoginMethod,
      resendFromEmail: settings.resendFromEmail,
      admin: { email: admin.email, phone: admin.phone || '', name: admin.name },
      resendConfigured: hasResendApiKey(),
    });
  } catch (err) {
    console.error('Update admin auth config error:', err);
    return res.status(500).json({ message: 'حصل خطأ أثناء حفظ إعدادات تسجيل الدخول' });
  }
};

const getMe = async (req, res) => {
  return res.json({ user: safeUser(req.user) });
};

// PUT /api/auth/saved-shipping — العميل بيحفظ/يحدّث بيانات الشحن المفضلة لحسابه
// عشان تفضل موجودة في الداتا بيز وترجع تاني حتى لو عمل ريفريش أو دخل من جهاز تاني
const updateSavedShipping = async (req, res) => {
  try {
    if (!req.user || req.user.role !== 'customer') {
      return res.status(403).json({ message: 'غير مسموح' });
    }

    const { fullName, phone, phone2, address, governorate, country, zipCode } = req.body || {};

    if (!String(fullName || '').trim() || !String(address || '').trim() || !String(phone || '').trim()) {
      return res.status(400).json({ message: 'من فضلك أكمل بيانات الشحن' });
    }

    const user = await User.findById(req.user._id);
    if (!user) {
      return res.status(404).json({ message: 'المستخدم غير موجود' });
    }

    user.savedShipping = {
      fullName: String(fullName).trim(),
      phone: String(phone || '').trim(),
      phone2: String(phone2 || '').trim(),
      address: String(address).trim(),
      governorate: String(governorate || '').trim(),
      country: String(country || '').trim(),
      zipCode: String(zipCode || '').trim(),
    };
    await user.save();

    return res.json({ user: safeUser(user) });
  } catch (err) {
    console.error('Update saved shipping error:', err);
    return res.status(500).json({ message: 'حصل خطأ أثناء حفظ بيانات الشحن' });
  }
};

// PUT /api/auth/wishlist — العميل بيحفظ/يحدّث قائمة المفضلة بتاعته
// بيستبدل القائمة بالكامل بالقائمة الجديدة المرسلة من الفرونت (بعد الدمج مع أي عناصر
// كانت محفوظة محلياً كـ guest قبل تسجيل الدخول)، عشان تفضل موجودة في الداتا بيز
// وترجع تاني حتى لو عمل ريفريش أو دخل من جهاز تاني.
const updateWishlist = async (req, res) => {
  try {
    if (!req.user) {
      return res.status(401).json({ message: 'لازم تسجل دخول الأول' });
    }

    const { wishlist } = req.body || {};
    if (!Array.isArray(wishlist)) {
      return res.status(400).json({ message: 'صيغة المفضلة غير صحيحة' });
    }

    // تنظيف القائمة: إزالة القيم الفاضية والتكرار
    const cleaned = [...new Set(wishlist.filter((id) => id !== null && id !== undefined && String(id).trim() !== ''))];

    const user = await User.findById(req.user._id);
    if (!user) {
      return res.status(404).json({ message: 'المستخدم غير موجود' });
    }

    user.wishlist = cleaned;
    await user.save();

    return res.json({ user: safeUser(user) });
  } catch (err) {
    console.error('Update wishlist error:', err);
    return res.status(500).json({ message: 'حصل خطأ أثناء حفظ المفضلة' });
  }
};

// PUT /api/auth/cart — العميل بيحفظ/يحدّث سلة التسوق بتاعته
// بيستبدل السلة بالكامل بالسلة الجديدة المرسلة من الفرونت (بعد الدمج مع أي منتجات
// كانت محفوظة محلياً كـ guest قبل تسجيل الدخول)، عشان تفضل موجودة في الداتا بيز
// وترجع تاني حتى لو قفل المتصفح أو دخل من جهاز تاني — ولو مسحها من جهاز، تتمسح معاه
// في كل مكان تاني كمان.
const updateCart = async (req, res) => {
  try {
    if (!req.user) {
      return res.status(401).json({ message: 'لازم تسجل دخول الأول' });
    }

    const { cart } = req.body || {};
    if (!Array.isArray(cart)) {
      return res.status(400).json({ message: 'صيغة السلة غير صحيحة' });
    }

    // تنظيف السلة: عناصر فعلية بس، وسقف أمان لعدد العناصر عشان منمنعش إساءة استخدام
    const cleaned = cart
      .filter((item) => item && typeof item === 'object')
      .slice(0, 200);

    const user = await User.findById(req.user._id);
    if (!user) {
      return res.status(404).json({ message: 'المستخدم غير موجود' });
    }

    user.cart = cleaned;
    await user.save();

    return res.json({ user: safeUser(user) });
  } catch (err) {
    console.error('Update cart error:', err);
    return res.status(500).json({ message: 'حصل خطأ أثناء حفظ السلة' });
  }
};

// POST /api/auth/logout — بيمسح كوكي الـ JWT وكوكي الـ CSRF من السيرفر
const logout = async (req, res) => {
  clearAuthCookie(res);
  clearCsrfCookie(res);
  return res.json({ success: true });
};

// GET /api/auth/csrf-token — بيديك CSRF token جديد (لازم يتنادى أول ما الصفحة تفتح
// قبل أي طلب POST/PUT/PATCH/DELETE، حتى لو المستخدم لسه مش مسجل دخول)
const getCsrfToken = async (req, res) => {
  const csrfToken = setCsrfCookie(res);
  return res.json({ csrfToken });
};

module.exports = {
  register,
  login,
  sendLoginCode,
  verifyLoginCode,
  checkEmailLoginMethod,
  getPublicAuthConfig,
  getAdminAuthConfig,
  updateAdminAuthConfig,
  getMe,
  updateSavedShipping,
  updateWishlist,
  updateCart,
  logout,
  getCsrfToken,
};