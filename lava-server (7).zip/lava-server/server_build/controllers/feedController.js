// ============================================================
// feedController.js — Product Feed Endpoints لـ LAVA Store
//
// GET /feeds/meta-catalog.xml     → ميتا / إنستجرام (RSS XML)
// GET /feeds/google-catalog.xml   → جوجل Merchant Center (RSS XML)
// GET /feeds/tiktok-catalog.csv   → تيك توك (CSV)
// GET /feeds/snapchat-catalog.csv → سناب شات (CSV)
//
// كل endpoint بيتحقق إن الكتالوج المقابل enabled في الـ settings
// لو disabled → يرجع 403
// ============================================================

const Product = require('../models/Product');
const Settings = require('../models/Settings');

// ===== helpers =====

const getSettings = async () => {
  let s = await Settings.findOne({});
  if (!s) s = await Settings.create({});
  return s;
};

const getActiveProducts = async () => {
  return Product.find({ visibility: 'published' }).lean();
};

const getLocalized = (field, lang = 'ar') => {
  if (!field) return '';
  if (typeof field === 'string') return field;
  return field[lang] || field['en'] || field['ar'] || '';
};

const getProductPrice = (p) => {
  const isOnSale = p.onSale && p.salePrice && p.salePrice < p.price;
  return isOnSale ? p.salePrice : p.price;
};

const getSalePrice = (p) => {
  if (p.onSale && p.salePrice && p.salePrice < p.price) return p.salePrice;
  return null;
};

const getFirstImage = (p) => {
  if (!p.images || p.images.length === 0) {
    // جرب صور الفاريانت الأول
    if (p.variants && p.variants.length > 0) {
      const v = p.variants[0];
      if (v.images && v.images.length > 0) return v.images[0].url || '';
    }
    return '';
  }
  const img = p.images[0];
  return img.url || img || '';
};

const getAdditionalImages = (p) => {
  const urls = [];
  if (p.images && p.images.length > 1) {
    p.images.slice(1).forEach(img => {
      const u = img.url || img;
      if (u) urls.push(u);
    });
  }
  return urls.slice(0, 10); // max 10 additional
};

const getTotalStock = (p) => {
  if (p.variants && p.variants.length > 0) {
    return p.variants.reduce((sum, v) => {
      const vStock = (v.sizeStock || []).reduce((s, ss) => s + (ss.stock || 0), 0);
      return sum + vStock;
    }, 0);
  }
  return 1; // لو مفيش فاريانت نعتبره متاح
};

const escapeXml = (str) => {
  if (!str && str !== 0) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
};

const escapeCsv = (val) => {
  if (val === null || val === undefined) return '';
  const str = String(val);
  if (str.includes(',') || str.includes('"') || str.includes('\n')) {
    return `"${str.replace(/"/g, '""')}"`;
  }
  return str;
};

const buildProductUrl = (p, origin) => {
  const slug = p.slug || p._id.toString();
  return `${origin}/product/${slug}`;
};

// ===== Meta / Google XML Feed (RSS 2.0 + g: namespace) =====

const buildXmlFeed = (products, settings, origin, platform) => {
  const storeName = getLocalized(settings.storeName) || 'LAVA Store';
  const storeDesc = getLocalized(settings.storeDescription) || storeName;
  const storeUrl = origin;

  const items = products.map(p => {
    const id = p._id.toString();
    const title = escapeXml(getLocalized(p.name));
    const description = escapeXml(getLocalized(p.description) || getLocalized(p.name));
    const link = escapeXml(buildProductUrl(p, origin));
    const imageLink = escapeXml(getFirstImage(p));
    const additionalImages = getAdditionalImages(p);
    const price = getProductPrice(p);
    const salePrice = getSalePrice(p);
    const stock = getTotalStock(p);
    const availability = stock > 0 ? 'in stock' : 'out of stock';
    const brand = escapeXml(storeName);
    const category = escapeXml(getLocalized(p.category));

    let additionalImagesXml = '';
    additionalImages.forEach(url => {
      additionalImagesXml += `\n      <g:additional_image_link>${escapeXml(url)}</g:additional_image_link>`;
    });

    let salePriceXml = '';
    if (salePrice) {
      salePriceXml = `\n      <g:sale_price>${salePrice} EGP</g:sale_price>`;
    }

    return `
    <item>
      <g:id>${escapeXml(id)}</g:id>
      <g:title>${title}</g:title>
      <g:description>${description}</g:description>
      <g:link>${link}</g:link>
      <g:image_link>${imageLink}</g:image_link>${additionalImagesXml}
      <g:price>${price} EGP</g:price>${salePriceXml}
      <g:availability>${availability}</g:availability>
      <g:condition>new</g:condition>
      <g:brand>${brand}</g:brand>
      <g:google_product_category>${category}</g:google_product_category>
      <g:identifier_exists>false</g:identifier_exists>
    </item>`;
  }).join('');

  return `<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0" xmlns:g="http://base.google.com/ns/1.0">
  <channel>
    <title>${escapeXml(storeName)}</title>
    <link>${escapeXml(storeUrl)}</link>
    <description>${escapeXml(storeDesc)}</description>${items}
  </channel>
</rss>`;
};

// ===== TikTok / Snapchat CSV Feed =====

const buildCsvFeed = (products, settings, origin) => {
  const storeName = getLocalized(settings.storeName) || 'LAVA Store';

  const headers = [
    'sku_id', 'title', 'description', 'availability',
    'condition', 'price', 'sale_price', 'link',
    'image_link', 'additional_image_link',
    'brand', 'product_type',
  ];

  const rows = products.map(p => {
    const id = p._id.toString();
    const title = getLocalized(p.name);
    const description = getLocalized(p.description) || title;
    const stock = getTotalStock(p);
    const availability = stock > 0 ? 'in stock' : 'out of stock';
    const price = getProductPrice(p);
    const salePrice = getSalePrice(p);
    const link = buildProductUrl(p, origin);
    const imageLink = getFirstImage(p);
    const additionalImages = getAdditionalImages(p).join('|');
    const brand = storeName;
    const category = getLocalized(p.category);

    return [
      id, title, description, availability, 'new',
      `${price} EGP`,
      salePrice ? `${salePrice} EGP` : '',
      link, imageLink, additionalImages,
      brand, category,
    ].map(escapeCsv).join(',');
  });

  return [headers.join(','), ...rows].join('\n');
};

// ===== Route Handlers =====

// GET /feeds/meta-catalog.xml
const getMetaCatalog = async (req, res) => {
  try {
    const settings = await getSettings();
    if (!settings.metaCatalogEnabled) {
      return res.status(403).json({ message: 'Meta catalog is disabled' });
    }
    const products = await getActiveProducts();
    const origin = `${req.protocol}://${req.get('host')}`;
    const xml = buildXmlFeed(products, settings, origin, 'meta');
    res.set('Content-Type', 'application/xml; charset=utf-8');
    res.set('Cache-Control', 'public, max-age=3600'); // cache ساعة
    res.send(xml);
  } catch (err) {
    console.error('Meta catalog feed error:', err);
    res.status(500).json({ message: 'Feed generation failed', error: err.message });
  }
};

// GET /feeds/google-catalog.xml
const getGoogleCatalog = async (req, res) => {
  try {
    const settings = await getSettings();
    if (!settings.googleCatalogEnabled) {
      return res.status(403).json({ message: 'Google catalog is disabled' });
    }
    const products = await getActiveProducts();
    const origin = `${req.protocol}://${req.get('host')}`;
    const xml = buildXmlFeed(products, settings, origin, 'google');
    res.set('Content-Type', 'application/xml; charset=utf-8');
    res.set('Cache-Control', 'public, max-age=3600');
    res.send(xml);
  } catch (err) {
    console.error('Google catalog feed error:', err);
    res.status(500).json({ message: 'Feed generation failed', error: err.message });
  }
};

// GET /feeds/tiktok-catalog.csv
const getTikTokCatalog = async (req, res) => {
  try {
    const settings = await getSettings();
    if (!settings.tiktokCatalogEnabled) {
      return res.status(403).json({ message: 'TikTok catalog is disabled' });
    }
    const products = await getActiveProducts();
    const origin = `${req.protocol}://${req.get('host')}`;
    const csv = buildCsvFeed(products, settings, origin);
    res.set('Content-Type', 'text/csv; charset=utf-8');
    res.set('Content-Disposition', 'attachment; filename="tiktok-catalog.csv"');
    res.set('Cache-Control', 'public, max-age=3600');
    res.send(csv);
  } catch (err) {
    console.error('TikTok catalog feed error:', err);
    res.status(500).json({ message: 'Feed generation failed', error: err.message });
  }
};

// GET /feeds/snapchat-catalog.csv
const getSnapchatCatalog = async (req, res) => {
  try {
    const settings = await getSettings();
    if (!settings.snapchatCatalogEnabled) {
      return res.status(403).json({ message: 'Snapchat catalog is disabled' });
    }
    const products = await getActiveProducts();
    const origin = `${req.protocol}://${req.get('host')}`;
    const csv = buildCsvFeed(products, settings, origin);
    res.set('Content-Type', 'text/csv; charset=utf-8');
    res.set('Content-Disposition', 'attachment; filename="snapchat-catalog.csv"');
    res.set('Cache-Control', 'public, max-age=3600');
    res.send(csv);
  } catch (err) {
    console.error('Snapchat catalog feed error:', err);
    res.status(500).json({ message: 'Feed generation failed', error: err.message });
  }
};

module.exports = {
  getMetaCatalog,
  getGoogleCatalog,
  getTikTokCatalog,
  getSnapchatCatalog,
};
