const User = require('../models/User');
const Order = require('../models/Order');
const Settings = require('../models/Settings');
const AbandonedCart = require('../models/AbandonedCart');
const MarketingMessage = require('../models/MarketingMessage');
const { sendEmail, sendWhatsApp, configured, verifyConfirmationToken, escapeHtml } = require('../services/brevoService');

const normalizeEmail = e => String(e || '').trim().toLowerCase();

const getMarketing = async (req, res) => {
  const settings = await Settings.findOne().select('marketing').lean();
  res.json({ configured: configured(), marketing: settings?.marketing || {} });
};

const updateMarketing = async (req, res) => {
  const input = req.body?.marketing || req.body || {};
  const safe = {
    enabled: Boolean(input.enabled),
    orderConfirmation: Boolean(input.orderConfirmation),
    orderConfirmationChannel: ['email','whatsapp'].includes(input.orderConfirmationChannel) ? input.orderConfirmationChannel : 'email',
    statusNotifications: Boolean(input.statusNotifications),
    statusChannels: Array.isArray(input.statusChannels) ? input.statusChannels.slice(0, 30).map(x => ({
      status: String(x.status || '').slice(0, 80), enabled: Boolean(x.enabled), channel: ['email','whatsapp'].includes(x.channel) ? x.channel : 'email', subject: String(x.subject || '').slice(0, 180), content: String(x.content || '').slice(0, 20000),
    })) : [],
    abandonedCart: {
      enabled: Boolean(input.abandonedCart?.enabled),
      steps: Array.isArray(input.abandonedCart?.steps) ? input.abandonedCart.steps.slice(0, 10).map((x, i) => ({
        step: i, delayMinutes: Math.max(1, Math.min(10080, Number(x.delayMinutes) || 120)), channel: ['email','whatsapp'].includes(x.channel) ? x.channel : 'email', subject: String(x.subject || '').slice(0, 180), content: String(x.content || '').slice(0, 20000), couponCode: String(x.couponCode || '').slice(0, 80),
      })) : [],
    },
    whatsapp: { enabled: Boolean(input.whatsapp?.enabled), senderNumber: String(input.whatsapp?.senderNumber || '').replace(/\D/g, '').slice(0, 20) },
  };
  await Settings.findOneAndUpdate({}, { $set: { marketing: safe } }, { upsert: true, new: true, setDefaultsOnInsert: true });
  res.json({ ok: true, marketing: safe, configured: configured() });
};

function renderText(template, ctx) {
  return String(template || '').replace(/\{\{\s*([a-zA-Z0-9_.-]+)\s*\}\}/g, (_, key) => {
    const parts = key.split('.'); let value = ctx;
    for (const p of parts) value = value?.[p];
    return value == null ? '' : String(value);
  });
}

// حجم الدفعة الواحدة لجدولة رسائل الحملة — بنقسّم الجمهور الكبير لدفعات صغيرة
// (batching) بدل ما نحمّل كل العملاء في الميموري مرة واحدة أو نعمل insert
// ضخم واحد، وبنسيب فرصة للـ event loop يستجيب لطلبات تانية بين كل دفعة.
const CAMPAIGN_BATCH_SIZE = 500;
const yieldToEventLoop = () => new Promise((resolve) => setImmediate(resolve));

const queueCampaign = async (req, res) => {
  try {
    const { channel='email', subject='', content='', audience='all', couponCode='', whatsappTemplateId } = req.body || {};
    if (!['email','whatsapp'].includes(channel)) return res.status(400).json({ message: 'القناة غير صحيحة' });
    if (!String(content).trim()) return res.status(400).json({ message: 'اكتب الرسالة أولاً' });

    const filter = { role: 'customer' };
    if (audience === 'with_orders') {
      filter._id = { $in: await Order.distinct('customerId', { customerId: { $ne: null } }) };
    }

    // معرّف واحد للحملة (للتجميع/التقارير)، لكن entityId الفريد لكل رسالة
    // لازم يكون مختلف لكل مستلم (campaignTag + userId)، وإلا الـ unique index
    // على (kind, entityId, step, channel) هيمنع إدخال أكتر من مستلم واحد
    // لنفس الحملة — وده كان بيسبب إرسال الحملة لعميل واحد بس فعليًا.
    const campaignTag = `campaign-${Date.now()}-${Math.random().toString(36).slice(2)}`;
    const scheduledAt = new Date();

    let queued = 0;
    let batch = [];

    // ===== cursor بدل find().lean() عادي: بيقرأ العملاء واحد ورا التاني من =====
    // MongoDB من غير ما يحمّل كل الجمهور (ممكن يكون ملايين) في الميموري مرة واحدة.
    const cursor = User.find(filter).select('name email phone').lean().cursor();
    for (let u = await cursor.next(); u != null; u = await cursor.next()) {
      const target = channel === 'email' ? normalizeEmail(u.email) : String(u.phone || '').replace(/\D/g, '');
      if (!target) continue;

      batch.push({
        kind: 'campaign',
        channel,
        recipientEmail: normalizeEmail(u.email),
        recipientPhone: String(u.phone || '').replace(/\D/g, ''),
        subject: String(subject).slice(0, 180),
        content: renderText(content, { customer: u, couponCode }),
        scheduledAt,
        status: 'pending',
        entityId: `${campaignTag}-${u._id}`,
        whatsappTemplateId: whatsappTemplateId ? Number(whatsappTemplateId) : undefined,
      });

      if (batch.length >= CAMPAIGN_BATCH_SIZE) {
        await MarketingMessage.insertMany(batch, { ordered: false });
        queued += batch.length;
        batch = [];
        // بنسيب الـ event loop يلحق يستجيب لأي HTTP request تاني جاي للعملاء
        // قبل ما نكمل الدفعة الجاية، بدل ما الحملة الكبيرة تحجز الـ process كله.
        await yieldToEventLoop();
      }
    }

    if (batch.length) {
      await MarketingMessage.insertMany(batch, { ordered: false });
      queued += batch.length;
    }

    res.json({ ok: true, queued });
  } catch (err) { console.error('Marketing campaign error:', err); res.status(500).json({ message: 'تعذر تجهيز الحملة' }); }
};

const confirmOrderByEmail = async (req, res) => {
  try {
    const data = verifyConfirmationToken(req.params.token);
    if (!data) return res.status(400).send('<h2>رابط التأكيد غير صالح أو منتهي.</h2>');
    const order = await Order.findById(data.orderId);
    if (!order || normalizeEmail(order.customerEmail) !== normalizeEmail(data.email)) return res.status(404).send('<h2>الطلب غير موجود.</h2>');
    if (!order.emailConfirmation?.confirmedAt) {
      order.emailConfirmation = { ...(order.emailConfirmation?.toObject?.() || order.emailConfirmation || {}), confirmedAt: new Date(), confirmedEmail: true };
      await order.save();
    }
    const clientUrl = process.env.CLIENT_URL || process.env.FRONTEND_URL || '/';
    res.send(`<!doctype html><html><body style="font-family:Arial;text-align:center;padding:60px"><h1>تم تسجيل تأكيد طلبك ✅</h1><p>التأكيد من الإيميل تم تسجيله، وسيتم التواصل معك لتأكيد الطلب بشكل نهائي.</p><a href="${escapeHtml(clientUrl)}">العودة للمتجر</a></body></html>`);
  } catch (err) { console.error('confirm email:', err); res.status(500).send('<h2>حصل خطأ. حاول مرة أخرى.</h2>'); }
};

const getMessageStats = async (req, res) => {
  const [pending, sent, failed] = await Promise.all([
    MarketingMessage.countDocuments({ status: 'pending' }),
    MarketingMessage.countDocuments({ status: 'sent' }),
    MarketingMessage.countDocuments({ status: 'failed' }),
  ]);
  res.json({ pending, sent, failed, configured: configured() });
};

module.exports = { getMarketing, updateMarketing, queueCampaign, confirmOrderByEmail, getMessageStats };