const express = require('express');
const router = express.Router();
const {
  getProducts, getAllProductsAdmin, getProductById,
  createProduct, updateProduct, deleteProduct,
  uploadVariantImages, uploadProductVideo, getInventoryMovements,
} = require('../controllers/productController');
const { protect, access } = require('../middleware/auth');
const upload = require('../middleware/upload');
const { validateUploadedImages, uploadVideo, validateUploadedVideo } = require('../middleware/upload');

router.get('/', getProducts);
router.get('/admin', protect, access('products', 'view'), getAllProductsAdmin);
router.get('/inventory/movements', protect, access('products', 'view'), getInventoryMovements);
router.get('/:id', getProductById);
router.post('/', protect, access('products', 'edit'), upload.array('images', 10), validateUploadedImages, createProduct);
router.put('/:id', protect, access('products', 'edit'), upload.array('images', 10), validateUploadedImages, updateProduct);
router.delete('/:id', protect, access('products', 'edit'), deleteProduct);
router.post('/:id/variants/:variantIndex/images', protect, access('products', 'edit'), upload.array('images', 10), validateUploadedImages, uploadVariantImages);
router.post('/video', protect, access('products', 'edit'), uploadVideo.single('video'), validateUploadedVideo, uploadProductVideo);

module.exports = router;