const express = require('express');
const router = express.Router();
const { upsertAbandonedCart, markRecovered, getAbandonedCarts } = require('../controllers/abandonedCartController');
const { protect, authorize, optionalProtect, access } = require('../middleware/auth');

router.post('/', optionalProtect, upsertAbandonedCart);
router.put('/recover', optionalProtect, markRecovered);
router.get('/', protect, access('abandoned_carts', 'view'), getAbandonedCarts);

module.exports = router;