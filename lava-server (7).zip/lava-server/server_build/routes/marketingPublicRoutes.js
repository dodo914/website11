const express = require('express');
const router = express.Router();
const { confirmOrderByEmail } = require('../controllers/marketingController');
router.get('/order-confirm/:token', confirmOrderByEmail);
module.exports = router;
