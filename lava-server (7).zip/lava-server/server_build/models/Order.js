const mongoose = require('mongoose');

const orderItemSchema = new mongoose.Schema({
  productId: { type: mongoose.Schema.Types.ObjectId, ref: 'Product' },
  name: { type: mongoose.Schema.Types.Mixed, default: null },
  variantId: String,
  size: String,
  color: { type: mongoose.Schema.Types.Mixed, default: null },
  colorHex: { type: String, default: null },
  productImage: { type: String, default: null },
  price: Number,          // السعر الفعلي اللي دفعه العميل (بعد أي خصم باندل)
  originalPrice: Number,  // السعر الأصلي للمنتج قبل خصم الباندل
  costPrice: Number,
  quantity: { type: Number, default: 1 },
  // ===== حقول الباندل =====
  isBundleItem: { type: Boolean, default: false },
  bundleDiscount: { type: Number, default: 0 },
}, { _id: false });

const orderSchema = new mongoose.Schema({
  customerId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },
  customerName: { type: String, required: true },
  customerPhone: { type: String, required: true },
  customerPhone2: String,
  customerEmail: String,
  emailConfirmation: {
    enabled: { type: Boolean, default: false },
    confirmed: { type: Boolean, default: false },
    confirmedAt: { type: Date, default: null },
    messageId: { type: String, default: null },
    // ===== حالة إرسال رسالة/واتساب تأكيد الطلب في الخلفية =====
    // not_sent: مفيش رسالة اتجدولت أصلاً. pending: اتجدولت ولسه مبعتتش.
    // sent: اتبعتت بنجاح. failed: فشلت بعد استنفاد كل محاولات الـ retry.
    status: { type: String, enum: ['not_sent', 'pending', 'sent', 'failed'], default: 'not_sent' },
  },
  items: [orderItemSchema],
  subtotal: Number,
  discount: Number,
  discountType: String,
  discountCode: String,
  promoLabel: String,
  shippingCost: Number,
  totalAmount: Number,
  governorate: String,
  country: String,
  address: String,
  zipCode: String,
  notes: String,
  status: { type: String, default: 'جديد' },
  packerStatus: { type: String, default: 'لم يتم التجهيز' },

  // ===== الدفع =====
  paymentMethod: { type: String, default: 'cod' }, // 'cod' | 'wallet'
  paymentStatus: { type: String, default: 'pending', enum: ['pending', 'paid', 'failed', 'refunded'] },
  walletPayment: {
    methodId: { type: String, default: null },
    methodName: { type: String, default: null },
    walletPhoneNumber: { type: String, default: null },
    senderPhone: { type: String, default: null },
    transferDate: { type: String, default: null },
    screenshotUrl: { type: String, default: null },
    screenshotPublicId: { type: String, default: null },
    confirmed: { type: Boolean, default: false },
    confirmedAt: { type: Date, default: null },
  },

  // ===== الشحن =====
  shippingStatus: {
    type: String,
    default: 'pending',
    enum: ['pending', 'preparing', 'shipped', 'delivered', 'failed_delivery', 'returned']
  },
  shippingCompany: { type: String, default: null },   // اسم شركة الشحن (Aramex, Bosta, J&T...)
  trackingNumber: { type: String, default: null },    // رقم التتبع
  shippingNotes: { type: String, default: null },     // ملاحظات الشحن / مشاكل
  shippedAt: { type: Date, default: null },           // تاريخ الشحن الفعلي
  deliveredAt: { type: Date, default: null },         // تاريخ الاستلام الفعلي

  // ===== حماية المخزون من الاسترجاع المكرر =====
  // stockRestored: بيبقى true أول ما يتم إرجاع المخزون بسبب إلغاء/رفض/ارتجاع،
  // عشان لو حد نادى على endpoint الإلغاء أكتر من مرة، المخزون ميترجعش مرتين.
  stockRestored: { type: Boolean, default: false },
  stockRestoredAt: { type: Date, default: null },
}, {
  timestamps: true,
  toJSON: { virtuals: false },
  toObject: { virtuals: false },
});

orderSchema.index({ createdAt: -1 });
orderSchema.index({ customerId: 1, createdAt: -1 });
orderSchema.index({ status: 1, createdAt: -1 });
orderSchema.index({ paymentMethod: 1, createdAt: -1 });
orderSchema.index({ paymentStatus: 1, createdAt: -1 });
orderSchema.index({ shippingStatus: 1, createdAt: -1 });
orderSchema.index({ shippingCompany: 1 });
orderSchema.index({ trackingNumber: 1 });
orderSchema.index({ customerEmail: 1 });
orderSchema.index({ customerPhone: 1 });
orderSchema.index({ 'items.productId': 1 });

module.exports = mongoose.model('Order', orderSchema);