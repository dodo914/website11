// ============================================================================
// utils/orderIdempotencyKey.js  (P1-1: Order Creation Idempotency)
// ------------------------------------------------------------------------
// دالة صغيرة نقية (pure) لاستخراج مفتاح idempotency الخاص بإنشاء الطلب من
// الـrequest - منفصلة عن controllers/orderController.js عشان تتختبر
// مباشرة من غير الحاجة لمحاكاة كل الـDB/services اللي createOrder بتستخدمها.
//
// أقصى طول منطقي لمفتاح idempotency القادم من العميل (حماية من قيم كبيرة/هجومية).
const MAX_IDEMPOTENCY_KEY_LENGTH = 200;

/**
 * buildOrderIdempotencyKey(req)
 *
 * بيقرأ مفتاح idempotency من هيدر "Idempotency-Key" (المعيار الشائع) أو
 * "X-Idempotency-Key"، أو من req.body.idempotencyKey كـfallback. بيربط
 * المفتاح بهوية مقدّم الطلب (customerId المسجّل أو 'guest') عشان عميل
 * ميقدرش يستخدم مفتاح عميل تاني عمدًا ويشوف نتيجة/بيانات طلب مش بتاعه.
 *
 * بيرجع null لو مفيش مفتاح مُرسل أصلاً (سلوك مُعرَّف بوضوح: إنشاء الطلب
 * بيكمل بنفس السلوك القديم من غير أي حماية إضافية - شوف orderController.js).
 *
 * بيرجع { idempotencyKey, scope } لو فيه مفتاح صالح.
 */
function buildOrderIdempotencyKey(req) {
  const headers = (req && req.headers) || {};
  const body = (req && req.body) || {};

  const rawIdemKey = headers['idempotency-key'] || headers['x-idempotency-key'] ||
    (typeof body.idempotencyKey === 'string' ? body.idempotencyKey : null);
  const trimmedIdemKey = typeof rawIdemKey === 'string' ? rawIdemKey.trim() : '';

  if (!trimmedIdemKey) return null;

  const scope = (req && req.user && req.user._id) ? `user:${req.user._id}` : 'guest';
  const idempotencyKey = `${scope}:${trimmedIdemKey.slice(0, MAX_IDEMPOTENCY_KEY_LENGTH)}`;

  return { idempotencyKey, scope };
}

module.exports = { buildOrderIdempotencyKey, MAX_IDEMPOTENCY_KEY_LENGTH };