const mongoose = require('mongoose');

// ============================================================
// نظام الاستبدال (Exchange) - المرحلة الأولى
// ------------------------------------------------------------------------
// ده Model مستقل ومنفصل عن Order.returnItems/returnRequestStatus (نظام
// الـReturn الموجود بالفعل جوه Order.js) لأن الاستبدال محتاج تتبع أغنى
// (Variant قديم + Variant جديد لكل عنصر، وworkflow أطول من مجرد
// pending/approved/rejected)، وده يمنع أي تعارض أو كسر لنظام الـReturn
// الحالي - Order.js متغيرش خالص في المرحلة دي.
//
// كل عنصر في exchange request بيحتفظ بالمنتج/الفاريانت/المقاس القديم
// (اللي اشتراه العميل فعلاً وموجود في الـ Order) والمنتج/الفاريانت/المقاس
// الجديد المطلوب استبداله بيه. بيتم التحقق من كل ده Server-side في
// controllers/exchangeController.js (مش بس Frontend validation).
// ============================================================

const exchangeItemSchema = new mongoose.Schema({
  productId: { type: mongoose.Schema.Types.ObjectId, ref: 'Product', required: true },
  quantity: { type: Number, default: 1 },

  // ===== الفاريانت القديم (اللي في الطلب الأصلي فعلاً) =====
  oldVariant: {
    variantId: { type: String, default: null },
    size: { type: String, default: null },
    color: { type: mongoose.Schema.Types.Mixed, default: null },
  },

  // ===== الفاريانت الجديد المطلوب الاستبدال بيه =====
  requestedNewVariant: {
    variantId: { type: String, default: null },
    size: { type: String, default: null },
    color: { type: mongoose.Schema.Types.Mixed, default: null },
  },
}, { _id: false });

const statusHistoryEntrySchema = new mongoose.Schema({
  status: { type: String, required: true },
  at: { type: Date, default: Date.now },
  by: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },
  note: { type: String, default: null },
}, { _id: false });

const EXCHANGE_STATUSES = [
  'pending',
  'under_review',
  'approved',
  'rejected',
  'pickup_scheduled',
  'received',
  'processing',
  'completed',
  'cancelled',
];

const exchangeRequestSchema = new mongoose.Schema({
  // ===== معرّف قصير قابل للعرض للعميل/الأدمن (منفصل عن Mongo _id) =====
  requestId: { type: String, required: true, unique: true },

  orderId: { type: mongoose.Schema.Types.ObjectId, ref: 'Order', required: true },
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },

  // ثابتة على 'exchange' حاليًا - موجودة عشان لو في المستقبل حبينا نوحّد
  // الـReturn والـExchange في نفس الـcollection.
  type: { type: String, default: 'exchange' },

  items: {
    type: [exchangeItemSchema],
    validate: [(arr) => Array.isArray(arr) && arr.length > 0, 'لازم تختار منتج واحد على الأقل للاستبدال'],
  },

  reasonCode: { type: String, default: null },
  reason: { type: String, default: null }, // نفس reasonCode لكن كنص عرض (مطابق لـEXCHANGE_REASONS)
  customerNote: { type: String, default: null }, // تفاصيل حرة (إلزامية لو reasonCode === 'other')

  // صور إثبات (لو Settings.requireEvidenceImages مفعّلة والسبب يستوجبها -
  // شوف utils/returnExchangeFees.js). روابط Cloudinary مرفوعة مسبقًا عن
  // طريق نفس File Upload الموجود بالفعل في المشروع (middleware/upload.js).
  evidenceImages: { type: [String], default: [] },

  // ===== Exchange Fee - Snapshot (Phase 2A - بند 5 + 6) =====
  // بتتحسب Server-side بس وقت إنشاء الطلب (utils/returnExchangeFees.js) وبتتحفظ
  // هنا زي ما هي - أي تغيير لاحق في Settings.exchangeFeeAmount مبيأثرش على
  // الطلبات القديمة، الطلبات الجديدة بس هي اللي تستخدم القيمة الجديدة.
  fee: { type: Number, default: 0 },
  currency: { type: String, default: 'EGP' },
  feeType: { type: String, default: null }, // 'exchange' | 'free_store_error' | 'free'

  status: { type: String, enum: EXCHANGE_STATUSES, default: 'pending' },
  statusHistory: { type: [statusHistoryEntrySchema], default: [] },

  // ===== مين طلب الاستبدال - زي Order.returnRequestedBy بالظبط =====
  // 'customer': العميل هو اللي فتح الطلب من "طلباتي". 'admin': الأدمن سجّله
  // بنفسه (مثلاً العميل كلّمه تليفونيًا) - في الحالة دي الطلب بيتعمله approve
  // فورًا (خطوة واحدة) بدل ما يفضل pending محتاج موافقة تانية.
  requestedBy: { type: String, enum: ['customer', 'admin'], default: 'customer' },

  // ===== رقم تتبع شحنة الاستبدال - بيتحط يدويًا بواسطة الأدمن =====
  // (زي Order.returnTrackingNumber بالظبط) لحد ما شركة الشحن تدعم
  // Exchange API رسميًا (شوف services/shipping/capabilities.js).
  trackingNumber: { type: String, default: null },

  reviewedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },
  reviewedAt: { type: Date, default: null },
  adminNote: { type: String, default: null },

  // ===== حماية المخزون من التعديل المكرر =====
  // بتبقى true أول ما المخزون يتعدّل فعليًا (خصم الفاريانت الجديد + إرجاع
  // القديم) وقت الموافقة، عشان أي محاولة موافقة/إلغاء تانية متأثرش في
  // المخزون مرتين. نفس فكرة Order.stockRestored بالظبط.
  stockAdjusted: { type: Boolean, default: false },
  stockAdjustedAt: { type: Date, default: null },
}, {
  timestamps: true,
});

exchangeRequestSchema.index({ orderId: 1, createdAt: -1 });
exchangeRequestSchema.index({ userId: 1, createdAt: -1 });
exchangeRequestSchema.index({ status: 1, createdAt: -1 });

module.exports = mongoose.model('ExchangeRequest', exchangeRequestSchema);
module.exports.EXCHANGE_STATUSES = EXCHANGE_STATUSES;