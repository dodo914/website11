const express = require('express');
const router = express.Router();
const {
  createOrder, getOrders, getMyOrders, updateOrderStatus, updatePackerStatus,
  getLoyaltyInfo, confirmWalletPayment,
  getPaymentsDashboard, getShippingDashboard, updateOrderShipping, updatePaymentStatus,
  refundOrderPayment, requestReturn, reviewReturnRequest,
  getReturnReasons, getReturnEligibility, uploadEvidenceImage,
  getReturnRequests, getReturnRequestDetails,
} = require('../controllers/orderController');
const { createExchangeRequest, getExchangeReasons, getExchangeEligibility } = require('../controllers/exchangeController');
const { protect, authorize, optionalProtect, access } = require('../middleware/auth');
const upload = require('../middleware/upload');
const { validateUploadedImages } = require('../middleware/upload');

router.post('/', optionalProtect, upload.single('screenshot'), validateUploadedImages, createOrder);
router.get('/', protect, access('orders', 'view', ['call_center', 'packer']), getOrders);
router.get('/mine', protect, getMyOrders);
router.get('/loyalty-info', protect, getLoyaltyInfo);

// ===== لوحات البيانات الجديدة =====
router.get('/payments-dashboard', protect, access('payments_dashboard', 'view'), getPaymentsDashboard);
router.get('/shipping-dashboard', protect, access('shipping_dashboard', 'view'), getShippingDashboard);

router.put('/:id/status', protect, access('orders', 'edit', ['call_center']), updateOrderStatus);
router.put('/:id/packer-status', protect, access('orders', 'edit', ['packer']), updatePackerStatus);
router.put('/:id/confirm-payment', protect, access('orders', 'edit', ['call_center']), confirmWalletPayment);
router.put('/:id/payment-status', protect, access('payments_dashboard', 'edit'), updatePaymentStatus);
router.put('/:id/refund', protect, access('payments_dashboard', 'edit'), refundOrderPayment);
router.put('/:id/shipping', protect, access('orders', 'edit', ['call_center']), updateOrderShipping);

// ===== استرجاع منتجات محددة من الطلب =====
// العميل بيطلب (route المفتوحة لأي مستخدم مسجل - بيتحقق داخل الكنترولر إن
// الطلب تابع له فعلاً)، والأدمن بيوافق/يرفض أو يبدأ استرجاع بنفسه.
router.post('/:id/return-request', protect, requestReturn);
router.put('/:id/return-request', protect, access('orders', 'edit', ['call_center']), reviewReturnRequest);
router.get('/:id/return-request', protect, getReturnRequestDetails);

// ===== Returns & Exchanges - Phase 2B: قايمة كل طلبات الاسترجاع (أدمن) =====
router.get('/return-requests', protect, access('orders', 'view', ['call_center', 'packer']), getReturnRequests);

// ===== Returns & Exchanges - Phase 2A: أسباب/أهلية/صور إثبات =====
router.get('/return-reasons', getReturnReasons);
router.get('/:id/return-eligibility', protect, getReturnEligibility);
router.get('/exchange-reasons', getExchangeReasons);
router.get('/:id/exchange-eligibility', protect, getExchangeEligibility);
// صورة إثبات مشتركة للاسترجاع والاستبدال (نفس File Upload الموجود بالفعل)
router.post('/evidence-images', protect, upload.single('image'), validateUploadedImages, uploadEvidenceImage);

// ===== طلب استبدال (Exchange) منتج من الطلب - نفس فكرة return-request بالظبط =====
// باقي عمليات الاستبدال (عرض/مراجعة/تحديث حالة/إلغاء) في routes/exchangeRoutes.js
// تحت /api/exchange-requests.
router.post('/:id/exchange-request', protect, createExchangeRequest);

module.exports = router;